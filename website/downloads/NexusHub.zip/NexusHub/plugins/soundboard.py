"""Soundboard: pads with hotkeys, optionally played into a virtual mic for Discord/games."""
import math
import os
import random
import shutil
import struct
import uuid
import wave

from PySide6.QtCore import QRectF, Qt, QUrl, Signal
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPen
from PySide6.QtWidgets import (QComboBox, QDialog, QFileDialog, QGridLayout, QInputDialog, QMenu, QPushButton,
                               QSlider, QVBoxLayout, QWidget)

from core import ui
from core.config import APP_DIR
from core.plugin import Plugin

try:
    from PySide6.QtMultimedia import QAudioOutput, QMediaDevices, QMediaPlayer
    HAS_AUDIO = True
except ImportError:
    HAS_AUDIO = False

SOUND_DIR = os.path.join(APP_DIR, "sounds")
AUDIO_EXT = (".mp3", ".wav", ".ogg", ".m4a", ".flac", ".aac", ".wma")
PAD_COLORS = ["#7c6cff", "#22d3ee", "#f472b6", "#34d399", "#fbbf24", "#f87171", "#a78bfa", "#60a5fa"]


# ====================================================================== starter sounds (synthesised)
RATE = 22050


def _write(name, samples):
    path = os.path.join(SOUND_DIR, name + ".wav")
    peak = max(1e-9, max(abs(s) for s in samples))
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(b"".join(struct.pack("<h", int(s / peak * 30000)) for s in samples))
    return path


def _saw(f, t):
    return 2 * ((f * t) % 1.0) - 1


def _env(i, n, attack=0.01, release=0.08):
    t, dur = i / RATE, n / RATE
    return min(1.0, t / attack, max(0.0, (dur - t) / release))


def make_starter_sounds():
    os.makedirs(SOUND_DIR, exist_ok=True)
    out = []
    # air horn: three blasts of a detuned sawtooth chord
    s = []
    for length in (0.18, 0.18, 0.7):
        n = int(RATE * length)
        s += [_env(i, n) * sum(_saw(f, i / RATE) for f in (466, 470, 587, 698)) for i in range(n)]
        s += [0.0] * int(RATE * 0.06)
    out.append(("Air Horn", _write("Air Horn", s)))
    # ding
    n = int(RATE * 1.4)
    out.append(("Ding", _write("Ding", [math.exp(-i / RATE * 3.2) * (math.sin(2 * math.pi * 1318 * i / RATE)
                                          + 0.4 * math.sin(2 * math.pi * 2637 * i / RATE)) for i in range(n)])))
    # ba-dum-tss
    rnd = random.Random(3)
    s = []
    for f0 in (180, 130):
        n = int(RATE * 0.16)
        ph = 0.0
        for i in range(n):
            ph += 2 * math.pi * (f0 - 60 * i / n) / RATE
            s.append(math.sin(ph) * math.exp(-i / RATE * 18))
        s += [0.0] * int(RATE * 0.07)
    n = int(RATE * 1.1)
    prev = 0.0
    for i in range(n):
        x = rnd.uniform(-1, 1)
        s.append((x - prev) * 0.6 * math.exp(-i / RATE * 3.5))   # crude high-pass = cymbal hiss
        prev = x
    out.append(("Ba Dum Tss", _write("Ba Dum Tss", s)))
    # sad trombone
    s = []
    for k, (f, length) in enumerate(((392, 0.35), (370, 0.35), (349, 0.35), (330, 1.1))):
        n = int(RATE * length)
        lp = 0.0
        for i in range(n):
            t = i / RATE
            vib = 1 + (0.012 * math.sin(2 * math.pi * 5.5 * t) if k == 3 else 0)
            lp += (_saw(f * vib, t) - lp) * 0.25     # soften the saw
            s.append(lp * _env(i, n, 0.03, 0.12))
    out.append(("Sad Trombone", _write("Sad Trombone", s)))
    # level up
    s = []
    for f in (523, 659, 784, 1046):
        n = int(RATE * (0.09 if f < 1046 else 0.35))
        s += [(1 if math.sin(2 * math.pi * f * i / RATE) > 0 else -1) * 0.5 * _env(i, n, 0.005, 0.05) for i in range(n)]
    out.append(("Level Up", _write("Level Up", s)))
    # drum roll + crash
    s = []
    n = int(RATE * 1.6)
    for i in range(n):
        t = i / RATE
        rate = 14 + 10 * t
        hit = math.exp(-((t * rate) % 1.0) * 6)
        s.append(rnd.uniform(-1, 1) * hit * (0.4 + 0.4 * t))
    n = int(RATE * 1.2)
    prev = 0.0
    for i in range(n):
        x = rnd.uniform(-1, 1)
        s.append((x - prev * 0.3) * math.exp(-i / RATE * 2.5))
        prev = x
    out.append(("Drum Roll", _write("Drum Roll", s)))
    return out


# ====================================================================== UI
class Pad(QPushButton):
    def __init__(self, plugin, pad):
        super().__init__()
        self.plugin, self.pad = plugin, pad
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumSize(150, 104)
        self.playing = False
        self.clicked.connect(lambda: plugin.play(pad))
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._menu)

    def _menu(self, pos):
        m = QMenu(self)
        m.addAction(ui.glyph_icon(""), "Play", lambda: self.plugin.play(self.pad))
        m.addAction(ui.glyph_icon(""), "Set hotkey…", lambda: self.plugin.edit_hotkey(self.pad))
        m.addAction(ui.glyph_icon(""), "Rename…", lambda: self.plugin.rename(self.pad))
        m.addAction(ui.glyph_icon(""), "Volume…", lambda: self.plugin.edit_volume(self.pad))
        m.addAction(ui.glyph_icon(""), "Change colour", lambda: self.plugin.cycle_color(self.pad))
        m.addSeparator()
        m.addAction(ui.glyph_icon(""), "Remove", lambda: self.plugin.remove(self.pad))
        m.exec(self.mapToGlobal(pos))

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        c = QColor(self.pad.get("color", ui.ACCENT))
        g = QLinearGradient(r.topLeft(), r.bottomRight())
        a = 235 if self.isDown() or self.playing else (200 if self.underMouse() else 150)
        c1, c2 = QColor(c), QColor(c).darker(170)
        c1.setAlpha(a)
        c2.setAlpha(a)
        g.setColorAt(0, c1)
        g.setColorAt(1, c2)
        p.setBrush(g)
        p.setPen(QPen(QColor(255, 255, 255, 110 if self.playing else 25), 2 if self.playing else 1))
        p.drawRoundedRect(r, 14, 14)
        f = QFont(ui.TEXT_FONT)
        f.setPixelSize(15)
        f.setWeight(QFont.DemiBold)
        p.setFont(f)
        p.setPen(QColor("white"))
        p.drawText(r.adjusted(14, 12, -12, -30), Qt.AlignLeft | Qt.AlignTop | Qt.TextWordWrap, self.pad["name"])
        combo = self.plugin.hub.combo_for(self.plugin, "pad_" + self.pad["id"])
        f.setPixelSize(11)
        f.setWeight(QFont.Normal)
        p.setFont(f)
        p.setPen(QColor(255, 255, 255, 190))
        p.drawText(r.adjusted(14, 0, -12, -10), Qt.AlignLeft | Qt.AlignBottom,
                   ui.hotkeys.pretty(combo) if combo else "Right-click to set a hotkey")


class Board(QWidget):
    """Pad grid that also accepts dropped audio files."""
    dropped = Signal(list)

    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)
        self.grid = QGridLayout(self)
        self.grid.setSpacing(12)
        self.grid.setContentsMargins(0, 0, 0, 0)

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        self.dropped.emit([u.toLocalFile() for u in e.mimeData().urls() if u.toLocalFile().lower().endswith(AUDIO_EXT)])


class Soundboard(Plugin):
    id = "soundboard"
    name = "Soundboard"
    icon = ""
    category = "Media"
    order = 12
    description = "Play sound effects with hotkeys, through your speakers and (optionally) into your mic so friends on Discord hear them."
    hotkeys = {"stop_all": ("Stop all sounds", "ctrl+alt+shift+x")}

    def __init__(self, hub):
        super().__init__(hub)
        self.active = []   # [(pad id, [players])]
        for pad in self.setting("pads", []):
            self.hotkeys["pad_" + pad["id"]] = (f"Play {pad['name']}", "")

    def on_enable(self):
        if not HAS_AUDIO:
            raise RuntimeError("QtMultimedia missing")
        if not self.setting("seeded"):
            pads = [self._new_pad(name, path) for name, path in make_starter_sounds()]
            self.set_setting("pads", pads)
            self.set_setting("seeded", True)
            for pad in pads:
                self.hotkeys["pad_" + pad["id"]] = (f"Play {pad['name']}", "")

    def on_disable(self):
        self.stop_all()

    def status(self):
        n = len(self.setting("pads", []))
        return f"{n} sounds" + (" · playing" if self.active else "")

    def tray_actions(self):
        return [("Stop all sounds", self.stop_all)] if self.active else []

    def on_hotkey(self, action):
        if action == "stop_all":
            self.stop_all()
            self.notify("Sounds stopped", "")
        elif action.startswith("pad_"):
            pad = next((p for p in self.setting("pads", []) if "pad_" + p["id"] == action), None)
            if pad:
                self.play(pad)

    # ------------------------------------------------------------ playback
    @staticmethod
    def _devices():
        return list(QMediaDevices.audioOutputs())

    def _device(self, desc):
        return next((d for d in self._devices() if d.description() == desc), None)

    def play(self, pad):
        if not os.path.exists(pad["path"]):
            self.notify(f"File missing: {os.path.basename(pad['path'])}", "")
            return
        if self.setting("one_at_a_time", False):
            self.stop_all()
        elif self.setting("restart_same", True):
            self._stop_pad(pad["id"])
        vol = pad.get("volume", 100) / 100
        players = []
        targets = [(None, self.setting("monitor_volume", 80) / 100)]   # None = default speakers
        mic = self.setting("mic_device", "")
        if mic and self._device(mic):
            targets.append((self._device(mic), self.setting("mic_volume", 100) / 100))
        for device, level in targets:
            player = QMediaPlayer(self)
            out = QAudioOutput(device, player) if device else QAudioOutput(player)
            out.setVolume(vol * level)
            player.setAudioOutput(out)
            player.setSource(QUrl.fromLocalFile(pad["path"]))
            player.mediaStatusChanged.connect(lambda st, pid=pad["id"]: st == QMediaPlayer.EndOfMedia and self._finished(pid))
            player.play()
            players.append(player)
        self.active.append((pad["id"], players))
        self._mark()

    def _finished(self, pid):
        self._stop_pad(pid)

    def _stop_pad(self, pid):
        keep = []
        for apid, players in self.active:
            if apid == pid:
                for pl in players:
                    pl.stop()
                    pl.deleteLater()
            else:
                keep.append((apid, players))
        self.active = keep
        self._mark()

    def stop_all(self):
        for _, players in self.active:
            for pl in players:
                pl.stop()
                pl.deleteLater()
        self.active = []
        self._mark()

    def _mark(self):
        if self._page is None:
            return
        playing = {pid for pid, _ in self.active}
        for w in self.pads_widgets:
            w.playing = w.pad["id"] in playing
            w.update()

    # ------------------------------------------------------------ pad editing
    def _new_pad(self, name, path):
        n = len(self.setting("pads", []))
        return {"id": uuid.uuid4().hex[:8], "name": name, "path": path, "volume": 100,
                "color": PAD_COLORS[(n + random.randint(0, 7)) % len(PAD_COLORS)]}

    def add_files(self, paths):
        pads = self.setting("pads", [])
        os.makedirs(SOUND_DIR, exist_ok=True)
        for src in paths:
            dst = os.path.join(SOUND_DIR, os.path.basename(src))
            if os.path.abspath(src) != os.path.abspath(dst):
                try:
                    shutil.copy2(src, dst)   # keep our own copy so moving the original doesn't break the pad
                except OSError:
                    dst = src
            pad = self._new_pad(os.path.splitext(os.path.basename(src))[0].replace("_", " ")[:40], dst)
            pads.append(pad)
            self.hotkeys["pad_" + pad["id"]] = (f"Play {pad['name']}", "")
        self.set_setting("pads", pads)
        self._build_pads()

    def _pick_files(self):
        exts = " ".join("*" + e for e in AUDIO_EXT)
        files, _ = QFileDialog.getOpenFileNames(None, "Add sounds", os.path.expanduser("~/Music"), f"Audio ({exts})")
        if files:
            self.add_files(files)

    def _save(self):
        self.hub.config.save()
        self._build_pads()

    def rename(self, pad):
        name, ok = QInputDialog.getText(None, "Rename", "Name:", text=pad["name"])
        if ok and name.strip():
            pad["name"] = name.strip()[:40]
            self.hotkeys["pad_" + pad["id"]] = (f"Play {pad['name']}", "")
            self._save()

    def edit_volume(self, pad):
        v, ok = QInputDialog.getInt(None, "Volume", f"Volume for {pad['name']} (%):", pad.get("volume", 100), 0, 200)
        if ok:
            pad["volume"] = v
            self._save()

    def cycle_color(self, pad):
        i = PAD_COLORS.index(pad["color"]) if pad.get("color") in PAD_COLORS else -1
        pad["color"] = PAD_COLORS[(i + 1) % len(PAD_COLORS)]
        self._save()

    def edit_hotkey(self, pad):
        dlg = QDialog()
        dlg.setWindowTitle(f"Hotkey for {pad['name']}")
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(20, 18, 20, 18)
        lay.addWidget(ui.label("Click the box, then press your key combo. Backspace clears it.", "muted"))
        edit = self.hotkey_editor("pad_" + pad["id"])
        edit.changed.connect(lambda _: (dlg.accept(), self._build_pads()))
        lay.addWidget(edit)
        dlg.exec()

    def remove(self, pad):
        self._stop_pad(pad["id"])
        self.set_setting("pads", [p for p in self.setting("pads", []) if p["id"] != pad["id"]])
        self.remove_hotkey("pad_" + pad["id"])
        self._build_pads()

    # ------------------------------------------------------------ page
    def create_page(self):
        page = QWidget()
        self._page = page
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)
        self.pads_widgets = []

        top = ui.Card("Your sounds", "")
        top.header.addWidget(ui.button("Stop all", None, "", self.stop_all))
        top.header.addWidget(ui.button("Add sounds", "primary", "", self._pick_files))
        top.add(ui.label("Click a pad to play it. Right-click for a hotkey, rename, volume or colour. "
                         "You can also drag audio files (mp3, wav, ogg…) onto the board.", "muted", wrap=True))
        self.board = Board()
        self.board.dropped.connect(lambda files: files and self.add_files(files))
        top.add(self.board)
        lay.addWidget(top)

        out = ui.Card("Where sounds play", "")
        mon = QSlider(Qt.Horizontal)
        mon.setRange(0, 100)
        mon.setValue(self.setting("monitor_volume", 80))
        mon.valueChanged.connect(lambda v: self.set_setting("monitor_volume", v))
        out.add(ui.hrow(ui.label("Your speakers / headphones"), None, mon))

        dev = QComboBox()
        dev.addItem("Off", "")
        for d in self._devices():
            dev.addItem(d.description(), d.description())
        cur = self.setting("mic_device", "")
        idx = dev.findData(cur)
        dev.setCurrentIndex(max(0, idx))
        dev.currentIndexChanged.connect(lambda _: self.set_setting("mic_device", dev.currentData()))
        dev.setMinimumWidth(260)
        out.add(ui.hrow(ui.label("Also play into (for Discord / games)"), None, dev))
        micv = QSlider(Qt.Horizontal)
        micv.setRange(0, 100)
        micv.setValue(self.setting("mic_volume", 100))
        micv.valueChanged.connect(lambda v: self.set_setting("mic_volume", v))
        out.add(ui.hrow(ui.label("Volume into that device"), None, micv))
        out.add(ui.label(
            "To let friends hear your sounds: install the free <b>VB-Audio Virtual Cable</b>, pick <b>CABLE Input</b> above, "
            "then in Discord set your input device to <b>CABLE Output</b>. (Your real mic then needs to go through the "
            "cable too. In Windows Sound settings → Recording → your mic → Listen, tick 'Listen to this device' "
            "and choose CABLE Input.)", "muted", wrap=True))
        out.add(ui.hrow(ui.button("Get VB-Cable (free)", None, "",
                                  lambda: self.hub.open_url("https://vb-audio.com/Cable/")), None))

        one = ui.ToggleSwitch(self.setting("one_at_a_time", False))
        one.toggled.connect(lambda on: self.set_setting("one_at_a_time", on))
        out.add(ui.hrow(ui.label("Only one sound at a time"), None, one))
        lay.addWidget(out)
        self._build_pads()
        return page

    def _build_pads(self):
        if self._page is None:
            return
        grid = self.board.grid
        while grid.count():
            w = grid.takeAt(0).widget()
            if w:
                w.deleteLater()
        self.pads_widgets = []
        pads = self.setting("pads", [])
        cols = 4
        for i, pad in enumerate(pads):
            w = Pad(self, pad)
            grid.addWidget(w, i // cols, i % cols)
            self.pads_widgets.append(w)
        if not pads:
            grid.addWidget(ui.label("No sounds yet. Click 'Add sounds' or drop files here.", "muted"), 0, 0)
        for c in range(cols):
            grid.setColumnStretch(c, 1)
        self._mark()
