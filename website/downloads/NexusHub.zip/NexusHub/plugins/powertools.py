"""One-click fixes and switches Windows hides in menus (or doesn't have)."""
import ctypes
import os
import re
import socket
import subprocess
import threading
import time
import winreg

import psutil
from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import QComboBox, QGridLayout, QMessageBox, QPushButton, QVBoxLayout, QWidget

from core import ui, win
from core.plugin import Plugin

NO_WINDOW = 0x08000000
ADV_KEY = r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"


def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True, creationflags=NO_WINDOW, errors="replace")


def dir_size(path):
    total = 0
    for root, _, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


class Tile(QPushButton):
    def __init__(self, glyph, title, sub, on_click):
        super().__init__()
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(118)
        self.setStyleSheet(f"QPushButton {{ background:{ui.SURFACE}; border:1px solid {ui.BORDER}; border-radius:14px; "
                           f"text-align:left; padding:14px; }} QPushButton:hover {{ border-color:{ui.ACCENT}; background:{ui.SURFACE2}; }}")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 12, 16, 12)
        lay.setSpacing(4)
        g = ui.glyph_label(glyph, 18, ui.ACCENT2)
        g.setAlignment(Qt.AlignLeft)
        lay.addWidget(g)
        t = ui.label(title, "h2")
        s = ui.label(sub, "muted", wrap=True)
        for w in (g, t, s):
            w.setAttribute(Qt.WA_TransparentForMouseEvents)
        lay.addWidget(t)
        lay.addWidget(s)
        self.clicked.connect(on_click)


class PowerTools(Plugin):
    id = "powertools"
    name = "Power Tools"
    icon = ""
    category = "System"
    order = 70
    description = "Turn the screen off, restart a stuck taskbar, flush DNS, clean junk files, switch power plans and more."
    hotkeys = {
        "screen_off": ("Turn the screen off", "ctrl+alt+shift+s"),
        "lock": ("Lock the PC", ""),
    }
    background_done = Signal(str)

    def __init__(self, hub):
        super().__init__(hub)
        self.background_done.connect(lambda msg: self.notify(msg, ""))

    def status(self):
        up = time.time() - psutil.boot_time()
        d, rem = divmod(int(up), 86400)
        return f"PC on for {d}d {rem // 3600}h" if d else f"PC on for {rem // 3600}h {rem % 3600 // 60}m"

    def tray_actions(self):
        return [("Turn screen off", self.screen_off)]

    def on_hotkey(self, action):
        if action == "screen_off":
            self.screen_off()
        elif action == "lock":
            win.lock_pc()

    # ------------------------------------------------------------ actions
    def screen_off(self):
        QTimer.singleShot(600, win.monitor_off)   # give you time to let go of the keys

    def restart_explorer(self):
        for p in psutil.process_iter(["name"]):
            if (p.info["name"] or "").lower() == "explorer.exe":
                try:
                    p.kill()
                except psutil.Error:
                    pass
        QTimer.singleShot(1200, lambda: subprocess.Popen("explorer.exe", creationflags=NO_WINDOW))
        self.notify("Restarting taskbar & Explorer", "")

    def flush_dns(self):
        ok = run(["ipconfig", "/flushdns"]).returncode == 0
        self.notify("DNS cache cleared" if ok else "Couldn't flush DNS", "")

    def clean_temp(self):
        paths = [os.environ.get("TEMP", ""), os.path.join(os.environ.get("LOCALAPPDATA", ""), "CrashDumps")]
        paths = [p for p in paths if p and os.path.isdir(p)]
        size = sum(dir_size(p) for p in paths)
        if QMessageBox.question(None, "Clean temporary files",
                                f"Delete about {ui.human_bytes(size)} of temporary files older than a day?\n\n"
                                "Files that apps are using right now are skipped.") != QMessageBox.Yes:
            return
        threading.Thread(target=self._clean_worker, args=(paths,), daemon=True).start()
        self.notify("Cleaning in the background…", "")

    def _clean_worker(self, paths):
        freed, cutoff = 0, time.time() - 86400
        for base in paths:
            for root, dirs, files in os.walk(base, topdown=False):
                for f in files:
                    fp = os.path.join(root, f)
                    try:
                        if os.path.getmtime(fp) < cutoff:
                            sz = os.path.getsize(fp)
                            os.remove(fp)
                            freed += sz
                    except OSError:
                        pass
                for d in dirs:
                    try:
                        os.rmdir(os.path.join(root, d))   # only succeeds when empty
                    except OSError:
                        pass
        self.background_done.emit(f"Freed {ui.human_bytes(freed)}")

    def empty_bin(self):
        if QMessageBox.question(None, "Empty Recycle Bin",
                                "Permanently delete everything in the Recycle Bin?") != QMessageBox.Yes:
            return
        ctypes.windll.shell32.SHEmptyRecycleBinW(None, None, 0x7)
        self.notify("Recycle Bin emptied", "")

    def sleep(self):
        if QMessageBox.question(None, "Sleep", "Put the PC to sleep now?") == QMessageBox.Yes:
            ctypes.windll.powrprof.SetSuspendState(False, False, False)

    @staticmethod
    def _adv(name, default):
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, ADV_KEY) as k:
                return winreg.QueryValueEx(k, name)[0]
        except OSError:
            return default

    def _set_adv(self, name, value):
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, ADV_KEY, 0, winreg.KEY_SET_VALUE) as k:
            winreg.SetValueEx(k, name, 0, winreg.REG_DWORD, value)
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)
        self.notify("Changed. Press F5 in open folders", "")

    @staticmethod
    def power_plans():
        plans, active = [], None
        for line in run(["powercfg", "/list"]).stdout.splitlines():
            m = re.search(r"([0-9a-f-]{36})\s+\((.+?)\)(\s*\*)?", line)
            if m:
                plans.append((m.group(2), m.group(1)))
                if m.group(3):
                    active = m.group(1)
        return plans, active

    # ------------------------------------------------------------ page
    def create_page(self):
        page = QWidget()
        self._page = page   # so refresh helpers work while building
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)
        grid = QGridLayout()
        grid.setSpacing(12)
        tiles = [
            ("", "Screen off", "Turns the monitor off without sleeping. Music keeps playing.", self.screen_off),
            ("", "Lock PC", "Lock instantly.", win.lock_pc),
            ("", "Fix taskbar", "Restart Explorer when the taskbar or Start menu freezes.", self.restart_explorer),
            ("", "Flush DNS", "Fixes 'site can't be reached' after network changes.", self.flush_dns),
            ("", "Clean junk", "Delete old temporary files and crash dumps.", self.clean_temp),
            ("", "Empty Recycle Bin", "Free the space used by deleted files.", self.empty_bin),
            ("", "Sleep", "Put the PC to sleep.", self.sleep),
            ("", "God Mode", "Every Windows setting in one folder.", self._god_mode),
            ("", "Startup apps", "Choose what starts with Windows.", lambda: os.startfile("ms-settings:startupapps")),
        ]
        for i, (g, t, s, cb) in enumerate(tiles):
            grid.addWidget(Tile(g, t, s, cb), i // 3, i % 3)
        for c in range(3):
            grid.setColumnStretch(c, 1)
        lay.addLayout(grid)

        sw = ui.Card("Switches", "")
        plans, active = self.power_plans()
        combo = QComboBox()
        for name, guid in plans:
            combo.addItem(name, guid)
            if guid == active:
                combo.setCurrentIndex(combo.count() - 1)
        combo.currentIndexChanged.connect(
            lambda _: (run(["powercfg", "/setactive", combo.currentData()]),
                       self.notify(f"Power plan: {combo.currentText()}", "")))
        sw.add(ui.hrow(ui.label("Power plan"), None, combo))
        hidden = ui.ToggleSwitch(self._adv("Hidden", 2) == 1)
        hidden.toggled.connect(lambda on: self._set_adv("Hidden", 1 if on else 2))
        sw.add(ui.hrow(ui.label("Show hidden files"), None, hidden))
        ext = ui.ToggleSwitch(self._adv("HideFileExt", 1) == 0)
        ext.toggled.connect(lambda on: self._set_adv("HideFileExt", 0 if on else 1))
        sw.add(ui.hrow(ui.label("Show file extensions (.exe, .png…)"), None, ext))
        lay.addWidget(sw)

        info = ui.Card("This PC", "")
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("1.1.1.1", 80))
            ip = s.getsockname()[0]
            s.close()
        except OSError:
            ip = "offline"
        info.add(ui.hrow(ui.label("Computer name", "muted"), None, ui.label(socket.gethostname())))
        info.add(ui.hrow(ui.label("Local IP address", "muted"), None, ui.label(ip)))
        self.uptime = ui.label(self.status())
        info.add(ui.hrow(ui.label("Uptime", "muted"), None, self.uptime))
        lay.addWidget(info)
        return page

    def _god_mode(self):
        os.startfile("shell:::{ED7BA470-8E54-465E-825C-99712043E01C}")
