"""Stop the PC from sleeping (like PowerToys Awake), with a timer."""
import time

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QButtonGroup, QHBoxLayout, QPushButton, QVBoxLayout, QWidget

from core import ui, win
from core.plugin import Plugin

DURATIONS = [("Until I turn it off", 0), ("30 minutes", 30), ("1 hour", 60), ("2 hours", 120), ("4 hours", 240)]


class KeepAwake(Plugin):
    id = "keepawake"
    name = "Keep Awake"
    icon = ""
    category = "System"
    order = 60
    description = "Stop your PC from sleeping or locking during downloads, renders or long videos. Turns itself off on a timer."
    hotkeys = {"toggle": ("Keep awake on / off", "ctrl+alt+shift+a")}

    def __init__(self, hub):
        super().__init__(hub)
        self.active = False
        self.until = 0
        self._timer = QTimer(self, interval=30_000, timeout=self._refresh)

    def on_disable(self):
        self.set_active(False)

    def status(self):
        if not self.active:
            return "Sleep allowed"
        return "Awake " + (f"· {self._remaining()} left" if self.until else "until turned off")

    def tray_actions(self):
        return [("Let PC sleep again" if self.active else "Keep PC awake", lambda: self.on_hotkey("toggle"))]

    def on_hotkey(self, action):
        if action == "toggle":
            self.set_active(not self.active)
            self.notify("Keeping PC awake" if self.active else "PC can sleep again")

    def _remaining(self):
        secs = max(0, int(self.until - time.time()))
        h, m = divmod(secs // 60, 60)
        return f"{h}h {m:02d}m" if h else f"{m} min"

    def set_active(self, on):
        self.active = on
        if on:
            minutes = self.setting("minutes", 0)
            self.until = time.time() + minutes * 60 if minutes else 0
            win.keep_awake(True, display=self.setting("display", True))
            self._timer.start()
        else:
            self.until = 0
            win.keep_awake(False)
            self._timer.stop()
        self._refresh()

    def _refresh(self):
        if self.active and self.until and time.time() >= self.until:
            self.set_active(False)
            self.notify("Keep Awake timer finished")
            return
        if self._page is None:
            return
        self.big.setText("Awake" if self.active else "Sleeping normally")
        self.sub.setText(self.status())
        self.btn.setText("  Turn off" if self.active else "  Keep my PC awake")
        self.btn.setProperty("kind", "danger" if self.active else "primary")
        self.btn.style().unpolish(self.btn)
        self.btn.style().polish(self.btn)

    def create_page(self):
        page = QWidget()
        self._page = page   # so refresh helpers work while building
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)
        card = ui.Card()
        self.big = ui.label("", "big")
        self.sub = ui.label("", "muted")
        self.btn = ui.button("", "primary", "", lambda: self.set_active(not self.active))
        self.btn.setMinimumHeight(44)
        card.add(self.big)
        card.add(self.sub)
        card.lay.addSpacing(8)
        card.add(ui.hrow(self.btn, None))
        lay.addWidget(card)

        opts = ui.Card("How long", "")
        group = QButtonGroup(page)
        row = QHBoxLayout()
        for text, minutes in DURATIONS:
            b = QPushButton(text, checkable=True)
            b.setChecked(self.setting("minutes", 0) == minutes)
            b.setStyleSheet(f"QPushButton:checked {{ background:{ui.ACCENT}; border:none; color:white; }}")
            b.clicked.connect(lambda _=False, m=minutes: self._set_minutes(m))
            group.addButton(b)
            row.addWidget(b)
        row.addStretch()
        opts.add(row)
        disp = ui.ToggleSwitch(self.setting("display", True))
        disp.toggled.connect(self._set_display)
        opts.add(ui.hrow(ui.label("Keep the screen on too"), None, disp))
        lay.addWidget(opts)
        self._refresh()
        return page

    def _set_minutes(self, m):
        self.set_setting("minutes", m)
        if self.active:
            self.set_active(True)

    def _set_display(self, on):
        self.set_setting("display", on)
        if self.active:
            self.set_active(True)
