"""Custom crosshair overlay for games (click-through, always on top)."""
from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QGuiApplication, QPainter, QPen
from PySide6.QtWidgets import QButtonGroup, QColorDialog, QHBoxLayout, QPushButton, QSlider, QVBoxLayout, QWidget

from core import ui
from core.plugin import Plugin

STYLES = ["cross", "dot", "circle", "cross_dot", "t"]
STYLE_NAMES = {"cross": "Cross", "dot": "Dot", "circle": "Circle", "cross_dot": "Cross + dot", "t": "T-shape"}
DEFAULTS = {"style": "cross", "color": "#00ff88", "size": 10, "thickness": 2, "gap": 4, "outline": True, "opacity": 100}


def draw_crosshair(p, c, s):
    """Paint crosshair settings `s` centred on point `c`."""
    color = QColor(s["color"])
    color.setAlpha(int(255 * s["opacity"] / 100))
    size, th, gap = s["size"], s["thickness"], s["gap"]
    style = s["style"]
    shapes = []   # ("line", x1, y1, x2, y2) | ("dot", r) | ("circle", r)
    if style in ("cross", "cross_dot", "t"):
        arms = [(0, -1), (0, 1), (-1, 0), (1, 0)] if style != "t" else [(0, 1), (-1, 0), (1, 0)]
        for dx, dy in arms:
            shapes.append(("line", c.x() + dx * gap, c.y() + dy * gap, c.x() + dx * (gap + size), c.y() + dy * (gap + size)))
    if style in ("dot", "cross_dot"):
        shapes.append(("dot", max(1.0, th * (1.2 if style == "dot" else 0.8))))
    if style == "circle":
        shapes.append(("circle", size))
        shapes.append(("dot", max(1.0, th * 0.7)))
    passes = [(QColor(0, 0, 0, color.alpha()), th + 2)] if s["outline"] else []
    passes.append((color, th))
    for col, width in passes:
        for sh in shapes:
            if sh[0] == "line":
                p.setPen(QPen(col, width, Qt.SolidLine, Qt.FlatCap))
                p.drawLine(QPointF(sh[1], sh[2]), QPointF(sh[3], sh[4]))
            elif sh[0] == "dot":
                p.setPen(Qt.NoPen)
                p.setBrush(col)
                p.drawEllipse(c, sh[1] + (width - th) / 2, sh[1] + (width - th) / 2)
            else:
                p.setBrush(Qt.NoBrush)
                p.setPen(QPen(col, width))
                p.drawEllipse(c, sh[1], sh[1])


class Overlay(QWidget):
    def __init__(self, plugin):
        super().__init__(None, Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint
                         | Qt.WindowTransparentForInput | Qt.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.plugin = plugin
        self.place()

    def place(self):
        geo = QGuiApplication.primaryScreen().geometry()
        side = 200
        off = self.plugin.setting("offset", [0, 0])
        self.setGeometry(geo.center().x() - side // 2 + off[0], geo.center().y() - side // 2 + off[1], side, side)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        draw_crosshair(p, QPointF(self.width() / 2, self.height() / 2), self.plugin.style())


class Preview(QWidget):
    def __init__(self, plugin):
        super().__init__()
        self.plugin = plugin
        self.setFixedSize(220, 160)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect())
        g = QColor("#3b4a5c")
        p.setBrush(g)
        p.setPen(Qt.NoPen)
        p.drawRoundedRect(r, 12, 12)
        p.setBrush(QColor("#6b7f5a"))
        p.drawRect(QRectF(0, r.height() * 0.62, r.width(), r.height() * 0.38))   # fake "ground" to judge contrast
        draw_crosshair(p, r.center(), self.plugin.style())


class Crosshair(Plugin):
    id = "crosshair"
    name = "Crosshair"
    icon = ""
    category = "Gaming"
    order = 45
    description = "Draw your own crosshair over games that hide it or snipers without scopes. Click-through and adjustable."
    hotkeys = {"toggle": ("Show / hide crosshair", "ctrl+alt+shift+c")}

    def __init__(self, hub):
        super().__init__(hub)
        self.overlay = None

    def style(self):
        return {**DEFAULTS, **self.setting("style", {})}

    def on_enable(self):
        if self.setting("visible", False):
            self.show_overlay(True)

    def on_disable(self):
        self.show_overlay(False)

    def status(self):
        return "Showing" if self.overlay else "Hidden"

    def tray_actions(self):
        return [("Hide crosshair" if self.overlay else "Show crosshair", lambda: self.on_hotkey("toggle"))]

    def on_hotkey(self, action):
        if action == "toggle":
            on = self.overlay is None
            self.show_overlay(on)
            self.set_setting("visible", on)
            self.notify("Crosshair on" if on else "Crosshair off")

    def show_overlay(self, on):
        if on and not self.overlay:
            self.overlay = Overlay(self)
            self.overlay.show()
        elif not on and self.overlay:
            self.overlay.close()
            self.overlay = None
        if self._page is not None:
            self.vis.blockSignals(True)
            self.vis.setChecked(self.overlay is not None)
            self.vis.blockSignals(False)

    def _set(self, key, value):
        st = self.setting("style", {})
        st[key] = value
        self.set_setting("style", st)
        self.preview.update()
        if self.overlay:
            self.overlay.update()

    def _nudge(self, dx, dy):
        off = self.setting("offset", [0, 0])
        off = [0, 0] if dx == dy == 0 else [off[0] + dx, off[1] + dy]
        self.set_setting("offset", off)
        if self.overlay:
            self.overlay.place()
        self.off_lbl.setText(f"Offset {off[0]}, {off[1]} px")

    def create_page(self):
        page = QWidget()
        self._page = page
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)
        s = self.style()

        card = ui.Card()
        row = QHBoxLayout()
        row.setSpacing(24)
        self.preview = Preview(self)
        row.addWidget(self.preview)
        col = QVBoxLayout()
        self.vis = ui.ToggleSwitch(self.overlay is not None)
        self.vis.toggled.connect(lambda on: (self.show_overlay(on), self.set_setting("visible", on)))
        col.addLayout(ui.hrow(ui.label("Show crosshair", "h2"), None, self.vis))
        col.addWidget(ui.label("Works over games in windowed or borderless mode (not exclusive fullscreen). "
                               "It only draws on screen and doesn't touch the game, but check your game's rules if you "
                               "play ranked.", "muted", wrap=True))
        group = QButtonGroup(page)
        styles = QHBoxLayout()
        for st in STYLES:
            b = QPushButton(STYLE_NAMES[st], checkable=True)
            b.setChecked(s["style"] == st)
            b.setStyleSheet(f"QPushButton:checked {{ background:{ui.ACCENT}; border:none; color:white; }}")
            b.clicked.connect(lambda _=False, st=st: self._set("style", st))
            group.addButton(b)
            styles.addWidget(b)
        styles.addStretch()
        col.addLayout(styles)
        col.addStretch()
        row.addLayout(col, 1)
        card.add(row)
        lay.addWidget(card)

        tune = ui.Card("Look", "")
        for key, text, lo, hi in (("size", "Length", 2, 60), ("thickness", "Thickness", 1, 8),
                                  ("gap", "Centre gap", 0, 30), ("opacity", "Opacity", 20, 100)):
            sl = QSlider(Qt.Horizontal)
            sl.setRange(lo, hi)
            sl.setValue(s[key])
            sl.setFixedWidth(300)
            sl.valueChanged.connect(lambda v, k=key: self._set(k, v))
            tune.add(ui.hrow(ui.label(text), None, sl))
        colors = QHBoxLayout()
        for c in ("#00ff88", "#ff3b3b", "#00e5ff", "#ffea00", "#ff4dff", "#ffffff"):
            b = QPushButton()
            b.setFixedSize(30, 30)
            b.setCursor(Qt.PointingHandCursor)
            b.setStyleSheet(f"background:{c}; border-radius:15px; border:2px solid #0d0f14;")
            b.clicked.connect(lambda _=False, c=c: self._set("color", c))
            colors.addWidget(b)
        colors.addWidget(ui.button("Custom…", "ghost", on_click=self._pick_color))
        colors.addStretch()
        tune.add(ui.hrow(ui.label("Colour"), None, colors))
        outline = ui.ToggleSwitch(s["outline"])
        outline.toggled.connect(lambda on: self._set("outline", on))
        tune.add(ui.hrow(ui.label("Black outline (easier to see)"), None, outline))
        lay.addWidget(tune)

        pos = ui.Card("Position", "")
        off = self.setting("offset", [0, 0])
        self.off_lbl = ui.label(f"Offset {off[0]}, {off[1]} px", "muted")
        pos.add(ui.label("Some games aim a little off-centre. Nudge it pixel by pixel.", "muted"))
        pos.add(ui.hrow(ui.button("←", None, on_click=lambda: self._nudge(-1, 0)),
                        ui.button("↑", None, on_click=lambda: self._nudge(0, -1)),
                        ui.button("↓", None, on_click=lambda: self._nudge(0, 1)),
                        ui.button("→", None, on_click=lambda: self._nudge(1, 0)),
                        ui.button("Centre", "ghost", on_click=lambda: self._nudge(0, 0)),
                        None, self.off_lbl))
        lay.addWidget(pos)
        return page

    def _pick_color(self):
        c = QColorDialog.getColor(QColor(self.style()["color"]), None, "Crosshair colour")
        if c.isValid():
            self._set("color", c.name())
