"""Superpowers for any window: always-on-top, see-through, centre, force-close."""
import psutil
from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QHBoxLayout, QListWidget, QListWidgetItem, QMessageBox, QSlider, QVBoxLayout, QWidget

from core import ui, win
from core.plugin import Plugin


class WindowTools(Plugin):
    id = "windowtools"
    name = "Window Tools"
    icon = ""
    category = "Desktop"
    order = 50
    description = "Pin any window on top, make it see-through, centre it, or force-close a frozen app, all with hotkeys."
    hotkeys = {
        "pin": ("Pin / unpin the active window on top", "ctrl+alt+t"),
        "more_opaque": ("Make active window more solid", "ctrl+alt+pageup"),
        "less_opaque": ("Make active window more see-through", "ctrl+alt+pagedown"),
        "center": ("Centre the active window", "ctrl+alt+c"),
        "kill": ("Force close the active app", "ctrl+alt+shift+k"),
    }
    PROTECTED = {"explorer.exe", "dwm.exe", "csrss.exe", "winlogon.exe", "python.exe", "pythonw.exe"}

    def __init__(self, hub):
        super().__init__(hub)
        self.pinned = set()

    def on_disable(self):
        # unpin anything we pinned so windows go back to normal
        for hwnd in list(self.pinned):
            if win.user32.IsWindow(hwnd):
                win.set_topmost(hwnd, False)
        self.pinned.clear()

    def status(self):
        n = sum(1 for h in self.pinned if win.user32.IsWindow(h))
        return f"{n} window(s) pinned" if n else "Ready"

    def _target(self):
        hwnd = win.foreground()
        if not hwnd or win.is_desktop_or_shell(hwnd):
            self.notify("Click a window first", "")
            return None
        return hwnd

    def on_hotkey(self, action):
        hwnd = self._target()
        if not hwnd:
            return
        name = win.title(hwnd)[:48] or win.process_name(hwnd)
        if action == "pin":
            on = not win.is_topmost(hwnd)
            self._pin(hwnd, on)
            self.hub.osd.show_message("Pinned on top" if on else "Unpinned", "" if on else "", sub=name)
        elif action in ("more_opaque", "less_opaque"):
            step = 25 if action == "more_opaque" else -25
            alpha = max(40, min(255, win.get_opacity(hwnd) + step))
            win.set_opacity(hwnd, alpha)
            self.hub.osd.show_message(f"Opacity  {round(alpha / 2.55)}%", "", value=alpha / 255)
        elif action == "center":
            win.center_window(hwnd)
            self.notify("Centred", "")
        elif action == "kill":
            self._kill(hwnd, confirm=False)
        self._refresh_page()

    def _pin(self, hwnd, on):
        win.set_topmost(hwnd, on)
        (self.pinned.add if on else self.pinned.discard)(hwnd)

    def _kill(self, hwnd, confirm=True):
        pid = win.pid_of(hwnd)
        try:
            proc = psutil.Process(pid)
            pname = proc.name()
        except psutil.Error:
            return
        if pname.lower() in self.PROTECTED:
            self.notify(f"Won't close {pname}, Windows needs it", "")
            return
        if confirm and QMessageBox.question(None, "Force close", f"Force close {pname}? Unsaved work will be lost.") != QMessageBox.Yes:
            return
        try:
            proc.kill()
            self.notify(f"Force closed {pname}", "")
        except psutil.Error:
            self.notify(f"Couldn't close {pname} (try running as admin)", "")

    # ------------------------------------------------------------ page
    def create_page(self):
        page = QWidget()
        self._page = page   # so refresh helpers work while building
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)

        how = ui.Card("How it works", "")
        how.add(ui.label("Click any window, then press a hotkey. Or pick a window below and use the buttons. "
                         "You can change the hotkeys in Settings.", "muted", wrap=True))
        for action, (text, _) in self.hotkeys.items():
            combo = self.hub.combo_for(self, action)
            how.add(ui.hrow(ui.label(text), None, ui.label(ui.hotkeys.pretty(combo), "pill")))
        lay.addWidget(how)

        card = ui.Card("Open windows", "")
        card.header.addWidget(ui.button("Refresh", "ghost", "", self._refresh_page))
        self.list = QListWidget()
        self.list.setMinimumHeight(300)
        self.list.currentItemChanged.connect(lambda *_: self._sync_controls())
        card.add(self.list)
        self.opacity = QSlider(Qt.Horizontal)
        self.opacity.setRange(15, 100)
        self.opacity.valueChanged.connect(self._opacity_changed)
        self.btn_pin = ui.button("Pin on top", None, "", self._toggle_pin_selected)
        card.add(ui.hrow(ui.label("See-through"), self.opacity, self.btn_pin,
                         ui.button("Centre", None, "", lambda: self._with_selected(win.center_window)),
                         ui.button("Force close", "danger", "", lambda: self._with_selected(self._kill))))
        lay.addWidget(card)
        self._refresh_page()
        return page

    def _selected(self):
        it = self.list.currentItem() if self._page is not None else None
        if not it:
            return None
        hwnd = it.data(Qt.UserRole)
        return hwnd if win.user32.IsWindow(hwnd) else None

    def _with_selected(self, fn):
        hwnd = self._selected()
        if hwnd:
            fn(hwnd)
            QTimer.singleShot(300, self._refresh_page)

    def _toggle_pin_selected(self):
        hwnd = self._selected()
        if hwnd:
            self._pin(hwnd, not win.is_topmost(hwnd))
            self._refresh_page()

    def _opacity_changed(self, v):
        hwnd = self._selected()
        if hwnd:
            win.set_opacity(hwnd, v * 2.55)

    def _sync_controls(self):
        hwnd = self._selected()
        self.opacity.setEnabled(bool(hwnd))
        self.btn_pin.setEnabled(bool(hwnd))
        if hwnd:
            self.opacity.blockSignals(True)
            self.opacity.setValue(round(win.get_opacity(hwnd) / 2.55))
            self.opacity.blockSignals(False)
            self.btn_pin.setText("Unpin" if win.is_topmost(hwnd) else "Pin on top")

    def _refresh_page(self):
        if self._page is None:
            return
        keep = self._selected()
        self.list.blockSignals(True)
        self.list.clear()
        for hwnd in win.app_windows():
            pinned = win.is_topmost(hwnd)
            alpha = win.get_opacity(hwnd)
            tags = ("   📌" if pinned else "") + (f"   {round(alpha / 2.55)}%" if alpha < 255 else "")
            it = QListWidgetItem(f"{win.title(hwnd)[:80]}   ·   {win.process_name(hwnd)}{tags}")
            it.setData(Qt.UserRole, hwnd)
            self.list.addItem(it)
            if hwnd == keep:
                self.list.setCurrentItem(it)
        self.list.blockSignals(False)
        self._sync_controls()
