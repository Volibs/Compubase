"""Game Mode: when a game starts, tune the PC for it; undo everything when you stop playing."""
import os
import re
import subprocess

import psutil
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QComboBox, QInputDialog, QListWidget, QSlider, QVBoxLayout, QWidget
from PySide6.QtCore import Qt

from core import audio, ui, win
from core.plugin import Plugin

NO_WINDOW = 0x08000000
# fullscreen apps that aren't games
NOT_GAMES = {"chrome.exe", "msedge.exe", "firefox.exe", "opera.exe", "brave.exe", "vlc.exe", "mpc-hc64.exe",
             "wmplayer.exe", "video.ui.exe", "applicationframehost.exe", "powerpnt.exe", "explorer.exe",
             "spotify.exe", "discord.exe", "obs64.exe", "pythonw.exe", "python.exe", "photos.exe", "mspaint.exe"}
KNOWN_GAMES = {"deadlock.exe", "project8.exe", "discovery.exe", "cs2.exe", "valorant-win64-shipping.exe",
               "fortniteclient-win64-shipping.exe", "r5apex.exe", "r5apex_dx12.exe", "minecraft.exe",
               "leagueoflegends.exe", "overwatch.exe", "rocketleague.exe", "gta5.exe", "eldenring.exe",
               "cod.exe", "robloxplayerbeta.exe", "dota2.exe", "rainbowsix.exe", "marvel-win64-shipping.exe"}


def power_plans():
    out = subprocess.run(["powercfg", "/list"], capture_output=True, text=True, creationflags=NO_WINDOW,
                         errors="replace").stdout
    plans, active = [], None
    for line in out.splitlines():
        m = re.search(r"([0-9a-f-]{36})\s+\((.+?)\)(\s*\*)?", line)
        if m:
            plans.append((m.group(2), m.group(1)))
            if m.group(3):
                active = m.group(1)
    return plans, active


def set_plan(guid):
    subprocess.run(["powercfg", "/setactive", guid], creationflags=NO_WINDOW)


class GameMode(Plugin):
    id = "gamemode"
    name = "Game Mode"
    icon = ""
    category = "Gaming"
    order = 44
    description = "Detects when you start a game and switches to max performance, boosts the game, turns down Spotify and more. Undone when you quit."
    hotkeys = {"toggle": ("Game Mode on / off", "ctrl+alt+g")}

    def __init__(self, hub):
        super().__init__(hub)
        self.active = False
        self.manual = False
        self.game = None          # (pid, exe name)
        self._saved = {}
        self._seen = 0
        self._ignore_pid = None
        self._timer = QTimer(self, interval=2000, timeout=self._watch)

    def on_enable(self):
        self._timer.start()

    def on_disable(self):
        self._timer.stop()
        if self.active:
            self.deactivate()

    def status(self):
        if self.active:
            return f"ON · {self.game[1] if self.game else 'manual'}"
        return "Watching for games" if self.setting("auto", True) else "Manual only"

    def tray_actions(self):
        return [("Game Mode off" if self.active else "Game Mode on", lambda: self.on_hotkey("toggle"))]

    def on_hotkey(self, action):
        if action == "toggle":
            if self.active:
                # switched off by hand: don't auto-enable again for this same game session
                self._ignore_pid = self.game[0] if self.game else win.pid_of(win.foreground())
                self.deactivate()
            else:
                self.manual = True
                fg = win.foreground()
                self.activate((win.pid_of(fg), win.process_name(fg).lower()) if fg and not win.is_desktop_or_shell(fg) else None)

    # ------------------------------------------------------------ detection
    def _is_game(self, name):
        name = name.lower()
        if name in {g.lower() for g in self.setting("games", [])} or name in KNOWN_GAMES:
            return True
        return False

    def _watch(self):
        if self.active:
            if self.game and not psutil.pid_exists(self.game[0]):
                self.deactivate()   # the game closed
            self._refresh_page()
            return
        if not self.setting("auto", True) or self.manual:
            return
        fg = win.foreground()
        if not fg or win.is_desktop_or_shell(fg):
            self._seen = 0
            return
        if win.pid_of(fg) == self._ignore_pid:
            return
        name = win.process_name(fg).lower()
        game = self._is_game(name) or (self.setting("fullscreen_detect", True) and name not in NOT_GAMES
                                       and win.foreground_is_fullscreen())
        self._seen = self._seen + 1 if game else 0
        if self._seen >= 2:          # ~4 s, so alt-tabbing through a fullscreen video doesn't trigger it
            self.activate((win.pid_of(fg), name))

    # ------------------------------------------------------------ boost / restore
    def activate(self, game):
        if self.active:
            return
        self.active, self.game, self._saved = True, game, {}
        done = []
        if self.setting("power", True):
            plans, current = power_plans()
            best = next((g for n, g in plans if "ultimate" in n.lower()), None) or \
                next((g for n, g in plans if "high" in n.lower()), None)
            if best and best != current:
                self._saved["plan"] = current
                set_plan(best)
                done.append("max performance")
        if self.setting("priority", True) and game:
            try:
                proc = psutil.Process(game[0])
                self._saved["priority"] = (game[0], proc.nice())
                proc.nice(psutil.HIGH_PRIORITY_CLASS)
                done.append("game boosted")
            except psutil.Error:
                pass
        if self.setting("spotify_vol", 40) < 100:
            vol = audio.app_volume("spotify.exe")
            if vol:
                self._saved["spotify"] = vol.GetMasterVolume()
                vol.SetMasterVolume(self.setting("spotify_vol", 40) / 100, None)
                done.append(f"Spotify {self.setting('spotify_vol', 40)}%")
        for pid, setting, default in (("sysmonitor", "overlay", False), ("crosshair", "crosshair", False)):
            p = self.hub.by_id.get(pid)
            if p and p.enabled and self.setting(setting, default):
                if pid == "sysmonitor" and not p.overlay:
                    p._show_overlay(True)
                    self._saved["overlay"] = True
                    done.append("stats overlay")
                elif pid == "crosshair" and not p.overlay:
                    p.show_overlay(True)
                    self._saved["crosshair"] = True
                    done.append("crosshair")
        if self.setting("keepawake", True):
            win.keep_awake(True, display=True)
            self._saved["awake"] = True
        if self.setting("hide_widgets", True):
            w = self.hub.by_id.get("widgets")
            if w and w.enabled and w.shown:
                w.hide_all()
                self._saved["widgets"] = True
        self.hub.osd.show_message(f"Game Mode ON" + (f" · {game[1]}" if game else ""), self.icon,
                                  sub=", ".join(done) or "ready")
        self._refresh_page()

    def deactivate(self):
        s = self._saved
        if "plan" in s and s["plan"]:
            set_plan(s["plan"])
        if "priority" in s:
            try:
                psutil.Process(s["priority"][0]).nice(s["priority"][1])
            except psutil.Error:
                pass
        if "spotify" in s:
            vol = audio.app_volume("spotify.exe")
            if vol:
                vol.SetMasterVolume(s["spotify"], None)
        if s.get("overlay"):
            p = self.hub.by_id.get("sysmonitor")
            if p and p.enabled and not p.setting("overlay", False):
                p._show_overlay(False)
        if s.get("crosshair"):
            p = self.hub.by_id.get("crosshair")
            if p and p.enabled and not p.setting("visible", False):
                p.show_overlay(False)
        if s.get("awake"):
            ka = self.hub.by_id.get("keepawake")
            if not (ka and ka.enabled and ka.active):
                win.keep_awake(False)
        if s.get("widgets"):
            w = self.hub.by_id.get("widgets")
            if w and w.enabled and not w.setting("hidden", False):
                w.show_all()
        self.active, self.game, self._saved, self._seen = False, None, {}, 0
        # wait for the foreground to change before auto-detecting again
        self.manual = False
        self.notify("Game Mode off. Everything restored", self.icon)
        self._refresh_page()

    # ------------------------------------------------------------ page
    def create_page(self):
        page = QWidget()
        self._page = page
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)
        top = ui.Card()
        self.big = ui.label("", "big")
        self.sub = ui.label("", "muted")
        self.btn = ui.button("", "primary", self.icon, lambda: self.on_hotkey("toggle"))
        self.btn.setMinimumHeight(42)
        top.add(ui.hrow(self.big, None, self.btn))
        top.add(self.sub)
        lay.addWidget(top)

        det = ui.Card("Detect games", "")
        auto = ui.ToggleSwitch(self.setting("auto", True))
        auto.toggled.connect(lambda on: self.set_setting("auto", on))
        det.add(ui.hrow(ui.label("Turn on automatically when a game starts"), None, auto))
        fs = ui.ToggleSwitch(self.setting("fullscreen_detect", True))
        fs.toggled.connect(lambda on: self.set_setting("fullscreen_detect", on))
        det.add(ui.hrow(ui.label("Treat any fullscreen app as a game (browsers & video players are ignored)"), None, fs))
        det.add(ui.label("Your games (always detected, even in windowed mode):", "muted"))
        self.games = QListWidget()
        self.games.setMaximumHeight(130)
        det.add(self.games)
        det.add(ui.hrow(ui.button("Add running game…", None, "", self._add_running),
                        ui.button("Remove", "ghost", "", self._remove_game), None))
        lay.addWidget(det)

        act = ui.Card("While gaming", "")
        for key, text, default in (("power", "Switch to the High/Ultimate performance power plan", True),
                                   ("priority", "Give the game high CPU priority", True),
                                   ("keepawake", "Keep the screen from sleeping", True),
                                   ("hide_widgets", "Hide desktop widgets", True),
                                   ("overlay", "Show the stats overlay (FPS-style CPU/RAM box)", False),
                                   ("crosshair", "Show the crosshair", False)):
            sw = ui.ToggleSwitch(self.setting(key, default))
            sw.toggled.connect(lambda on, k=key: self.set_setting(k, on))
            act.add(ui.hrow(ui.label(text), None, sw))
        sv = QSlider(Qt.Horizontal)
        sv.setRange(0, 100)
        sv.setValue(self.setting("spotify_vol", 40))
        sv.setFixedWidth(260)
        lbl = ui.label(f"{sv.value()}%", "h2")
        sv.valueChanged.connect(lambda v: (self.set_setting("spotify_vol", v), lbl.setText(f"{v}%")))
        act.add(ui.hrow(ui.label("Lower Spotify to (100% = leave it)"), None, sv, lbl))
        act.add(ui.label("Everything goes back to how it was when you quit the game or press the hotkey.", "muted"))
        lay.addWidget(act)
        self._fill_games()
        self._refresh_page()
        return page

    def _fill_games(self):
        self.games.clear()
        for g in self.setting("games", []):
            self.games.addItem(g)

    def _add_running(self):
        names = sorted({win.process_name(h) for h in win.app_windows()} - {""}, key=str.lower)
        name, ok = QInputDialog.getItem(None, "Add a game", "Pick the game's process (start the game first):", names, 0, False)
        if ok and name:
            self.set_setting("games", sorted(set(self.setting("games", [])) | {name}))
            self._fill_games()

    def _remove_game(self):
        it = self.games.currentItem()
        if it:
            self.set_setting("games", [g for g in self.setting("games", []) if g != it.text()])
            self._fill_games()

    def _refresh_page(self):
        if self._page is None:
            return
        self.big.setText("Game Mode is ON 🎮" if self.active else "Game Mode is off")
        self.sub.setText((f"Boosting {self.game[1]}" if self.game else "Turned on by hand") if self.active else
                         "It'll switch on by itself when you launch a game.")
        self.btn.setText("  Turn off" if self.active else "  Turn on now")
