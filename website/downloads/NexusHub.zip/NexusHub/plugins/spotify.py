"""Control Spotify from anywhere with hotkeys, even while gaming."""
import os
import threading
import urllib.request
import uuid

import psutil
from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QConicalGradient, QDesktopServices, QGuiApplication, QPainter, QPixmap, QRadialGradient
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton, QSlider, QVBoxLayout, QWidget

from core import audio, spotify_ui, ui, win
from core.config import APP_DIR
from core.plugin import Plugin
from core.spotify_api import REDIRECT, SpotifyAPI, SpotifyError, oembed, parse_link

CACHE = os.path.join(APP_DIR, "cache")
KIND_LABEL = {"track": "Song", "album": "Album", "playlist": "Playlist", "artist": "Artist",
              "episode": "Episode", "show": "Podcast"}

APPCOMMAND = {"play_pause": 14, "next": 11, "prev": 12}
MEDIA_VK = {"play_pause": 0xB3, "next": 0xB0, "prev": 0xB1}
IDLE_TITLES = {"spotify", "spotify premium", "spotify free"}


class Disc(QWidget):
    """A spinning record that stands in for album art."""

    def __init__(self):
        super().__init__()
        self.setFixedSize(150, 150)
        self.angle = 0.0
        self.playing = False
        self._timer = QTimer(self, interval=33, timeout=self._spin)

    def set_playing(self, on):
        self.playing = on
        if on and self.isVisible():
            self._timer.start()
        elif not on:
            self._timer.stop()
        self.update()

    def showEvent(self, e):
        if self.playing:
            self._timer.start()

    def hideEvent(self, e):
        self._timer.stop()

    def _spin(self):
        self.angle = (self.angle + 1.6) % 360
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        c = QPointF(75, 75)
        p.translate(c)
        p.rotate(self.angle)
        p.translate(-c)
        g = QConicalGradient(c, 0)
        for stop, col in ((0, "#1b1f2a"), (0.25, "#2d3346"), (0.5, "#1b1f2a"), (0.75, "#2d3346"), (1, "#1b1f2a")):
            g.setColorAt(stop, QColor(col))
        p.setPen(Qt.NoPen)
        p.setBrush(g)
        p.drawEllipse(c, 74, 74)
        p.setPen(QColor(255, 255, 255, 14))
        p.setBrush(Qt.NoBrush)
        for r in range(34, 72, 5):
            p.drawEllipse(c, r, r)
        rg = QRadialGradient(c, 30)
        rg.setColorAt(0, QColor("#1ed760"))
        rg.setColorAt(1, QColor(ui.ACCENT))
        p.setPen(Qt.NoPen)
        p.setBrush(rg)
        p.drawEllipse(c, 28, 28)
        p.setBrush(QColor(ui.BG))
        p.drawEllipse(c, 4, 4)


class Spotify(Plugin):
    id = "spotify"
    name = "Spotify Hotkeys"
    icon = ""
    category = "Media"
    order = 10
    description = "Play, skip and change Spotify's own volume from anywhere with global hotkeys, even in fullscreen games."
    hotkeys = {
        "play_pause": ("Play / Pause", "ctrl+alt+p"),
        "next": ("Next track", "ctrl+alt+right"),
        "prev": ("Previous track", "ctrl+alt+left"),
        "vol_up": ("Spotify volume up", "ctrl+alt+up"),
        "vol_down": ("Spotify volume down", "ctrl+alt+down"),
        "mute": ("Mute Spotify", "ctrl+alt+m"),
        "now": ("Show what's playing", "ctrl+alt+n"),
        # these need "Connect Spotify" on the Spotify page
        "like": ("Like / unlike the current song", "ctrl+alt+l"),
        "shuffle": ("Shuffle on / off", "ctrl+alt+h"),
        "seek_fwd": ("Jump forward 15 s", "ctrl+alt+shift+right"),
        "seek_back": ("Jump back 15 s", "ctrl+alt+shift+left"),
    }
    api_msg = Signal(str, str)      # text, glyph: shown as a popup from background threads
    favs_changed = Signal()
    conn_changed = Signal()

    def __init__(self, hub):
        super().__init__(hub)
        self.api = SpotifyAPI(self.settings.setdefault("api", {}), hub.config.save)
        self.api_msg.connect(lambda text, glyph: self.notify(text, glyph))
        self.favs_changed.connect(self._build_favs)
        self.conn_changed.connect(self._refresh_conn)
        for fav in self.setting("favorites", []):
            self.hotkeys["fav_" + fav["id"]] = (f"Play {fav['name']}", "")
        self.hwnd = None
        self.track = ""          # "Artist - Song" or "" when paused/closed
        self.running = False
        self._scan_wait = 0
        self._timer = QTimer(self, interval=1000, timeout=self._poll)

    # ------------------------------------------------------------ lifecycle
    def on_enable(self):
        self._poll()
        self._timer.start()

    def on_disable(self):
        self._timer.stop()

    def status(self):
        if not self.running:
            return "Spotify isn't open"
        return "♪ " + self.track if self.track else "Paused"

    def tray_actions(self):
        return [("Play / Pause", lambda: self.on_hotkey("play_pause")),
                ("Next track", lambda: self.on_hotkey("next"))]

    # ------------------------------------------------------------ spotify
    def _find_window(self):
        pids = {p.pid for p in psutil.process_iter(["name"]) if (p.info["name"] or "").lower() == "spotify.exe"}
        if not pids:
            return None
        for hwnd in win.enum_windows(visible_only=False):
            if win.pid_of(hwnd) not in pids:
                continue
            t = win.title(hwnd)
            if t and win.class_name(hwnd).startswith("Chrome_WidgetWin") and not t.startswith(("GDI+", "Default IME", "MSCTFIME")):
                return hwnd
        return None

    def _poll(self):
        if not (self.hwnd and win.user32.IsWindow(self.hwnd)):
            self.hwnd = None
            if self._scan_wait > 0:   # don't rescan processes every second when Spotify is closed
                self._scan_wait -= 1
            else:
                self.hwnd = self._find_window()
                self._scan_wait = 0 if self.hwnd else 4
        self.running = self.hwnd is not None
        title = win.title(self.hwnd) if self.hwnd else ""
        track = "" if title.lower() in IDLE_TITLES else title
        if track != self.track:
            self.track = track
            if track and self.setting("popup_on_change", True):
                artist, _, song = track.partition(" - ")
                self.hub.osd.show_message(song or track, "", sub=artist if song else "")
            self._refresh_page()
        elif self._page is not None and self._page.isVisible() and not self.slider.isSliderDown():
            self._refresh_page()

    def _command(self, action):
        if self.hwnd and self.setting("direct", True):
            win.user32.SendMessageW(self.hwnd, win.WM_APPCOMMAND, 0, APPCOMMAND[action] << 16)
        else:
            win.press_key(MEDIA_VK[action])

    def _volume(self):
        return audio.app_volume("spotify.exe")

    def _spotify_mute(self):
        if not self.hwnd or self.setting("volume_mode", "spotify") != "spotify":
            return False
        try:
            muted = spotify_ui.toggle_mute(self.hwnd)
        except Exception:
            muted = None
        if muted is None:
            return False
        self.notify("Spotify muted" if muted else "Spotify unmuted", "" if muted else "")
        return True

    def spotify_volume(self):
        """Spotify's own volume (0..1) from its slider, or None if it can't be read."""
        return spotify_ui.get_volume(self.hwnd) if self.hwnd else None

    def change_volume(self, delta=None, absolute=None):
        # Preferred: move Spotify's OWN volume slider (what you see inside Spotify), in 10% steps
        if self.hwnd and self.setting("volume_mode", "spotify") == "spotify":
            try:
                if absolute is not None:
                    new = spotify_ui.set_volume(self.hwnd, absolute)
                else:
                    new = spotify_ui.step_volume(self.hwnd, 1 if delta > 0 else -1)
                if new is not None:
                    return new
            except Exception:
                pass
        # Fallback: Spotify's volume in the Windows mixer
        vol = self._volume()
        if not vol:
            self.notify("Spotify isn't playing any audio yet", "")
            return
        cur = vol.GetMasterVolume()
        new = absolute if absolute is not None else max(0.0, min(1.0, cur + delta))
        vol.SetMasterVolume(new, None)
        if new > 0:
            vol.SetMute(0, None)
        return new

    # ------------------------------------------------------------ hotkeys
    # ------------------------------------------------------------ web api (background threads)
    def _bg(self, fn):
        def run():
            try:
                fn()
            except SpotifyError as e:
                self.api_msg.emit(str(e), "")
            except OSError:
                self.api_msg.emit("Couldn't reach Spotify. Are you online?", "")
        threading.Thread(target=run, daemon=True).start()

    def _need_api(self):
        if not self.api.connected:
            self.notify("Connect Spotify on the Spotify page first", "")
            return False
        return True

    def play_fav(self, fav):
        uri = fav["uri"]
        shuffle = fav.get("shuffle", fav.get("kind") in ("album", "playlist", "artist"))
        if self.api.connected:
            def go():
                self.api.play_uri(uri, shuffle=shuffle)
                self.api_msg.emit(f"Playing {fav['name']}" + (" · shuffled" if shuffle else ""), "" if shuffle else "")
            self._bg(go)
            return
        # No API: open the page, then press its Shuffle + Play buttons through UI Automation.
        # Remember how things looked first, so Spotify can be tucked away again once the music starts.
        h = self.hwnd
        self._restore = {"prev": win.foreground(), "was_running": bool(h),
                         "visible": bool(h and win.user32.IsWindowVisible(h)),
                         "iconic": bool(h and win.user32.IsIconic(h))}
        if not self.hwnd:
            try:
                os.startfile(uri)   # launches Spotify; give it a moment before we look for buttons
            except OSError:
                self.notify("Couldn't open Spotify", "")
                return
            QTimer.singleShot(4000, lambda: (self._poll(), self._ui_play(fav, shuffle, tries=14, opened=True)))
        else:
            os.startfile(uri)
            QTimer.singleShot(500, lambda: self._ui_play(fav, shuffle, tries=14))
        self.hub.osd.show_message(fav["name"], "", sub="Starting…")

    def _put_back(self):
        """Tuck Spotify away again (tray / minimised / behind) and return focus to what you were doing."""
        r = getattr(self, "_restore", None)
        self._restore = None
        if not r or not self.setting("stay_hidden", True) or not self.hwnd:
            return
        h = self.hwnd
        if not r["was_running"] or r["iconic"]:
            win.user32.ShowWindow(h, 7)          # SW_SHOWMINNOACTIVE: minimised, without stealing focus
        elif not r["visible"]:
            win.user32.ShowWindow(h, 0)          # it lived in the tray before: hide it again
        prev = r["prev"]
        if prev and prev != h and win.user32.IsWindow(prev):
            win.focus(prev)

    def _ui_player_button(self, action):
        """Like / shuffle through the player bar's own buttons (no Web API needed)."""
        if not self.hwnd:
            self.notify("Spotify isn't open", "")
            return
        song = self.track.partition(" - ")[2] or self.track
        try:
            btns = spotify_ui.buttons(self.hwnd)
        except Exception:
            btns = []
        if action == "like":
            for name, el in btns:
                if name in ("Add to Liked Songs", "Remove from Liked Songs"):
                    spotify_ui.invoke(el)
                    self.notify("Liked ♥" if name.startswith("Add") else "Removed from Liked Songs",
                                "" if name.startswith("Add") else "")
                    return
        else:
            for name, el in btns:
                if song and name in (f"Enable Shuffle for {song}", f"Disable Shuffle for {song}"):
                    spotify_ui.invoke(el)
                    self.notify("Shuffle on" if name.startswith("Enable") else "Shuffle off", "")
                    return
        self.notify("Play something in Spotify first", "")

    def _ui_play(self, fav, shuffle, tries, opened=False):
        if opened and not self.hwnd:
            self._poll()
        if not self.hwnd:
            self.notify("Spotify didn't open", "")
            return
        try:
            c = spotify_ui.page_controls(self.hwnd, fav["name"])
        except Exception:
            c = None
        if not c or not c["play"]:
            if tries > 0:
                QTimer.singleShot(500, lambda: self._ui_play(fav, shuffle, tries - 1))
            else:
                self.hub.osd.show_message(fav["name"], "", sub="Opened in Spotify. Press play there")
            return
        try:
            if shuffle and c["shuffle_off"] is not None:
                spotify_ui.invoke(c["shuffle_off"])
            elif not shuffle and c["shuffle_on"] is not None:
                spotify_ui.invoke(c["shuffle_on"])
        except Exception:
            pass
        # Spotify re-draws the page after a shuffle click, so look the Play button up again before pressing it
        QTimer.singleShot(300, lambda: self._ui_press_play(fav, shuffle, tries=6))

    def _ui_press_play(self, fav, shuffle, tries):
        try:
            c = spotify_ui.page_controls(self.hwnd, fav["name"]) if self.hwnd else None
            if c and c["play"]:
                name, button = c["play"]
                if name.startswith("Pause") or spotify_ui.invoke(button):
                    self.hub.osd.show_message(fav["name"], "" if shuffle else "",
                                              sub="Playing on shuffle" if shuffle else "Playing")
                    QTimer.singleShot(1200, self._poll)
                    QTimer.singleShot(400, self._put_back)     # music is playing: tuck Spotify away again
                    return
        except Exception:
            pass
        if tries > 0:
            QTimer.singleShot(300, lambda: self._ui_press_play(fav, shuffle, tries - 1))
        else:
            self.hub.osd.show_message(fav["name"], "", sub="Opened in Spotify. Press play there")

    def on_hotkey(self, action):
        if action.startswith("fav_"):
            fav = next((f for f in self.setting("favorites", []) if "fav_" + f["id"] == action), None)
            if fav:
                self.play_fav(fav)
            return
        if action in ("like", "shuffle") and not self.api.connected:
            self._ui_player_button(action)
            return
        if action == "like" and self._need_api():
            def like():
                liked, name = self.api.toggle_like()
                self.api_msg.emit(f"{'Liked' if liked else 'Removed from Liked'}: {name}", "" if liked else "")
            self._bg(like)
            return
        if action == "shuffle" and self._need_api():
            self._bg(lambda: self.api_msg.emit("Shuffle on" if self.api.toggle_shuffle() else "Shuffle off", ""))
            return
        if action in ("seek_fwd", "seek_back") and self._need_api():
            secs = 15 if action == "seek_fwd" else -15
            self._bg(lambda: (self.api.seek_by(secs), self.api_msg.emit(
                "Forward 15 s" if secs > 0 else "Back 15 s", "" if secs > 0 else "")))
            return
        if action in APPCOMMAND:
            if not self.running and self.setting("direct", True):
                self.notify("Spotify isn't open", "")
                return
            self._command(action)
            glyph = {"play_pause": "", "next": "", "prev": ""}[action]
            if action == "play_pause":
                self.notify("Paused" if self.track else "Playing", glyph)
            else:
                self.notify("Next track" if action == "next" else "Previous track", glyph)
            QTimer.singleShot(700, self._poll)
        elif action in ("vol_up", "vol_down"):
            step = self.setting("step", 10) / 100
            new = self.change_volume(step if action == "vol_up" else -step)
            if new is not None:
                self.hub.osd.show_message(f"Spotify volume  {round(new * 100)}%", "", value=new)
                self._refresh_page()
        elif action == "mute" and self._spotify_mute():
            pass                                   # handled by Spotify's own mute button
        elif action == "mute":
            vol = self._volume()
            if vol:
                muted = not vol.GetMute()
                vol.SetMute(int(muted), None)
                self.notify("Spotify muted" if muted else "Spotify unmuted", "" if muted else "")
        elif action == "now":
            if self.track:
                artist, _, song = self.track.partition(" - ")
                self.hub.osd.show_message(song or self.track, "", sub=artist)
            else:
                self.notify("Nothing playing" if self.running else "Spotify isn't open", "")

    # ------------------------------------------------------------ page
    def create_page(self):
        page = QWidget()
        self._page = page   # so refresh helpers work while building
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)

        now = ui.Card()
        row = QHBoxLayout()
        row.setSpacing(24)
        self.disc = Disc()
        row.addWidget(self.disc)
        col = QVBoxLayout()
        col.setSpacing(4)
        col.addStretch()
        self.lbl_state = ui.label("", "muted")
        self.lbl_song = ui.label("", "big")
        self.lbl_artist = ui.label("", "muted")
        self.lbl_artist.setStyleSheet("font-size:15px;")
        col.addWidget(self.lbl_state)
        col.addWidget(self.lbl_song)
        col.addWidget(self.lbl_artist)
        col.addSpacing(10)
        controls = ui.hrow(
            ui.button("", None, "", lambda: self.on_hotkey("prev")),
            ui.button("  Play / Pause", "primary", "", lambda: self.on_hotkey("play_pause")),
            ui.button("", None, "", lambda: self.on_hotkey("next")),
            None,
            ui.button("Open Spotify", "ghost", "", self._open_spotify))
        col.addLayout(controls)
        col.addStretch()
        row.addLayout(col, 1)
        now.add(row)
        lay.addWidget(now)

        vol_card = ui.Card("Spotify volume", "")
        vol_card.add(ui.label("Moves Spotify's own volume slider (in 10% steps). Your game and Discord stay the same.",
                              "muted", wrap=True))
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(0, 10)                     # Spotify's slider moves in 10% notches
        self.slider.setPageStep(1)
        self.slider.valueChanged.connect(lambda v: self.lbl_vol.setText(f"{v * 10}%"))
        # talk to Spotify only when you let go (or click/scroll), not on every pixel of a drag
        self.slider.sliderReleased.connect(lambda: self.change_volume(absolute=self.slider.value() / 10))
        self.slider.actionTriggered.connect(
            lambda a: a not in (QSlider.SliderMove, QSlider.SliderNoAction) and
            QTimer.singleShot(0, lambda: self.change_volume(absolute=self.slider.value() / 10)))
        self.lbl_vol = ui.label("", "h2")
        self.lbl_vol.setFixedWidth(52)
        vol_card.add(ui.hrow(self.slider, self.lbl_vol))
        lay.addWidget(vol_card)

        opts = ui.Card("Options", "")
        popup = ui.ToggleSwitch(self.setting("popup_on_change", True))
        popup.toggled.connect(lambda on: self.set_setting("popup_on_change", on))
        opts.add(ui.hrow(ui.label("Show a popup when the song changes"), None, popup))
        direct = ui.ToggleSwitch(self.setting("direct", True))
        direct.toggled.connect(lambda on: self.set_setting("direct", on))
        opts.add(ui.hrow(ui.label("Send controls straight to Spotify (off = normal media keys)"), None, direct))
        hide = ui.ToggleSwitch(self.setting("stay_hidden", True))
        hide.toggled.connect(lambda on: self.set_setting("stay_hidden", on))
        opts.add(ui.hrow(ui.label("Keep Spotify out of sight when a favourite starts (it goes back where it was)"), None, hide))

        favs = ui.Card("Quick-play favourites", "")
        favs.add(ui.label("Paste a Spotify link to a song, album or playlist (in Spotify: Share → Copy link), "
                          "then give it a hotkey. Press it anywhere to start that music.", "muted", wrap=True))
        self.link = QLineEdit(placeholderText="https://open.spotify.com/album/…")
        self.link.returnPressed.connect(self._add_fav)
        favs.add(ui.hrow(self.link, ui.button("Paste", None, "", self._paste_link),
                         ui.button("Add", "primary", "", self._add_fav)))
        self.fav_box = QVBoxLayout()
        self.fav_box.setSpacing(8)
        favs.add(self.fav_box)

        conn = ui.Card("Connect Spotify (optional, even faster)", "")
        self.conn_status = ui.label("", "muted", wrap=True)
        conn.add(self.conn_status)
        self.conn_steps = QWidget()
        sl = QVBoxLayout(self.conn_steps)
        sl.setContentsMargins(0, 0, 0, 0)
        sl.addWidget(ui.label(
            "Unlocks instant play for favourites, plus Like, Shuffle and ±15 s hotkeys. One-time setup, about 2 minutes:<br>"
            "1. Open the Spotify developer dashboard and log in, then click <b>Create app</b>.<br>"
            f"2. Any name/description. Redirect URI: <b>{REDIRECT}</b>. Tick <b>Web API</b>, then save.<br>"
            "3. Copy the app's <b>Client ID</b>, paste it below and press Connect.", "muted", wrap=True))
        self.client_id = QLineEdit(placeholderText="Client ID", text=self.api.store.get("client_id", ""))
        sl.addLayout(ui.hrow(
            ui.button("Open dashboard", None, "",
                      lambda: QDesktopServices.openUrl(QUrl("https://developer.spotify.com/dashboard"))),
            ui.button("Copy redirect URI", None, "",
                      lambda: (QGuiApplication.clipboard().setText(REDIRECT), self.notify("Copied", ""))),
            None))
        self.btn_connect = ui.button("Connect", "primary", "", self._connect)
        sl.addLayout(ui.hrow(self.client_id, self.btn_connect))
        conn.add(self.conn_steps)
        self.btn_disconnect = ui.button("Disconnect", "ghost", "", self._disconnect)
        conn.add(ui.hrow(None, self.btn_disconnect))
        lay.addWidget(favs)
        lay.addWidget(conn)
        lay.addWidget(opts)
        self._refresh_conn()
        self._build_favs()
        self._refresh_page()
        return page

    # ------------------------------------------------------------ favourites
    def _paste_link(self):
        self.link.setText(QGuiApplication.clipboard().text().strip())
        self._add_fav()

    def _add_fav(self):
        uri = parse_link(self.link.text())
        if not uri:
            self.notify("That doesn't look like a Spotify link", "")
            return
        if any(f["uri"] == uri for f in self.setting("favorites", [])):
            self.notify("Already in your favourites")
            return
        self.link.clear()
        fid = uuid.uuid4().hex[:8]
        kind = uri.split(":")[1]
        fav = {"id": fid, "uri": uri, "name": KIND_LABEL.get(kind, kind).title() + " (loading name…)", "kind": kind}
        self.set_setting("favorites", self.setting("favorites", []) + [fav])
        self.add_hotkey("fav_" + fid, f"Play {fav['name']}")
        self._build_favs()

        def fetch():   # look up the real name + cover art in the background
            try:
                name, thumb = oembed(uri)
            except OSError:
                name, thumb = uri, ""
            fav["name"] = name or uri
            if thumb:
                os.makedirs(CACHE, exist_ok=True)
                try:
                    req = urllib.request.Request(thumb, headers={"User-Agent": "NexusHub"})
                    with urllib.request.urlopen(req, timeout=10) as r, open(os.path.join(CACHE, fid + ".jpg"), "wb") as f:
                        f.write(r.read())
                except OSError:
                    pass
            self.hub.config.save()
            self.favs_changed.emit()
        threading.Thread(target=fetch, daemon=True).start()

    def _remove_fav(self, fid):
        self.set_setting("favorites", [f for f in self.setting("favorites", []) if f["id"] != fid])
        self.remove_hotkey("fav_" + fid)
        try:
            os.remove(os.path.join(CACHE, fid + ".jpg"))
        except OSError:
            pass
        self._build_favs()

    def _build_favs(self):
        if self._page is None:
            return
        while self.fav_box.count():
            item = self.fav_box.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        favs = self.setting("favorites", [])
        if not favs:
            empty = ui.label("No favourites yet.", "muted")
            self.fav_box.addWidget(empty)
            return
        for fav in favs:
            self.hotkeys["fav_" + fav["id"]] = (f"Play {fav['name']}", "")
            row = QFrame()
            row.setStyleSheet(f"QFrame {{ background:{ui.SURFACE2}; border-radius:10px; }}")
            rl = QHBoxLayout(row)
            rl.setContentsMargins(8, 8, 10, 8)
            art = QLabel()
            art.setFixedSize(44, 44)
            pm = QPixmap(os.path.join(CACHE, fav["id"] + ".jpg"))
            if not pm.isNull():
                art.setPixmap(pm.scaled(44, 44, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation))
            else:
                art.setText("")
                art.setFont(ui.icon_font(18))
                art.setAlignment(Qt.AlignCenter)
            art.setStyleSheet("background:#262c3d; border-radius:6px;")
            rl.addWidget(art)
            col = QVBoxLayout()
            col.setSpacing(0)
            col.addWidget(ui.label(fav["name"], "h2"))
            col.addWidget(ui.label(KIND_LABEL.get(fav.get("kind"), ""), "muted"))
            rl.addLayout(col, 1)
            if fav.get("kind") in ("album", "playlist", "artist"):
                sh = QPushButton(checkable=True)
                sh.setChecked(fav.get("shuffle", True))
                sh.setIcon(ui.glyph_icon("", "white"))
                sh.setToolTip("Play on shuffle")
                sh.setFixedWidth(44)
                sh.setStyleSheet(f"QPushButton:checked {{ background:{ui.ACCENT}; border:none; }}")
                sh.toggled.connect(lambda on, f=fav: (f.__setitem__("shuffle", on), self.hub.config.save()))
                rl.addWidget(sh)
            rl.addWidget(self.hotkey_editor("fav_" + fav["id"]))
            rl.addWidget(ui.button("", None, "", lambda _=False, f=fav: self.play_fav(f)))
            rl.addWidget(ui.button("", "ghost", "", lambda _=False, fid=fav["id"]: self._remove_fav(fid)))
            self.fav_box.addWidget(row)

    # ------------------------------------------------------------ connect
    def _connect(self):
        cid = self.client_id.text().strip()
        if len(cid) < 20:
            self.notify("Paste your app's Client ID first", "")
            return
        self.btn_connect.setEnabled(False)
        self.conn_status.setText("Finish logging in in your browser…")

        def go():
            try:
                user = self.api.login(cid)
                self.api_msg.emit(f"Connected to Spotify as {user}", "")
            finally:
                self.conn_changed.emit()
        self._bg(go)

    def _disconnect(self):
        self.api.disconnect()
        self._refresh_conn()

    def _refresh_conn(self):
        if self._page is None:
            return
        on = self.api.connected
        self.btn_connect.setEnabled(True)
        self.conn_steps.setVisible(not on)
        self.btn_disconnect.setVisible(on)
        self.conn_status.setText(f"✔ Connected as {self.api.store.get('user', 'you')}. Favourites play instantly; "
                                 "Like, Shuffle and ±15 s hotkeys work." if on else
                                 "Not connected. That's fine: favourites still play (NexusHub opens them in Spotify and presses "
                                 "Shuffle + Play for you). Connecting makes it instant and unlocks Like / Shuffle / ±15 s hotkeys.")

    def _open_spotify(self):
        try:
            os.startfile("spotify:")
        except OSError:
            self.notify("Couldn't find Spotify", "")

    def _refresh_page(self):
        if self._page is None:
            return
        if not self.running:
            self.lbl_state.setText("NOT RUNNING")
            self.lbl_song.setText("Spotify is closed")
            self.lbl_artist.setText("Open it and your hotkeys will just work.")
        elif self.track:
            artist, _, song = self.track.partition(" - ")
            self.lbl_state.setText("NOW PLAYING")
            self.lbl_song.setText(song or self.track)
            self.lbl_artist.setText(artist if song else "")
        else:
            self.lbl_state.setText("PAUSED")
            self.lbl_song.setText("Nothing playing")
            self.lbl_artist.setText("Press Play or your hotkey.")
        self.disc.set_playing(bool(self.track))
        cur = self.spotify_volume()
        if cur is None:
            vol = self._volume()
            cur = vol.GetMasterVolume() if vol is not None else None
        self.slider.setEnabled(cur is not None)
        if cur is not None and not self.slider.isSliderDown():
            v = round(cur * 10)
            self.slider.blockSignals(True)
            self.slider.setValue(v)
            self.slider.blockSignals(False)
            self.lbl_vol.setText(f"{v * 10}%")
        elif cur is None:
            self.lbl_vol.setText("–")
