"""Extra-dim screen, warm night filter, and automatic dark/light mode."""
import ctypes
import datetime
import winreg

from PySide6.QtCore import Qt, QTime, QTimer
from PySide6.QtGui import QColor, QGuiApplication, QPainter
from PySide6.QtWidgets import QComboBox, QSlider, QTimeEdit, QVBoxLayout, QWidget

from core import ui, win
from core.plugin import Plugin

THEME_KEY = r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"


def is_dark():
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, THEME_KEY) as k:
            return winreg.QueryValueEx(k, "AppsUseLightTheme")[0] == 0
    except OSError:
        return False


def set_dark(on):
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, THEME_KEY, 0, winreg.KEY_SET_VALUE) as k:
        for name in ("AppsUseLightTheme", "SystemUsesLightTheme"):
            winreg.SetValueEx(k, name, 0, winreg.REG_DWORD, 0 if on else 1)
    # tell open apps (Explorer, Settings…) to repaint with the new theme
    res = ctypes.c_size_t()
    area = ctypes.create_unicode_buffer("ImmersiveColorSet")
    win.user32.SendMessageTimeoutW(win.HWND(0xFFFF), 0x001A, 0, ctypes.addressof(area), 0x2, 200, ctypes.byref(res))


ADV = r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
SEARCH = r"Software\Microsoft\Windows\CurrentVersion\Search"
DEV = r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\TaskbarDeveloperSettings"


def reg_get(path, name, default=None):
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, path) as k:
            return winreg.QueryValueEx(k, name)[0]
    except OSError:
        return default


def reg_set(path, name, value):
    with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, path, 0, winreg.KEY_SET_VALUE) as k:
        winreg.SetValueEx(k, name, 0, winreg.REG_DWORD, int(value))
    res = ctypes.c_size_t()
    area = ctypes.create_unicode_buffer("TraySettings")
    win.user32.SendMessageTimeoutW(win.HWND(0xFFFF), 0x001A, 0, ctypes.addressof(area), 0x2, 300, ctypes.byref(res))


class APPBARDATA(ctypes.Structure):
    _fields_ = [("cbSize", ctypes.c_uint), ("hWnd", ctypes.c_void_p), ("uCallbackMessage", ctypes.c_uint),
                ("uEdge", ctypes.c_uint), ("rc", ctypes.c_long * 4), ("lParam", ctypes.c_ssize_t)]


_SHELL32 = ctypes.WinDLL("shell32")


def taskbar_autohide(on=None):
    """Read (on=None) or set the taskbar auto-hide state, the same switch Settings uses."""
    abd = APPBARDATA()
    abd.cbSize = ctypes.sizeof(abd)
    shell = _SHELL32       # private handle, so this can't clash with the Nexus Dock's own settings
    shell.SHAppBarMessage.restype = ctypes.c_size_t
    shell.SHAppBarMessage.argtypes = [ctypes.c_uint, ctypes.POINTER(APPBARDATA)]
    state = shell.SHAppBarMessage(0x4, ctypes.byref(abd))       # ABM_GETSTATE
    if on is None:
        return bool(state & 0x1)
    abd.lParam = (state & ~0x1) | (0x1 if on else 0)
    shell.SHAppBarMessage(0xA, ctypes.byref(abd))                # ABM_SETSTATE
    return on


def in_window(now, start, end):
    """True if time `now` is inside [start, end), handling windows that cross midnight."""
    return start <= now < end if start < end else now >= start or now < end


class Shade(QWidget):
    """Click-through tint over one monitor."""

    def __init__(self, screen, plugin):
        super().__init__(None, Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint
                         | Qt.WindowTransparentForInput | Qt.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.plugin = plugin
        self.setGeometry(screen.geometry())

    def paintEvent(self, _):
        p = QPainter(self)
        dim, warm = self.plugin.dim, self.plugin.warm_now()
        if warm:
            p.fillRect(self.rect(), QColor(255, 130, 20, int(warm * 1.1)))
        if dim:
            p.fillRect(self.rect(), QColor(0, 0, 0, int(dim * 2.3)))


class Display(Plugin):
    id = "display"
    name = "Display"
    icon = ""
    category = "Desktop"
    order = 25
    description = "Dim your screen below Windows' minimum, add a warm night filter, and switch dark/light mode on a schedule."
    hotkeys = {
        "dim_more": ("Dim screen more", "ctrl+alt+shift+pagedown"),
        "dim_less": ("Dim screen less", "ctrl+alt+shift+pageup"),
        "night": ("Night filter on / off", "ctrl+alt+shift+n"),
        "theme": ("Switch dark / light mode", "ctrl+alt+shift+d"),
    }

    def __init__(self, hub):
        super().__init__(hub)
        self.shades = []
        self.dim = 0
        self._last_auto = None
        self._timer = QTimer(self, interval=30_000, timeout=self._tick)
        self._raise = QTimer(self, interval=4000, timeout=self._keep_on_top)

    def on_enable(self):
        self.dim = self.setting("dim", 0)
        self._timer.start()
        self._tick()
        app = QGuiApplication.instance()
        app.screenAdded.connect(self._rebuild)
        app.screenRemoved.connect(self._rebuild)

    def on_disable(self):
        self._timer.stop()
        self._clear()
        app = QGuiApplication.instance()
        for sig in (app.screenAdded, app.screenRemoved):
            try:
                sig.disconnect(self._rebuild)
            except (RuntimeError, TypeError):
                pass

    def status(self):
        bits = []
        if self.dim:
            bits.append(f"Dimmed {self.dim}%")
        if self.warm_now():
            bits.append("Night filter")
        bits.append("Dark mode" if is_dark() else "Light mode")
        return " · ".join(bits)

    def tray_actions(self):
        return [("Night filter off" if self.setting("night", False) else "Night filter on", lambda: self.on_hotkey("night")),
                ("Switch to light mode" if is_dark() else "Switch to dark mode", lambda: self.on_hotkey("theme"))]

    # ------------------------------------------------------------ logic
    def warm_now(self):
        if self.setting("night", False):
            return self.setting("warmth", 40)
        if self.setting("night_auto", False) and self._in_dark_hours():
            return self.setting("warmth", 40)
        return 0

    def _in_dark_hours(self):
        now = datetime.datetime.now().strftime("%H:%M")
        return in_window(now, self.setting("dark_from", "19:00"), self.setting("light_from", "07:00"))

    def _tick(self):
        if self.setting("auto_theme", False):
            want_dark = self._in_dark_hours()
            # only act when the schedule flips, so a manual switch sticks until the next change
            if want_dark != self._last_auto:
                self._last_auto = want_dark
                if want_dark != is_dark():
                    set_dark(want_dark)
        self._apply()

    def _apply(self):
        need = self.dim > 0 or self.warm_now() > 0
        if need and not self.shades:
            self._rebuild()
        elif not need and self.shades:
            self._clear()
        for s in self.shades:
            s.update()
        self._refresh_page()

    def _rebuild(self, *_):
        self._clear()
        if self.dim > 0 or self.warm_now() > 0:
            for screen in QGuiApplication.screens():
                s = Shade(screen, self)
                s.show()
                self.shades.append(s)
            self._raise.start()

    def _clear(self):
        self._raise.stop()
        for s in self.shades:
            s.close()
            s.deleteLater()
        self.shades = []

    def _keep_on_top(self):
        # the taskbar/start menu can pop above us, so push back to the top now and then
        for s in self.shades:
            win.set_topmost(int(s.winId()), True)

    def set_dim(self, v):
        self.dim = max(0, min(90, int(v)))
        self.set_setting("dim", self.dim)
        self._apply()

    def on_hotkey(self, action):
        if action in ("dim_more", "dim_less"):
            self.set_dim(self.dim + (10 if action == "dim_more" else -10))
            self.hub.osd.show_message(f"Extra dim  {self.dim}%", "", value=self.dim / 90)
        elif action == "night":
            on = not self.setting("night", False)
            self.set_setting("night", on)
            self._apply()
            self.notify("Night filter on" if on else "Night filter off", "")
        elif action == "theme":
            dark = not is_dark()
            set_dark(dark)
            self.notify("Dark mode" if dark else "Light mode", "" if dark else "")
            self._refresh_page()

    # ------------------------------------------------------------ page
    def create_page(self):
        page = QWidget()
        self._page = page
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)

        dim = ui.Card("Extra dim", "")
        dim.add(ui.label("Goes darker than the brightness slider allows. Great for late nights. "
                         "It's an overlay, so it also works on monitors without brightness control.", "muted", wrap=True))
        self.dim_slider = QSlider(Qt.Horizontal)
        self.dim_slider.setRange(0, 90)
        self.dim_slider.setValue(self.dim)
        self.dim_slider.valueChanged.connect(self.set_dim)
        self.dim_lbl = ui.label("", "h2")
        self.dim_lbl.setFixedWidth(50)
        dim.add(ui.hrow(self.dim_slider, self.dim_lbl))
        lay.addWidget(dim)

        night = ui.Card("Night filter", "")
        night.add(ui.label("A warm orange tint that's easier on the eyes at night, adjustable way past Windows Night Light.",
                           "muted", wrap=True))
        self.night_sw = ui.ToggleSwitch(self.setting("night", False))
        self.night_sw.toggled.connect(lambda on: (self.set_setting("night", on), self._apply()))
        night.add(ui.hrow(ui.label("Night filter on"), None, self.night_sw))
        warm = QSlider(Qt.Horizontal)
        warm.setRange(5, 100)
        warm.setValue(self.setting("warmth", 40))
        warm.setFixedWidth(300)
        warm.valueChanged.connect(lambda v: (self.set_setting("warmth", v), self._apply()))
        night.add(ui.hrow(ui.label("Warmth"), None, warm))
        auto_night = ui.ToggleSwitch(self.setting("night_auto", False))
        auto_night.toggled.connect(lambda on: (self.set_setting("night_auto", on), self._apply()))
        night.add(ui.hrow(ui.label("Turn on automatically during dark hours (below)"), None, auto_night))
        lay.addWidget(night)

        theme = ui.Card("Dark / light mode", "")
        self.theme_lbl = ui.label("", "h2")
        theme.add(ui.hrow(self.theme_lbl, None, ui.button("Switch now", "primary", "", lambda: self.on_hotkey("theme"))))
        auto = ui.ToggleSwitch(self.setting("auto_theme", False))
        auto.toggled.connect(lambda on: (self.set_setting("auto_theme", on), setattr(self, "_last_auto", None), self._tick()))
        theme.add(ui.hrow(ui.label("Switch automatically on a schedule"), None, auto))
        t_dark = QTimeEdit(QTime.fromString(self.setting("dark_from", "19:00"), "HH:mm"))
        t_dark.setDisplayFormat("HH:mm")
        t_dark.timeChanged.connect(lambda t: (self.set_setting("dark_from", t.toString("HH:mm")), setattr(self, "_last_auto", None)))
        t_light = QTimeEdit(QTime.fromString(self.setting("light_from", "07:00"), "HH:mm"))
        t_light.setDisplayFormat("HH:mm")
        t_light.timeChanged.connect(lambda t: (self.set_setting("light_from", t.toString("HH:mm")), setattr(self, "_last_auto", None)))
        theme.add(ui.hrow(ui.label("Dark from"), t_dark, ui.label("   Light from"), t_light, None))
        lay.addWidget(theme)
        lay.addWidget(self._taskbar_card())
        self._refresh_page()
        return page

    def _taskbar_card(self):
        card = ui.Card("Taskbar", "")
        card.add(ui.label("Customise the Windows taskbar. Changes apply right away; if one doesn't, use "
                          "Power Tools → Fix taskbar to refresh it.", "muted", wrap=True))
        align = QComboBox()
        align.addItem("Centre (Windows 11 style)", 1)
        align.addItem("Left (classic)", 0)
        align.setCurrentIndex(0 if reg_get(ADV, "TaskbarAl", 1) == 1 else 1)
        align.currentIndexChanged.connect(lambda _: self._tb(ADV, "TaskbarAl", align.currentData(), "Taskbar aligned"))
        card.add(ui.hrow(ui.label("Icon alignment"), None, align))

        search = QComboBox()
        for text, v in (("Hidden", 0), ("Icon only", 1), ("Search box", 2), ("Icon and label", 3)):
            search.addItem(text, v)
        search.setCurrentIndex(max(0, search.findData(reg_get(SEARCH, "SearchboxTaskbarMode", 2))))
        search.currentIndexChanged.connect(
            lambda _: self._tb(SEARCH, "SearchboxTaskbarMode", search.currentData(), "Search button updated"))
        card.add(ui.hrow(ui.label("Search on the taskbar"), None, search))

        for path, name, text, default, on_val in (
                (ADV, "ShowTaskViewButton", "Task View button", 1, 1),
                (ADV, "ShowSecondsInSystemClock", "Show seconds on the taskbar clock", 0, 1),
                (DEV, "TaskbarEndTask", "Add 'End task' when you right-click an app on the taskbar", 0, 1)):
            sw = ui.ToggleSwitch(reg_get(path, name, default) == on_val)
            sw.toggled.connect(lambda on, p=path, n=name, t=text: self._tb(p, n, 1 if on else 0, t + (" on" if on else " off")))
            card.add(ui.hrow(ui.label(text), None, sw))

        ah = ui.ToggleSwitch(taskbar_autohide())
        ah.toggled.connect(lambda on: (taskbar_autohide(on), self.notify("Taskbar auto-hide " + ("on" if on else "off"), "")))
        card.add(ui.hrow(ui.label("Auto-hide the taskbar (more room for games and videos)"), None, ah))
        return card

    def _tb(self, path, name, value, msg):
        try:
            reg_set(path, name, value)
            self.notify(msg, "")
        except OSError:
            self.notify("Windows blocked that change", "")

    def _refresh_page(self):
        if self._page is None:
            return
        self.dim_lbl.setText(f"{self.dim}%")
        if self.dim_slider.value() != self.dim:
            self.dim_slider.blockSignals(True)
            self.dim_slider.setValue(self.dim)
            self.dim_slider.blockSignals(False)
        self.night_sw.blockSignals(True)
        self.night_sw.setChecked(self.setting("night", False))
        self.night_sw.blockSignals(False)
        self.theme_lbl.setText("Windows is in dark mode" if is_dark() else "Windows is in light mode")
