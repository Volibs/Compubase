"""Clipboard history with pins and a pop-up picker."""
from PySide6.QtCore import QEvent, QPoint, Qt, QTimer
from PySide6.QtGui import QCursor, QGuiApplication
from PySide6.QtWidgets import (QFrame, QLineEdit, QListWidget, QListWidgetItem, QVBoxLayout, QWidget)

from core import ui, win
from core.plugin import Plugin

MAX_ITEMS = 60


class Picker(QFrame):
    """Pop-up list at the mouse. Type to search, Enter/click to paste."""

    def __init__(self, plugin):
        super().__init__(None, Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint)
        self.plugin = plugin
        self.setObjectName("card")
        self.setFixedSize(420, 460)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 12, 12, 12)
        self.search = QLineEdit(placeholderText="Search clipboard…")
        self.search.textChanged.connect(self.fill)
        self.search.installEventFilter(self)
        self.list = QListWidget()
        self.list.itemActivated.connect(self._pick)
        self.list.itemClicked.connect(self._pick)
        lay.addWidget(self.search)
        lay.addWidget(self.list)
        lay.addWidget(ui.label("Enter to paste · Esc to close", "muted"))
        self.target = None

    def popup(self, target):
        self.target = target
        self.search.clear()
        self.fill()
        pos = QCursor.pos()
        geo = (QGuiApplication.screenAt(pos) or QGuiApplication.primaryScreen()).availableGeometry()
        x = min(max(pos.x() - 40, geo.left()), geo.right() - self.width())
        y = min(max(pos.y() - 20, geo.top()), geo.bottom() - self.height())
        self.move(x, y)
        self.show()
        self.raise_()
        self.activateWindow()
        self.search.setFocus()

    def fill(self):
        q = self.search.text().lower()
        self.list.clear()
        for entry in self.plugin.items():
            if q and q not in entry["text"].lower():
                continue
            text = entry["text"].strip().replace("\n", " ⏎ ")
            it = QListWidgetItem(("📌  " if entry.get("pinned") else "") + (text[:90] + "…" if len(text) > 90 else text))
            it.setData(Qt.UserRole, entry["text"])
            it.setToolTip(entry["text"][:500])
            self.list.addItem(it)
        if self.list.count():
            self.list.setCurrentRow(0)

    def eventFilter(self, obj, e):
        if e.type() == QEvent.KeyPress:
            if e.key() == Qt.Key_Escape:
                self.hide()
                return True
            if e.key() in (Qt.Key_Down, Qt.Key_Up):
                row = self.list.currentRow() + (1 if e.key() == Qt.Key_Down else -1)
                self.list.setCurrentRow(max(0, min(self.list.count() - 1, row)))
                return True
            if e.key() in (Qt.Key_Return, Qt.Key_Enter) and self.list.currentItem():
                self._pick(self.list.currentItem())
                return True
        return super().eventFilter(obj, e)

    def changeEvent(self, e):
        if e.type() == QEvent.ActivationChange and not self.isActiveWindow():
            self.hide()
        super().changeEvent(e)

    def _pick(self, item):
        text = item.data(Qt.UserRole)
        self.hide()
        self.plugin.paste(text, self.target)


class Clipboard(Plugin):
    id = "clipboard"
    name = "Clipboard History"
    icon = ""
    category = "Productivity"
    order = 80
    description = "Remembers everything you copy. Press the hotkey to search and paste older items, and pin the ones you reuse."
    hotkeys = {"picker": ("Open clipboard history", "ctrl+alt+v")}

    def __init__(self, hub):
        super().__init__(hub)
        self.picker = None
        self._ignore_next = False

    def on_enable(self):
        QGuiApplication.clipboard().dataChanged.connect(self._on_copy)

    def on_disable(self):
        try:
            QGuiApplication.clipboard().dataChanged.disconnect(self._on_copy)
        except (RuntimeError, TypeError):
            pass
        if self.picker:
            self.picker.hide()

    def status(self):
        return f"{len(self.items())} items saved"

    def items(self):
        entries = self.setting("items", [])
        return sorted(entries, key=lambda e: not e.get("pinned"))

    def _on_copy(self):
        if self._ignore_next:
            self._ignore_next = False
            return
        text = QGuiApplication.clipboard().text()
        if not text or not text.strip() or len(text) > 20000:
            return
        entries = self.setting("items", [])
        pinned = any(e["text"] == text and e.get("pinned") for e in entries)
        entries = [e for e in entries if e["text"] != text]
        entries.insert(0, {"text": text, "pinned": pinned})
        keep_pinned = [e for e in entries if e.get("pinned")]
        others = [e for e in entries if not e.get("pinned")][:MAX_ITEMS]
        # preserve newest-first order while keeping every pin
        allowed = {id(e) for e in keep_pinned + others}
        self.set_setting("items", [e for e in entries if id(e) in allowed])
        self._refresh_page()

    def on_hotkey(self, action):
        if action == "picker":
            target = win.foreground()
            if not self.picker:
                self.picker = Picker(self)
            self.picker.popup(target)

    def paste(self, text, target):
        self._ignore_next = True
        QGuiApplication.clipboard().setText(text)
        if target:
            win.release_modifiers()
            win.focus(target)
            QTimer.singleShot(120, win.send_ctrl_v)

    # ------------------------------------------------------------ page
    def create_page(self):
        page = QWidget()
        self._page = page   # so refresh helpers work while building
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)
        card = ui.Card("History", "")
        card.add(ui.label(f"Press {ui.hotkeys.pretty(self.hub.combo_for(self, 'picker'))} anywhere to open the picker. "
                          "Double-click an item here to copy it.", "muted", wrap=True))
        self.search = QLineEdit(placeholderText="Search…")
        self.search.textChanged.connect(self._refresh_page)
        card.add(self.search)
        self.list = QListWidget()
        self.list.setMinimumHeight(380)
        self.list.itemDoubleClicked.connect(self._copy_item)
        card.add(self.list)
        card.add(ui.hrow(
            ui.button("Pin / unpin", None, "", self._toggle_pin),
            ui.button("Delete", None, "", self._delete),
            None,
            ui.button("Clear all (keeps pins)", "danger", "", self._clear)))
        lay.addWidget(card)
        self._refresh_page()
        return page

    def _selected_text(self):
        it = self.list.currentItem()
        return it.data(Qt.UserRole) if it else None

    def _copy_item(self, it):
        self._ignore_next = False   # re-copying should move it to the top
        QGuiApplication.clipboard().setText(it.data(Qt.UserRole))
        self.notify("Copied", "")

    def _toggle_pin(self):
        text = self._selected_text()
        if text is None:
            return
        for e in self.setting("items", []):
            if e["text"] == text:
                e["pinned"] = not e.get("pinned")
        self.hub.config.save()
        self._refresh_page()

    def _delete(self):
        text = self._selected_text()
        if text is not None:
            self.set_setting("items", [e for e in self.setting("items", []) if e["text"] != text])
            self._refresh_page()

    def _clear(self):
        self.set_setting("items", [e for e in self.setting("items", []) if e.get("pinned")])
        self._refresh_page()

    def _refresh_page(self):
        if self._page is None:
            return
        q = self.search.text().lower()
        self.list.clear()
        for e in self.items():
            if q and q not in e["text"].lower():
                continue
            text = e["text"].strip().replace("\n", " ⏎ ")
            it = QListWidgetItem(("📌  " if e.get("pinned") else "") + (text[:140] + "…" if len(text) > 140 else text))
            it.setData(Qt.UserRole, e["text"])
            self.list.addItem(it)
