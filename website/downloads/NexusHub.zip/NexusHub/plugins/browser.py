"""Nexus Browser: a tabbed Chromium browser inside NexusHub (Google, YouTube, anything)."""
import os
import re
import urllib.parse

from PySide6.QtCore import QSize, Qt, QUrl, Signal
from PySide6.QtGui import QCursor, QKeySequence, QShortcut
from PySide6.QtWidgets import (QHBoxLayout, QLineEdit, QMenu, QPushButton, QStackedWidget, QTabBar, QVBoxLayout,
                               QWidget)

from core import ui
from core.config import APP_DIR
from core.plugin import Plugin

try:
    from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile, QWebEngineSettings
    from PySide6.QtWebEngineWidgets import QWebEngineView
    HAS_WEB = True
except ImportError:
    HAS_WEB = False

HOME = "https://www.google.com/"
SEARCH = {"Google": "https://www.google.com/search?q=", "DuckDuckGo": "https://duckduckgo.com/?q=",
          "Bing": "https://www.bing.com/search?q="}
DEFAULT_BOOKMARKS = [("Google", "https://www.google.com/"), ("YouTube", "https://www.youtube.com/"),
                     ("Gmail", "https://mail.google.com/"), ("Twitch", "https://www.twitch.tv/")]
# A normal desktop Chrome user agent: some sites (Google sign-in especially) refuse "embedded" browsers.
CHROME_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
             "Chrome/{ver} Safari/537.36")


def to_url(text, engine="Google"):
    """What you typed -> a URL: 'youtube.com' opens it, 'best pizza' searches it."""
    t = text.strip()
    if not t:
        return HOME
    if re.match(r"^[a-zA-Z][\w+.-]*://", t) or t.startswith("about:"):
        return t
    if " " not in t and (re.fullmatch(r"[\w-]+(\.[\w-]+)+(:\d+)?(/.*)?", t) or t.startswith("localhost")):
        return "https://" + t
    return SEARCH.get(engine, SEARCH["Google"]) + urllib.parse.quote(t)


if HAS_WEB:
    class WebView(QWebEngineView):
        """A tab's view; links that want a new window open as a new tab instead."""

        def __init__(self, browser, profile):
            super().__init__()
            self.browser = browser
            self.setPage(QWebEnginePage(profile, self))

        def createWindow(self, _type):
            return self.browser.new_tab(None, focus=True)


class Browser(QWidget):
    def __init__(self, plugin):
        super().__init__()
        self.plugin = plugin
        self.profile = plugin.profile()
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 10, 12, 10)
        lay.setSpacing(8)

        # tabs row
        top = QHBoxLayout()
        top.setSpacing(6)
        self.tabs = QTabBar()
        self.tabs.setTabsClosable(True)
        self.tabs.setMovable(True)
        self.tabs.setExpanding(False)
        self.tabs.setElideMode(Qt.ElideRight)
        self.tabs.setDocumentMode(True)
        self.tabs.setStyleSheet(
            f"QTabBar::tab {{ background: {ui.SURFACE}; color: {ui.MUTED}; padding: 7px 14px; margin-right: 4px;"
            f" border-radius: 9px; min-width: 120px; max-width: 220px; }}"
            f"QTabBar::tab:selected {{ background: {ui.SURFACE2}; color: {ui.TEXT}; border-bottom: 2px solid {ui.ACCENT}; }}"
            f"QTabBar::tab:hover {{ color: {ui.TEXT}; }}"
            "QTabBar::close-button { subcontrol-position: right; }")
        self.tabs.currentChanged.connect(self._switch)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.tabMoved.connect(self._moved)
        top.addWidget(self.tabs, 1)
        plus = ui.button("", "ghost", "", lambda: self.new_tab(HOME, focus=True))
        plus.setToolTip("New tab (Ctrl+T)")
        top.addWidget(plus)
        top.addStretch(0)
        lay.addLayout(top)

        # toolbar
        bar = QHBoxLayout()
        bar.setSpacing(6)
        self.back = ui.button("", "ghost", "", lambda: self.view() and self.view().back())
        self.fwd = ui.button("", "ghost", "", lambda: self.view() and self.view().forward())
        self.reload = ui.button("", "ghost", "", self._reload_or_stop)
        home = ui.button("", "ghost", "", lambda: self.navigate(HOME))
        self.address = QLineEdit(placeholderText="Search Google or type a web address")
        self.address.setStyleSheet(f"QLineEdit {{ border-radius: 18px; padding: 8px 16px; font-size: 14px;"
                                   f" background: {ui.SURFACE2}; }}")
        self.address.returnPressed.connect(lambda: self.navigate(self.address.text()))
        self.star = ui.button("", "ghost", "", self._toggle_bookmark)
        self.star.setToolTip("Bookmark this page")
        ext = ui.button("", "ghost", "", self._open_external)
        ext.setToolTip("Open in your normal browser")
        more = ui.button("", "ghost", "", self._menu)
        for w in (self.back, self.fwd, self.reload, home):
            bar.addWidget(w)
        bar.addWidget(self.address, 1)
        for w in (self.star, ext, more):
            bar.addWidget(w)
        lay.addLayout(bar)

        # bookmarks bar
        self.marks = QHBoxLayout()
        self.marks.setSpacing(4)
        lay.addLayout(self.marks)

        self.pages = QStackedWidget()
        self.pages.setStyleSheet(f"QStackedWidget {{ background: {ui.SURFACE}; border-radius: 12px; }}")
        lay.addWidget(self.pages, 1)
        self.views = []

        for keys, fn in (("Ctrl+T", lambda: self.new_tab(HOME, focus=True)), ("Ctrl+W", lambda: self.close_tab(self.tabs.currentIndex())),
                         ("Ctrl+L", lambda: (self.address.setFocus(), self.address.selectAll())), ("F5", self._reload_or_stop),
                         ("Ctrl+R", self._reload_or_stop), ("Alt+Left", lambda: self.view() and self.view().back()),
                         ("Alt+Right", lambda: self.view() and self.view().forward()),
                         ("Ctrl+Tab", lambda: self.tabs.setCurrentIndex((self.tabs.currentIndex() + 1) % max(1, self.tabs.count()))),
                         ("Ctrl++", lambda: self._zoom(0.1)), ("Ctrl+=", lambda: self._zoom(0.1)), ("Ctrl+-", lambda: self._zoom(-0.1)),
                         ("Ctrl+0", lambda: self.view() and self.view().setZoomFactor(1.0))):
            QShortcut(QKeySequence(keys), self, activated=fn)
        self._fill_bookmarks()

    # ------------------------------------------------------------ tabs
    def view(self):
        i = self.tabs.currentIndex()
        return self.views[i] if 0 <= i < len(self.views) else None

    def new_tab(self, url=HOME, focus=True):
        v = WebView(self, self.profile)
        if hasattr(QWebEngineSettings.WebAttribute, "ForceDarkMode"):
            v.settings().setAttribute(QWebEngineSettings.WebAttribute.ForceDarkMode, self.plugin.setting("force_dark", False))
        self.views.append(v)
        self.pages.addWidget(v)
        idx = self.tabs.addTab("New tab")
        v.titleChanged.connect(lambda t, v=v: self._set_title(v, t))
        v.iconChanged.connect(lambda icon, v=v: self._set_icon(v, icon))
        v.urlChanged.connect(lambda u, v=v: self._url_changed(v, u))
        v.loadStarted.connect(lambda v=v: v is self.view() and self.reload.setIcon(ui.glyph_icon("")))
        v.loadFinished.connect(lambda _ok, v=v: v is self.view() and self.reload.setIcon(ui.glyph_icon("")))
        if url:
            v.load(QUrl(url))
        if focus:
            self.tabs.setCurrentIndex(idx)
        return v

    def close_tab(self, i):
        if not (0 <= i < len(self.views)):
            return
        v = self.views.pop(i)
        self.tabs.removeTab(i)
        self.pages.removeWidget(v)
        v.setUrl(QUrl("about:blank"))
        v.deleteLater()
        if not self.views:
            self.new_tab(HOME)

    def _moved(self, a, b):
        self.views.insert(b, self.views.pop(a))

    def _switch(self, i):
        v = self.view()
        if v is None:
            return
        self.pages.setCurrentWidget(v)
        self._show_url(v.url())
        self.back.setEnabled(v.history().canGoBack())
        self.fwd.setEnabled(v.history().canGoForward())

    def _set_title(self, v, title):
        if v in self.views:
            i = self.views.index(v)
            self.tabs.setTabText(i, title or "New tab")
            self.tabs.setTabToolTip(i, title)

    def _set_icon(self, v, icon):
        if v in self.views:
            self.tabs.setTabIcon(self.views.index(v), icon)

    def _url_changed(self, v, url):
        if v is self.view():
            self._show_url(url)
            self.back.setEnabled(v.history().canGoBack())
            self.fwd.setEnabled(v.history().canGoForward())

    def _show_url(self, url):
        s = url.toString()
        if not self.address.hasFocus():
            self.address.setText("" if s in ("about:blank",) else s)
        marked = any(u == s for _, u in self.plugin.bookmarks())
        self.star.setIcon(ui.glyph_icon("" if marked else "", ui.WARN if marked else ui.TEXT))

    # ------------------------------------------------------------ actions
    def navigate(self, text):
        url = to_url(text, self.plugin.setting("engine", "Google"))
        v = self.view() or self.new_tab(None)
        v.load(QUrl(url))
        v.setFocus()

    def _reload_or_stop(self):
        v = self.view()
        if v:
            v.reload()

    def _zoom(self, d):
        v = self.view()
        if v:
            v.setZoomFactor(max(0.3, min(3.0, v.zoomFactor() + d)))

    def _open_external(self):
        v = self.view()
        if v and v.url().toString().startswith("http"):
            os.startfile(v.url().toString())

    def _toggle_bookmark(self):
        v = self.view()
        if not v:
            return
        url, title = v.url().toString(), v.title() or v.url().host()
        marks = self.plugin.bookmarks()
        if any(u == url for _, u in marks):
            marks = [(t, u) for t, u in marks if u != url]
        else:
            marks.append((title[:28], url))
        self.plugin.set_setting("bookmarks", marks)
        self._fill_bookmarks()
        self._show_url(v.url())

    def _fill_bookmarks(self):
        while self.marks.count():
            w = self.marks.takeAt(0).widget()
            if w:
                w.deleteLater()
        for title, url in self.plugin.bookmarks():
            b = QPushButton(title)
            b.setProperty("kind", "ghost")
            b.setCursor(Qt.PointingHandCursor)
            b.setStyleSheet("padding: 4px 10px; font-size: 12px;")
            b.setToolTip(url)
            b.clicked.connect(lambda _=False, u=url: self.navigate(u))
            b.setContextMenuPolicy(Qt.CustomContextMenu)
            b.customContextMenuRequested.connect(lambda _p, u=url: (self.new_tab(u, focus=True)))
            self.marks.addWidget(b)
        self.marks.addStretch()

    def _menu(self):
        pl = self.plugin
        m = QMenu(self)
        m.addAction(ui.glyph_icon(""), "New tab", lambda: self.new_tab(HOME, focus=True))
        m.addAction(ui.glyph_icon(""), "Open page in your normal browser", self._open_external)
        m.addSeparator()
        m.addAction(ui.glyph_icon(""), "Zoom in   (Ctrl +)", lambda: self._zoom(0.1))
        m.addAction(ui.glyph_icon(""), "Zoom out   (Ctrl -)", lambda: self._zoom(-0.1))
        m.addAction(ui.glyph_icon(""), "Open Downloads folder",
                    lambda: os.startfile(os.path.join(os.path.expanduser("~"), "Downloads")))
        m.addSeparator()
        eng = m.addMenu(ui.glyph_icon(""), "Search with")
        for name in SEARCH:
            a = eng.addAction(name, lambda n=name: pl.set_setting("engine", n))
            a.setCheckable(True)
            a.setChecked(pl.setting("engine", "Google") == name)
        for key, text, default in (("handle_links", "Open NexusHub links here (searches, Quick Launch sites)", True),
                                   ("force_dark", "Dark mode for every website (new tabs)", False)):
            a = m.addAction(text, lambda k=key, d=default: pl.set_setting(k, not pl.setting(k, d)))
            a.setCheckable(True)
            a.setChecked(pl.setting(key, default))
        m.addAction(ui.glyph_icon(""), "Clear browsing data (sign out of everything)…", self._clear_data)
        m.exec(QCursor.pos())

    def _clear_data(self):
        from PySide6.QtWidgets import QMessageBox
        if QMessageBox.question(self, "Clear browsing data",
                                "Delete cookies, cache and history? You'll be signed out of all websites.") == QMessageBox.Yes:
            self.profile.clearHttpCache()
            self.profile.cookieStore().deleteAllCookies()
            self.profile.clearAllVisitedLinks()
            self.plugin.notify("Browsing data cleared", "")


class NexusBrowser(Plugin):
    id = "browser"
    name = "Browser"
    icon = ""
    category = "Internet"
    order = 5
    full_page = True
    description = "Browse the web without leaving NexusHub: tabs, Google, bookmarks, and you stay signed in."
    hotkeys = {"open": ("Open the browser", "ctrl+alt+b")}
    download_done = Signal(str)

    def __init__(self, hub):
        super().__init__(hub)
        self._profile = None
        self.view_widget = None
        self.download_done.connect(lambda name: self.notify(f"Downloaded {name}", ""))

    def on_enable(self):
        if not HAS_WEB:
            raise RuntimeError("QtWebEngine missing (install PySide6-Addons)")

    def status(self):
        n = len(self.view_widget.views) if self.view_widget else 0
        return f"{n} tab{'s' if n != 1 else ''} open" if n else "Ready"

    def on_hotkey(self, action):
        if action == "open":
            self.hub.show_window()
            self.hub.window.open_page(self.id)

    def bookmarks(self):
        marks = self.setting("bookmarks")
        return [tuple(m) for m in (marks if marks is not None else DEFAULT_BOOKMARKS)]

    def open_settings(self):
        self.hub.show_window()
        self.hub.window.open_page("settings")

    # ------------------------------------------------------------ engine
    def profile(self):
        """One persistent profile: cookies and logins survive restarts, stored in %APPDATA%\\NexusHub\\browser."""
        if self._profile is None:
            path = os.path.join(APP_DIR, "browser")
            os.makedirs(path, exist_ok=True)
            p = QWebEngineProfile("NexusHub", self)
            p.setPersistentStoragePath(path)
            p.setCachePath(os.path.join(path, "cache"))
            p.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.ForcePersistentCookies)
            ua = p.httpUserAgent()
            m = re.search(r"Chrome/([\d.]+)", ua)
            p.setHttpUserAgent(CHROME_UA.format(ver=m.group(1) if m else "130.0.0.0"))
            # English first (your Windows is in English), Arabic as a fallback, so sites don't guess from your region
            p.setHttpAcceptLanguage(self.setting("languages", "en-US,en;q=0.9,ar;q=0.7"))
            p.downloadRequested.connect(self._download)
            self._profile = p
        return self._profile

    def _download(self, item):
        folder = os.path.join(os.path.expanduser("~"), "Downloads")
        item.setDownloadDirectory(folder)
        item.accept()
        self.notify(f"Downloading {item.downloadFileName()}", "")
        item.isFinishedChanged.connect(
            lambda: item.isFinished() and self.download_done.emit(item.downloadFileName()))

    def open_tab(self, url, show=True):
        first = self.view_widget is None
        self._pending_url = url           # the very first page opens straight on this link
        if show:
            self.hub.show_window()
            self.hub.window.open_page(self.id)
        page = self.page()
        if page is not None and not first:
            page.new_tab(url, focus=True)
        self._pending_url = None

    # ------------------------------------------------------------ page
    def create_page(self):
        if not HAS_WEB:
            return ui.label("The browser needs PySide6-Addons (QtWebEngine).", "muted")
        self.view_widget = Browser(self)
        self._page = self.view_widget
        self.view_widget.new_tab(getattr(self, "_pending_url", None) or self.setting("home", HOME))
        return self.view_widget
