"""Pomodoro focus timer plus background reminders (water, eye breaks, custom)."""
import datetime
import os
import time
import winsound

from PySide6.QtCore import QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QConicalGradient, QFont, QPainter, QPen
from PySide6.QtWidgets import QHBoxLayout, QLineEdit, QListWidget, QListWidgetItem, QSpinBox, QVBoxLayout, QWidget

from core import ui
from core.config import APP_DIR
from core.plugin import Plugin

DING = os.path.join(APP_DIR, "sounds", "Ding.wav")
PHASE_NAME = {"focus": "Focus", "short": "Short break", "long": "Long break", "idle": "Ready"}


def chime():
    try:
        if os.path.exists(DING):
            winsound.PlaySound(DING, winsound.SND_FILENAME | winsound.SND_ASYNC)
        else:
            winsound.MessageBeep(winsound.MB_ICONASTERISK)
    except RuntimeError:
        pass


class Ring(QWidget):
    def __init__(self, plugin):
        super().__init__()
        self.plugin = plugin
        self.setFixedSize(240, 240)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        pl = self.plugin
        r = QRectF(14, 14, 212, 212)
        p.setPen(QPen(QColor(ui.SURFACE2), 14, Qt.SolidLine, Qt.RoundCap))
        p.drawArc(r, 0, 360 * 16)
        total = pl.phase_length(pl.phase) if pl.phase != "idle" else 1
        frac = 0 if pl.phase == "idle" else max(0.0, min(1.0, pl.remaining / total))
        if frac > 0:
            g = QConicalGradient(r.center(), 90)
            g.setColorAt(0, QColor(ui.ACCENT2 if pl.phase == "focus" else ui.GOOD))
            g.setColorAt(1, QColor(ui.ACCENT if pl.phase == "focus" else ui.ACCENT2))
            p.setPen(QPen(g, 14, Qt.SolidLine, Qt.RoundCap))
            p.drawArc(r, 90 * 16, int(frac * 360 * 16))
        secs = pl.remaining if pl.phase != "idle" else pl.phase_length("focus")
        f = QFont(ui.TEXT_FONT)
        f.setPixelSize(48)
        f.setWeight(QFont.Bold)
        p.setFont(f)
        p.setPen(QColor(ui.TEXT))
        p.drawText(r.adjusted(0, -16, 0, 0), Qt.AlignCenter, f"{int(secs) // 60:02d}:{int(secs) % 60:02d}")
        f.setPixelSize(14)
        f.setWeight(QFont.DemiBold)
        p.setFont(f)
        p.setPen(QColor(ui.ACCENT2))
        label = PHASE_NAME[pl.phase] + ("" if pl.running or pl.phase == "idle" else " · paused")
        p.drawText(r.adjusted(0, 70, 0, 0), Qt.AlignCenter, label.upper())


class Focus(Plugin):
    id = "focus"
    name = "Focus Timer"
    icon = ""
    category = "Productivity"
    order = 85
    description = "Pomodoro timer for focused work, plus gentle reminders to drink water and rest your eyes."
    hotkeys = {"toggle": ("Start / pause focus timer", "ctrl+alt+shift+f")}

    def __init__(self, hub):
        super().__init__(hub)
        self.phase, self.remaining, self.running, self.round = "idle", 0, False, 0
        self._last = time.monotonic()
        self._timer = QTimer(self, interval=1000, timeout=self._tick)

    def on_enable(self):
        now = time.time()
        self.set_setting("next_water", now + self.setting("water_min", 60) * 60)
        self.set_setting("next_eyes", now + 20 * 60)
        self._timer.start()

    def on_disable(self):
        self._timer.stop()
        self.running = False

    def status(self):
        if self.phase == "idle":
            done = self._today_count()
            return f"{done} focus session{'s' if done != 1 else ''} today"
        return f"{PHASE_NAME[self.phase]} · {int(self.remaining) // 60}:{int(self.remaining) % 60:02d}" + ("" if self.running else " (paused)")

    def tray_actions(self):
        return [("Pause focus timer" if self.running else "Start focus timer", lambda: self.on_hotkey("toggle"))]

    def on_hotkey(self, action):
        if action == "toggle":
            if self.phase == "idle":
                self.start_phase("focus")
            else:
                self.running = not self.running
                self.notify("Timer running" if self.running else "Timer paused", "")
            self._refresh_page()

    # ------------------------------------------------------------ timer
    def phase_length(self, phase):
        return {"focus": self.setting("focus_min", 25), "short": self.setting("short_min", 5),
                "long": self.setting("long_min", 15)}.get(phase, 25) * 60

    def start_phase(self, phase):
        self.phase, self.remaining, self.running = phase, self.phase_length(phase), True
        self.notify({"focus": "Focus time. You've got this", "short": "Short break: stand up and stretch",
                     "long": "Long break: you earned it"}[phase], "")
        self._refresh_page()

    def reset(self):
        self.phase, self.remaining, self.running, self.round = "idle", 0, False, 0
        self._refresh_page()

    def skip(self):
        if self.phase != "idle":
            self._phase_done(skipped=True)

    def _today_count(self):
        return self.setting("history", {}).get(datetime.date.today().isoformat(), 0)

    def _phase_done(self, skipped=False):
        if not skipped:
            chime()
        if self.phase == "focus":
            if not skipped:
                hist = self.setting("history", {})
                day = datetime.date.today().isoformat()
                hist[day] = hist.get(day, 0) + 1
                self.set_setting("history", dict(list(hist.items())[-30:]))
            self.round += 1
            nxt = "long" if self.round % self.setting("rounds", 4) == 0 else "short"
        else:
            nxt = "focus"
        if self.setting("auto_next", True):
            self.start_phase(nxt)
        else:
            self.phase, self.remaining, self.running = nxt, self.phase_length(nxt), False
            self.notify(f"Time's up! Press your hotkey to start the {PHASE_NAME[nxt].lower()}", "")
            self._refresh_page()

    def _tick(self):
        now = time.monotonic()
        dt, self._last = now - self._last, now
        if self.running:
            self.remaining -= dt
            if self.remaining <= 0:
                self._phase_done()
        self._reminders()
        if self._page is not None and self._page.isVisible():
            self.ring.update()

    def _reminders(self):
        now = time.time()
        if self.setting("water", False) and now >= self.setting("next_water", now + 1):
            self.set_setting("next_water", now + self.setting("water_min", 60) * 60)
            self.hub.osd.show_message("Drink some water 💧", "", sub="Hydration reminder")
            chime()
        if self.setting("eyes", False) and now >= self.setting("next_eyes", now + 1):
            self.set_setting("next_eyes", now + 20 * 60)
            self.hub.osd.show_message("Look at something 6 m away for 20 s", "", sub="20-20-20 eye break")
        due = [r for r in self.setting("custom", []) if r["at"] <= now]
        if due:
            for r in due:
                self.hub.osd.show_message(r["text"], "", sub="Reminder")
                self.hub.tray.showMessage("Reminder", r["text"], ui.app_icon(), 8000)
            chime()
            self.set_setting("custom", [r for r in self.setting("custom", []) if r["at"] > now])
            self._fill_custom()

    # ------------------------------------------------------------ page
    def create_page(self):
        page = QWidget()
        self._page = page
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)

        card = ui.Card()
        row = QHBoxLayout()
        row.setSpacing(28)
        self.ring = Ring(self)
        row.addWidget(self.ring)
        col = QVBoxLayout()
        col.addStretch()
        self.btn = ui.button("", "primary", "", lambda: self.on_hotkey("toggle"))
        self.btn.setMinimumHeight(42)
        col.addLayout(ui.hrow(self.btn, ui.button("Skip", None, "", self.skip),
                              ui.button("Reset", "ghost", "", self.reset), None))
        self.today = ui.label("", "muted")
        col.addWidget(self.today)
        col.addSpacing(8)
        for key, text, default, hi in (("focus_min", "Focus minutes", 25, 180), ("short_min", "Short break", 5, 60),
                                       ("long_min", "Long break", 15, 90), ("rounds", "Focus rounds before a long break", 4, 12)):
            sp = QSpinBox()
            sp.setRange(1, hi)
            sp.setValue(self.setting(key, default))
            sp.valueChanged.connect(lambda v, k=key: self.set_setting(k, v))
            col.addLayout(ui.hrow(ui.label(text), None, sp))
        auto = ui.ToggleSwitch(self.setting("auto_next", True))
        auto.toggled.connect(lambda on: self.set_setting("auto_next", on))
        col.addLayout(ui.hrow(ui.label("Start the next phase automatically"), None, auto))
        col.addStretch()
        row.addLayout(col, 1)
        card.add(row)
        lay.addWidget(card)

        rem = ui.Card("Reminders", "")
        water = ui.ToggleSwitch(self.setting("water", False))
        water.toggled.connect(lambda on: (self.set_setting("water", on),
                                          self.set_setting("next_water", time.time() + self.setting("water_min", 60) * 60)))
        wmin = QSpinBox()
        wmin.setRange(10, 240)
        wmin.setSuffix(" min")
        wmin.setValue(self.setting("water_min", 60))
        wmin.valueChanged.connect(lambda v: self.set_setting("water_min", v))
        rem.add(ui.hrow(ui.label("Drink water every"), wmin, None, water))
        eyes = ui.ToggleSwitch(self.setting("eyes", False))
        eyes.toggled.connect(lambda on: (self.set_setting("eyes", on), self.set_setting("next_eyes", time.time() + 1200)))
        rem.add(ui.hrow(ui.label("Eye break every 20 minutes (20-20-20 rule)"), None, eyes))
        rem.lay.addSpacing(6)
        rem.add(ui.label("Remind me…", "h2"))
        self.rem_text = QLineEdit(placeholderText="e.g. Take the pizza out")
        self.rem_min = QSpinBox()
        self.rem_min.setRange(1, 1440)
        self.rem_min.setValue(10)
        self.rem_min.setSuffix(" min")
        rem.add(ui.hrow(self.rem_text, ui.label("in"), self.rem_min, ui.button("Add", "primary", "", self._add_custom)))
        self.custom = QListWidget()
        self.custom.setMaximumHeight(140)
        rem.add(self.custom)
        lay.addWidget(rem)
        self._fill_custom()
        self._refresh_page()
        return page

    def _add_custom(self):
        text = self.rem_text.text().strip() or "Reminder"
        at = time.time() + self.rem_min.value() * 60
        self.set_setting("custom", self.setting("custom", []) + [{"text": text, "at": at}])
        self.rem_text.clear()
        self.notify(f"I'll remind you in {self.rem_min.value()} min", "")
        self._fill_custom()

    def _fill_custom(self):
        if self._page is None:
            return
        self.custom.clear()
        for r in sorted(self.setting("custom", []), key=lambda r: r["at"]):
            when = datetime.datetime.fromtimestamp(r["at"]).strftime("%H:%M")
            self.custom.addItem(QListWidgetItem(f"{when}   {r['text']}"))

    def _refresh_page(self):
        if self._page is None:
            return
        self.ring.update()
        label = "  Pause" if self.running else ("  Start focus" if self.phase == "idle" else "  Resume")
        self.btn.setText(label)
        self.btn.setIcon(ui.glyph_icon("" if self.running else "", "white"))
        n = self._today_count()
        self.today.setText(f"{n} focus session{'s' if n != 1 else ''} finished today")
