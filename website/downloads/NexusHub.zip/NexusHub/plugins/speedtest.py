"""Internet speed test (download, upload, ping) using Cloudflare's speed servers."""
import datetime
import http.client
import json
import math
import os
import statistics
import threading
import time

from PySide6.QtCore import QPointF, QRectF, Qt, QThread, QTimer, Signal
from PySide6.QtGui import QColor, QConicalGradient, QFont, QPainter, QPen
from PySide6.QtWidgets import (QComboBox, QGridLayout, QHBoxLayout, QTreeWidget, QTreeWidgetItem,
                               QVBoxLayout, QWidget)

from core import ui
from core.plugin import Plugin

HOST = "speed.cloudflare.com"
UA = {"User-Agent": "NexusHub-SpeedTest/1.0"}
STREAMS = 6
DOWN_SECONDS = 10
UP_SECONDS = 8
WARMUP = 1.5


class SpeedWorker(QThread):
    phase = Signal(str)
    live = Signal(str, float)
    info = Signal(dict)
    done = Signal(dict)
    failed = Signal(str)

    def __init__(self):
        super().__init__()
        self.cancelled = False

    def cancel(self):
        self.cancelled = True

    # --------------------------------------------------------------- phases
    def run(self):
        try:
            self.phase.emit("Finding a server…")
            self.info.emit(self._meta())
            self.phase.emit("Ping")
            ping, jitter = self._ping()
            if self.cancelled:
                return
            self.phase.emit("Download")
            down = self._transfer(self._download_loop, DOWN_SECONDS, "down")
            if self.cancelled:
                return
            self.phase.emit("Upload")
            up = self._transfer(self._upload_loop, UP_SECONDS, "up")
            if self.cancelled:
                return
            self.done.emit({"ping": ping, "jitter": jitter, "down": down, "up": up,
                            "when": datetime.datetime.now().isoformat(timespec="minutes")})
        except Exception as e:  # network errors → friendly message
            self.failed.emit(f"Test failed: {e.__class__.__name__}. Are you online?")

    def _conn(self):
        return http.client.HTTPSConnection(HOST, timeout=15)

    def _meta(self):
        c = self._conn()
        c.request("GET", "/meta", headers=UA)
        data = json.loads(c.getresponse().read() or b"{}")
        if not data.get("colo"):
            # /meta is sometimes empty; the trace endpoint always says which data centre we hit
            c.request("GET", "/cdn-cgi/trace", headers=UA)
            for line in c.getresponse().read().decode(errors="replace").splitlines():
                key, _, val = line.partition("=")
                if key == "colo":
                    data["colo"] = val
                elif key == "loc":
                    data.setdefault("country", val)
        c.close()
        return data

    def _ping(self):
        c = self._conn()
        samples = []
        for i in range(14):
            if self.cancelled:
                break
            t0 = time.perf_counter()
            c.request("GET", "/__down?bytes=0", headers=UA)
            c.getresponse().read()
            ms = (time.perf_counter() - t0) * 1000
            if i >= 2:          # the first requests include connection setup
                samples.append(ms)
                self.live.emit("ping", ms)
        c.close()
        if len(samples) < 2:
            return 0.0, 0.0
        jitter = statistics.mean(abs(a - b) for a, b in zip(samples, samples[1:]))
        return statistics.median(samples), jitter

    def _transfer(self, loop, seconds, name):
        state = {"bytes": 0, "stop": False}
        lock = threading.Lock()
        threads = [threading.Thread(target=loop, args=(state, lock), daemon=True) for _ in range(STREAMS)]
        start = time.perf_counter()
        for t in threads:
            t.start()
        history = []   # (time, bytes)
        base_t, base_b = None, 0
        while not self.cancelled:
            time.sleep(0.2)
            now = time.perf_counter() - start
            with lock:
                total = state["bytes"]
            history.append((now, total))
            if base_t is None and now >= WARMUP:
                base_t, base_b = now, total
            recent = [h for h in history if h[0] >= now - 2.0]
            if len(recent) > 1 and recent[-1][0] > recent[0][0]:
                mbps = (recent[-1][1] - recent[0][1]) * 8 / (recent[-1][0] - recent[0][0]) / 1e6
                self.live.emit(name, mbps)
            if now >= seconds:
                break
        state["stop"] = True
        end_t, end_b = history[-1] if history else (1, 0)
        if base_t is None or end_t <= base_t:
            return end_b * 8 / max(end_t, 0.001) / 1e6
        return (end_b - base_b) * 8 / (end_t - base_t) / 1e6

    def _download_loop(self, state, lock):
        c = self._conn()
        try:
            while not state["stop"] and not self.cancelled:
                c.request("GET", "/__down?bytes=50000000", headers=UA)
                r = c.getresponse()
                while not state["stop"] and not self.cancelled:
                    chunk = r.read(65536)
                    if not chunk:
                        break
                    with lock:
                        state["bytes"] += len(chunk)
                if state["stop"] or self.cancelled:
                    break
        except OSError:
            pass
        finally:
            c.close()

    def _upload_loop(self, state, lock):
        payload = os.urandom(65536)
        size = 8 * 1024 * 1024
        c = self._conn()
        try:
            while not state["stop"] and not self.cancelled:
                c.putrequest("POST", "/__up")
                c.putheader("User-Agent", UA["User-Agent"])
                c.putheader("Content-Type", "application/octet-stream")
                c.putheader("Content-Length", str(size))
                c.endheaders()
                sent = 0
                while sent < size and not state["stop"] and not self.cancelled:
                    c.send(payload)
                    sent += len(payload)
                    with lock:
                        state["bytes"] += len(payload)
                if sent < size:
                    break
                c.getresponse().read()
        except OSError:
            pass
        finally:
            c.close()


class Gauge(QWidget):
    TICKS = (0, 5, 10, 25, 50, 100, 250, 500, 1000)

    def __init__(self):
        super().__init__()
        self.setMinimumSize(340, 300)
        self.value = 0.0
        self.shown = 0.0
        self.unit = "Mbps"
        self.caption = "Ready"
        self.anim = QTimer(self, interval=16, timeout=self._ease)

    def set_value(self, v, unit="Mbps"):
        self.value, self.unit = max(0.0, v), unit
        if not self.anim.isActive():
            self.anim.start()

    def _ease(self):
        self.shown += (self.value - self.shown) * 0.12
        if abs(self.value - self.shown) < 0.01:
            self.shown = self.value
            self.anim.stop()
        self.update()

    @staticmethod
    def frac(v):
        return math.log10(1 + min(v, 1000)) / math.log10(1001)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        side = min(self.width(), self.height() * 1.15)
        r = side * 0.42
        c = QPointF(self.width() / 2, self.height() * 0.55)
        box = QRectF(c.x() - r, c.y() - r, 2 * r, 2 * r)
        start, span = 225, -270
        pen = QPen(QColor(ui.SURFACE2), 16, Qt.SolidLine, Qt.RoundCap)
        p.setPen(pen)
        p.drawArc(box, start * 16, span * 16)
        f = self.frac(self.shown) if self.unit == "Mbps" else min(self.shown / 200, 1)
        if f > 0.002:
            g = QConicalGradient(c, start)
            g.setColorAt(0.0, QColor(ui.ACCENT2))
            g.setColorAt(0.75, QColor(ui.ACCENT))
            g.setColorAt(1.0, QColor(ui.ACCENT2))
            pen = QPen(g, 16, Qt.SolidLine, Qt.RoundCap)
            p.setPen(pen)
            p.drawArc(box, start * 16, int(span * f * 16))
        # tick labels
        tf = QFont(ui.TEXT_FONT)
        tf.setPixelSize(11)
        p.setFont(tf)
        p.setPen(QColor(ui.MUTED))
        if self.unit == "Mbps":
            for t in self.TICKS:
                ang = math.radians(start + span * self.frac(t))
                pt = QPointF(c.x() + math.cos(ang) * (r - 34), c.y() - math.sin(ang) * (r - 34))
                p.drawText(QRectF(pt.x() - 20, pt.y() - 8, 40, 16), Qt.AlignCenter, str(t))
        # centre readout
        big = QFont(ui.TEXT_FONT)
        big.setPixelSize(int(r * 0.42))
        big.setWeight(QFont.Bold)
        p.setFont(big)
        p.setPen(QColor(ui.TEXT))
        txt = f"{self.shown:.0f}" if self.shown >= 100 or self.unit == "ms" else f"{self.shown:.1f}"
        p.drawText(QRectF(c.x() - r, c.y() - r * 0.32, 2 * r, r * 0.5), Qt.AlignCenter, txt)
        tf.setPixelSize(14)
        p.setFont(tf)
        p.setPen(QColor(ui.MUTED))
        p.drawText(QRectF(c.x() - r, c.y() + r * 0.2, 2 * r, 22), Qt.AlignCenter, self.unit)
        tf.setPixelSize(13)
        tf.setWeight(QFont.DemiBold)
        p.setFont(tf)
        p.setPen(QColor(ui.ACCENT2))
        p.drawText(QRectF(c.x() - r, c.y() + r * 0.5, 2 * r, 22), Qt.AlignCenter, self.caption.upper())


def verdict(res):
    d, ping = res["down"], res["ping"]
    if d >= 100 and ping < 40:
        return "Excellent: 4K streaming, big downloads and competitive gaming all at once."
    if d >= 25 and ping < 70:
        return "Good: HD/4K streaming, video calls and online gaming run smoothly."
    if d >= 8:
        return "OK: HD streaming works; large downloads and multiple 4K streams will struggle."
    return "Slow: expect buffering. Try moving closer to the router or using a cable."


class SpeedTest(Plugin):
    id = "speedtest"
    name = "Speed Test"
    icon = ""
    category = "Network"
    order = 30
    description = "Check your Wi-Fi/internet download, upload and ping, keep a history, and optionally test automatically."

    def __init__(self, hub):
        super().__init__(hub)
        self.worker = None
        self._auto = QTimer(self, timeout=lambda: self.run_test(silent=True))

    def on_enable(self):
        self._apply_auto()

    def on_disable(self):
        self._auto.stop()
        if self.worker:
            self.worker.cancel()

    def status(self):
        if self.worker:
            return "Testing…"
        hist = self.setting("history", [])
        if hist:
            h = hist[0]
            return f"↓ {h['down']:.0f}  ↑ {h['up']:.0f} Mbps · {h['ping']:.0f} ms"
        return "No tests yet"

    def tray_actions(self):
        return [("Run speed test", lambda: self.run_test(silent=False, show_window=True))]

    def _apply_auto(self):
        hours = self.setting("auto_hours", 0)
        self._auto.stop()
        if hours:
            self._auto.start(int(hours * 3600 * 1000))

    # ------------------------------------------------------------ test
    def run_test(self, silent=False, show_window=False):
        if self.worker:
            return
        if show_window:
            self.hub.show_window()
            self.hub.window.open_page(self.id)
        self.silent = silent
        self.worker = SpeedWorker()
        self.worker.phase.connect(self._on_phase)
        self.worker.live.connect(self._on_live)
        self.worker.info.connect(self._on_info)
        self.worker.done.connect(self._on_done)
        self.worker.failed.connect(self._on_failed)
        self.worker.finished.connect(self._on_finished)
        self.worker.start()
        self._set_running(True)
        if self._page is not None:
            for k in self.tiles:
                self.tiles[k].setText("–")
            self.gauge.set_value(0)

    def cancel(self):
        if self.worker:
            self.worker.cancel()

    def _on_phase(self, text):
        if self._page is not None:
            self.gauge.caption = text
            self.gauge.update()

    def _on_live(self, name, v):
        if self._page is None:
            return
        if name == "ping":
            self.gauge.set_value(v, "ms")
            self.tiles["ping"].setText(f"{v:.0f}")
        else:
            self.gauge.set_value(v, "Mbps")
            self.tiles[name].setText(f"{v:.1f}")

    def _on_info(self, meta):
        if self._page is not None and meta:
            where = ", ".join(x for x in (meta.get("city"), meta.get("country")) if x)
            isp = meta.get("asOrganization", "")
            text = f"Server: Cloudflare {meta.get('colo', '')}" + (f" ({where})" if where else "")
            self.lbl_server.setText(text + (f"   ·   Provider: {isp}" if isp else ""))

    def _on_done(self, res):
        hist = [res] + self.setting("history", [])[:49]
        self.set_setting("history", hist)
        if self._page is not None:
            self.tiles["ping"].setText(f"{res['ping']:.0f}")
            self.tiles["jitter"].setText(f"{res['jitter']:.0f}")
            self.tiles["down"].setText(f"{res['down']:.1f}")
            self.tiles["up"].setText(f"{res['up']:.1f}")
            self.gauge.caption = "Done"
            self.gauge.set_value(res["down"], "Mbps")
            self.lbl_verdict.setText(verdict(res))
            self._fill_history()
        if not self.silent and (self._page is None or not self._page.isVisible()):
            self.hub.osd.show_message(f"↓ {res['down']:.0f} Mbps   ↑ {res['up']:.0f} Mbps", self.icon,
                                      sub=f"Ping {res['ping']:.0f} ms")

    def _on_failed(self, msg):
        if self._page is not None:
            self.gauge.caption = "Failed"
            self.gauge.update()
            self.lbl_verdict.setText(msg)
        if not self.silent:
            self.notify(msg, "")

    def _on_finished(self):
        self.worker.deleteLater()
        self.worker = None
        self._set_running(False)

    def _set_running(self, on):
        if self._page is not None:
            self.btn.setText("  Cancel" if on else "  Start test")
            self.btn.setIcon(ui.glyph_icon("" if on else "", "white"))

    # ------------------------------------------------------------ page
    def create_page(self):
        page = QWidget()
        self._page = page   # so refresh helpers work while building
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)

        main = ui.Card()
        row = QHBoxLayout()
        row.setSpacing(24)
        self.gauge = Gauge()
        row.addWidget(self.gauge, 3)
        right = QVBoxLayout()
        right.setSpacing(10)
        grid = QGridLayout()
        grid.setSpacing(10)
        self.tiles = {}
        for i, (key, title, unit, glyph) in enumerate((
                ("down", "Download", "Mbps", ""), ("up", "Upload", "Mbps", ""),
                ("ping", "Ping", "ms", ""), ("jitter", "Jitter", "ms", ""))):
            tile = ui.Card()
            tile.setStyleSheet(f"#card {{ background: {ui.SURFACE2}; }}")
            tile.add(ui.hrow(ui.glyph_label(glyph, 13, ui.ACCENT2), ui.label(title, "muted"), None))
            val = ui.label("–", "big")
            tile.add(ui.hrow(val, ui.label(unit, "muted"), None))
            self.tiles[key] = val
            grid.addWidget(tile, i // 2, i % 2)
        right.addLayout(grid)
        self.lbl_verdict = ui.label("Press Start to measure your connection. It takes about 25 seconds.", "muted", wrap=True)
        right.addWidget(self.lbl_verdict)
        self.btn = ui.button("  Start test", "primary", "",
                             lambda: self.cancel() if self.worker else self.run_test())
        self.btn.setMinimumHeight(42)
        right.addWidget(self.btn)
        right.addStretch()
        row.addLayout(right, 2)
        main.add(row)
        self.lbl_server = ui.label("", "muted")
        main.add(self.lbl_server)
        lay.addWidget(main)

        hist = ui.Card("History", "")
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["When", "Download", "Upload", "Ping", "Jitter"])
        self.tree.setRootIsDecorated(False)
        self.tree.setMinimumHeight(200)
        self.tree.setColumnWidth(0, 200)
        hist.add(self.tree)
        auto = QComboBox()
        for text, h in (("Never", 0), ("Every hour", 1), ("Every 6 hours", 6), ("Every day", 24)):
            auto.addItem(text, h)
        auto.setCurrentIndex([0, 1, 6, 24].index(self.setting("auto_hours", 0)))
        auto.currentIndexChanged.connect(lambda _: (self.set_setting("auto_hours", auto.currentData()), self._apply_auto()))
        hist.add(ui.hrow(ui.label("Test automatically in the background"), None, auto,
                         ui.button("Clear history", "ghost", "",
                                   lambda: (self.set_setting("history", []), self._fill_history()))))
        lay.addWidget(hist)
        self._fill_history()
        if self.worker:
            self._set_running(True)
        return page

    def _fill_history(self):
        self.tree.clear()
        for h in self.setting("history", []):
            when = h["when"].replace("T", "  ")
            self.tree.addTopLevelItem(QTreeWidgetItem([
                when, f"{h['down']:.1f} Mbps", f"{h['up']:.1f} Mbps", f"{h['ping']:.0f} ms", f"{h['jitter']:.0f} ms"]))
