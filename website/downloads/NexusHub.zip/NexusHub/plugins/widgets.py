"""Desktop widgets: clock, weather, PC stats and Spotify now-playing, living on your desktop."""
import datetime
import json
import math
import threading
import time
import urllib.parse
import urllib.request

import psutil
from PySide6.QtCore import QPoint, QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QGuiApplication, QLinearGradient, QPainter, QPen
from PySide6.QtWidgets import QLineEdit, QSlider, QVBoxLayout, QWidget

from core import ui, win
from core.plugin import Plugin

# WMO weather codes -> (text, emoji)
SUN, SUN_CLOUD, PART, CLOUD, FOG = "\u2600\ufe0f", "\U0001F324\ufe0f", "\u26c5", "\u2601\ufe0f", "\U0001F32B\ufe0f"
SHOWER, RAIN, SNOWY, SNOW, STORM = "\U0001F326\ufe0f", "\U0001F327\ufe0f", "\U0001F328\ufe0f", "\u2744\ufe0f", "\u26c8\ufe0f"
THERMO = "\U0001F321\ufe0f"
WEATHER = {0: ("Clear", SUN), 1: ("Mostly clear", SUN_CLOUD), 2: ("Partly cloudy", PART), 3: ("Cloudy", CLOUD),
           45: ("Fog", FOG), 48: ("Fog", FOG), 51: ("Drizzle", SHOWER), 53: ("Drizzle", SHOWER), 55: ("Drizzle", SHOWER),
           61: ("Light rain", RAIN), 63: ("Rain", RAIN), 65: ("Heavy rain", RAIN), 71: ("Light snow", SNOWY),
           73: ("Snow", SNOW), 75: ("Heavy snow", SNOW), 80: ("Showers", SHOWER), 81: ("Showers", RAIN),
           82: ("Heavy showers", RAIN), 95: ("Thunderstorm", STORM), 96: ("Thunderstorm", STORM), 99: ("Thunderstorm", STORM)}


def emoji_font(px):
    f = QFont("Segoe UI Emoji")
    f.setPixelSize(px)
    return f


def fetch_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "NexusHub"})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read())


class DeskWidget(QWidget):
    """Base: a frameless glass card that sits on the desktop and can be dragged."""
    KIND = ""
    SIZE = (260, 140)

    def __init__(self, plugin):
        super().__init__(None, Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnBottomHint
                         | Qt.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.plugin = plugin
        self.setFixedSize(*self.SIZE)
        self._drag = None
        pos = plugin.setting("pos", {}).get(self.KIND)
        geo = QGuiApplication.primaryScreen().availableGeometry()
        if pos and any(s.availableGeometry().contains(QPoint(*pos)) for s in QGuiApplication.screens()):
            self.move(*pos)
        else:
            idx = list(WIDGETS).index(self.KIND)
            self.move(geo.right() - self.width() - 24, geo.top() + 24 + sum(
                WIDGETS[k].SIZE[1] + 14 for k in list(WIDGETS)[:idx]))

    # dragging (when unlocked)
    def mousePressEvent(self, e):
        if e.button() != Qt.LeftButton:
            return
        if self.plugin.setting("locked", False):
            self.clicked(e.position())
        else:
            self._drag = e.globalPosition().toPoint() - self.pos()
            self._press = e.globalPosition().toPoint()

    def mouseMoveEvent(self, e):
        if self._drag is not None:
            self.move(e.globalPosition().toPoint() - self._drag)

    def mouseReleaseEvent(self, e):
        if self._drag is None:
            return
        self._drag = None
        if (e.globalPosition().toPoint() - self._press).manhattanLength() < 5:
            self.clicked(e.position())   # barely moved: treat it as a click (e.g. a play button)
            return
        pos = self.plugin.setting("pos", {})
        pos[self.KIND] = [self.x(), self.y()]
        self.plugin.set_setting("pos", pos)

    def clicked(self, pt):
        pass

    def card(self, p):
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        alpha = int(255 * self.plugin.setting("opacity", 78) / 100)
        g = QLinearGradient(r.topLeft(), r.bottomRight())
        g.setColorAt(0, QColor(24, 27, 38, alpha))
        g.setColorAt(1, QColor(14, 16, 24, alpha))
        p.setBrush(g)
        p.setPen(QPen(QColor(255, 255, 255, 30), 1))
        p.drawRoundedRect(r, 18, 18)
        return r

    @staticmethod
    def font(px, weight=QFont.Normal):
        f = QFont(ui.TEXT_FONT)
        f.setPixelSize(px)
        f.setWeight(weight)
        return f


class ClockWidget(DeskWidget):
    KIND = "clock"
    SIZE = (280, 130)

    def paintEvent(self, _):
        p = QPainter(self)
        r = self.card(p)
        now = datetime.datetime.now()
        p.setFont(self.font(52, QFont.Light))
        p.setPen(QColor("white"))
        p.drawText(r.adjusted(22, 8, 0, -40), Qt.AlignLeft | Qt.AlignVCenter, now.strftime("%H:%M"))
        # seconds progress arc
        c = QPointF(r.right() - 42, r.top() + 46)
        p.setPen(QPen(QColor(255, 255, 255, 30), 4))
        p.drawEllipse(c, 22, 22)
        g = QLinearGradient(c.x() - 22, 0, c.x() + 22, 0)
        g.setColorAt(0, QColor(ui.ACCENT))
        g.setColorAt(1, QColor(ui.ACCENT2))
        p.setPen(QPen(g, 4, Qt.SolidLine, Qt.RoundCap))
        p.drawArc(QRectF(c.x() - 22, c.y() - 22, 44, 44), 90 * 16, -int(now.second / 60 * 360 * 16))
        p.setFont(self.font(11, QFont.DemiBold))
        p.setPen(QColor(ui.MUTED))
        p.drawText(QRectF(c.x() - 22, c.y() - 22, 44, 44), Qt.AlignCenter, f"{now.second:02d}")
        p.setFont(self.font(14))
        p.setPen(QColor(220, 225, 235))
        p.drawText(r.adjusted(24, 0, 0, -18), Qt.AlignLeft | Qt.AlignBottom, now.strftime("%A, %d %B"))


class WeatherWidget(DeskWidget):
    KIND = "weather"
    SIZE = (280, 130)

    def clicked(self, pt):
        self.plugin.refresh_weather()

    def paintEvent(self, _):
        p = QPainter(self)
        r = self.card(p)
        w = self.plugin.weather
        if not w:
            p.setFont(self.font(13))
            p.setPen(QColor(ui.MUTED))
            msg = self.plugin.weather_error or ("Loading weather…" if self.plugin.setting("city") else
                                                "Set your city in NexusHub → Desktop Widgets")
            p.drawText(r.adjusted(18, 0, -18, 0), Qt.AlignCenter | Qt.TextWordWrap, msg)
            return
        text, glyph = WEATHER.get(w["code"], ("", THERMO))
        p.setFont(emoji_font(42))
        p.drawText(QRectF(r.left() + 12, r.top(), 72, r.height() - 20), Qt.AlignCenter, glyph)
        p.setFont(self.font(40, QFont.Light))
        p.setPen(QColor("white"))
        p.drawText(r.adjusted(92, 10, 0, -44), Qt.AlignLeft | Qt.AlignVCenter, f"{round(w['temp'])}°")
        p.setFont(self.font(13, QFont.DemiBold))
        p.drawText(r.adjusted(92, 0, -10, -38), Qt.AlignLeft | Qt.AlignBottom, text)
        p.setFont(self.font(12))
        p.setPen(QColor(ui.MUTED))
        p.drawText(r.adjusted(92, 0, -10, -18), Qt.AlignLeft | Qt.AlignBottom,
                   f"{w['city']} · H {round(w['max'])}° L {round(w['min'])}°")


class StatsWidget(DeskWidget):
    KIND = "stats"
    SIZE = (280, 120)

    def paintEvent(self, _):
        p = QPainter(self)
        r = self.card(p)
        pl = self.plugin
        rings = [("CPU", pl.cpu, ui.ACCENT), ("RAM", pl.ram, ui.ACCENT2), ("DISK", pl.disk, ui.GOOD)]
        for i, (name, val, col) in enumerate(rings):
            c = QPointF(r.left() + 50 + i * 90, r.top() + 50)
            p.setPen(QPen(QColor(255, 255, 255, 28), 6))
            p.setBrush(Qt.NoBrush)
            p.drawEllipse(c, 28, 28)
            color = QColor(col if val < 85 else ui.BAD)
            p.setPen(QPen(color, 6, Qt.SolidLine, Qt.RoundCap))
            p.drawArc(QRectF(c.x() - 28, c.y() - 28, 56, 56), 90 * 16, -int(val / 100 * 360 * 16))
            p.setFont(self.font(14, QFont.DemiBold))
            p.setPen(QColor("white"))
            p.drawText(QRectF(c.x() - 28, c.y() - 28, 56, 56), Qt.AlignCenter, f"{val:.0f}%")
            p.setFont(self.font(10, QFont.DemiBold))
            p.setPen(QColor(ui.MUTED))
            p.drawText(QRectF(c.x() - 40, c.y() + 32, 80, 16), Qt.AlignCenter, name)


class MusicWidget(DeskWidget):
    KIND = "music"
    SIZE = (280, 120)
    BUTTONS = (("prev", "\uE892"), ("play_pause", "\uE768"), ("next", "\uE893"))

    def _spotify(self):
        return self.plugin.hub.by_id.get("spotify")

    def _button_rects(self, r):
        return [(a, g, QRectF(r.left() + 18 + i * 46, r.bottom() - 46, 38, 32)) for i, (a, g) in enumerate(self.BUTTONS)]

    def clicked(self, pt):
        sp = self._spotify()
        if not sp or not sp.enabled:
            return
        for action, _, rect in self._button_rects(QRectF(self.rect()).adjusted(1, 1, -1, -1)):
            if rect.contains(pt):
                sp.on_hotkey(action)

    def paintEvent(self, _):
        p = QPainter(self)
        r = self.card(p)
        sp = self._spotify()
        track = sp.track if sp and sp.enabled else ""
        artist, _, song = track.partition(" - ")
        p.setFont(ui.icon_font(15))
        p.setPen(QColor("#1ed760"))
        p.drawText(QRectF(r.left() + 18, r.top() + 14, 20, 20), Qt.AlignCenter, "\uE8D6")
        p.setFont(self.font(10, QFont.DemiBold))
        p.setPen(QColor(ui.MUTED))
        state = "NOW PLAYING" if track else ("PAUSED" if sp and sp.running else "SPOTIFY IS CLOSED")
        p.drawText(r.adjusted(44, 16, 0, 0), Qt.AlignLeft | Qt.AlignTop, state)
        fm_w = int(r.width() - 36)
        p.setFont(self.font(15, QFont.DemiBold))
        p.setPen(QColor("white"))
        p.drawText(r.adjusted(18, 36, -18, 0), Qt.AlignLeft | Qt.AlignTop,
                   p.fontMetrics().elidedText(song or track or "Nothing playing", Qt.ElideRight, fm_w))
        p.setFont(self.font(12))
        p.setPen(QColor(ui.MUTED))
        p.drawText(r.adjusted(18, 58, -18, 0), Qt.AlignLeft | Qt.AlignTop,
                   p.fontMetrics().elidedText(artist if song else "", Qt.ElideRight, fm_w))
        for action, glyph, rect in self._button_rects(r):
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(255, 255, 255, 22))
            p.drawRoundedRect(rect, 9, 9)
            p.setFont(ui.icon_font(13))
            p.setPen(QColor("white"))
            p.drawText(rect, Qt.AlignCenter, "\uE769" if action == "play_pause" and track else glyph)


WIDGETS = {"clock": ClockWidget, "weather": WeatherWidget, "stats": StatsWidget, "music": MusicWidget}
NAMES = {"clock": "Clock & date", "weather": "Weather", "stats": "PC stats", "music": "Spotify now playing"}


class DesktopWidgets(Plugin):
    id = "widgets"
    name = "Desktop Widgets"
    icon = "\uE80A"
    category = "Desktop"
    order = 22
    description = "Beautiful live widgets on your desktop: clock, weather, PC stats and Spotify controls. Drag them anywhere."
    hotkeys = {"toggle": ("Show / hide desktop widgets", "ctrl+alt+shift+w")}
    weather_ready = Signal()

    def __init__(self, hub):
        super().__init__(hub)
        self.shown = {}
        self.weather = None
        self.weather_error = ""
        self.cpu = self.ram = self.disk = 0.0
        self._timer = QTimer(self, interval=1000, timeout=self._tick)
        self._weather_timer = QTimer(self, interval=30 * 60 * 1000, timeout=self.refresh_weather)
        self.weather_ready.connect(lambda: self.shown.get("weather") and self.shown["weather"].update())
        self._desk_mode = False

    def on_enable(self):
        psutil.cpu_percent(None)
        if not self.setting("hidden", False):
            self.show_all()
        self._timer.start()
        self._weather_timer.start()
        self.refresh_weather()

    def on_disable(self):
        self._timer.stop()
        self._weather_timer.stop()
        self.hide_all()

    def status(self):
        return f"{len(self.shown)} widget(s) on desktop" if self.shown else "Hidden"

    def tray_actions(self):
        return [("Hide desktop widgets" if self.shown else "Show desktop widgets", lambda: self.on_hotkey("toggle"))]

    def on_hotkey(self, action):
        if action == "toggle":
            if self.shown:
                self.hide_all()
                self.set_setting("hidden", True)
            else:
                self.show_all()
                self.set_setting("hidden", False)
            self.notify("Widgets shown" if self.shown else "Widgets hidden")

    def enabled_kinds(self):
        return [k for k in WIDGETS if self.setting("on", {}).get(k, True)]

    def show_all(self):
        for k in self.enabled_kinds():
            if k not in self.shown:
                w = WIDGETS[k](self)
                w.show()
                self.shown[k] = w

    def hide_all(self):
        for w in self.shown.values():
            w.close()
            w.deleteLater()
        self.shown = {}

    def set_widget(self, kind, on):
        st = self.setting("on", {})
        st[kind] = on
        self.set_setting("on", st)
        if on and not self.setting("hidden", False):
            self.show_all()
        elif not on and kind in self.shown:
            self.shown.pop(kind).close()

    # ------------------------------------------------------------ live data
    def _tick(self):
        if not self.shown:
            return
        self.cpu = psutil.cpu_percent(None)
        self.ram = psutil.virtual_memory().percent
        try:
            self.disk = psutil.disk_usage("C:\\").percent
        except OSError:
            pass
        # Keep widgets visible on "Show desktop" (Win+D): lift them when the desktop is focused,
        # and tuck them back to the bottom when you switch to an app.
        desk = win.is_desktop_or_shell(win.foreground())
        if desk != self._desk_mode:
            self._desk_mode = desk
            for w in self.shown.values():
                hwnd = int(w.winId())
                win.user32.SetWindowPos(hwnd, win.HWND(0) if desk else win.HWND(1), 0, 0, 0, 0,
                                        win.SWP_NOMOVE | win.SWP_NOSIZE | win.SWP_NOACTIVATE)
        for w in self.shown.values():
            w.update()

    def refresh_weather(self):
        city = self.setting("city", "").strip()
        if not city:
            self.weather, self.weather_error = None, ""
            self.weather_ready.emit()
            return

        def work():
            try:
                geo = fetch_json("https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + urllib.parse.quote(city))
                if not geo.get("results"):
                    self.weather, self.weather_error = None, f"Couldn't find “{city}”"
                    return
                g = geo["results"][0]
                data = fetch_json(
                    f"https://api.open-meteo.com/v1/forecast?latitude={g['latitude']}&longitude={g['longitude']}"
                    "&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min&timezone=auto"
                    + ("&temperature_unit=fahrenheit" if self.setting("fahrenheit", False) else ""))
                self.weather = {"city": g["name"], "temp": data["current"]["temperature_2m"],
                                "code": data["current"]["weather_code"],
                                "max": data["daily"]["temperature_2m_max"][0], "min": data["daily"]["temperature_2m_min"][0]}
                self.weather_error = ""
            except (OSError, ValueError, KeyError):
                self.weather_error = "Weather unavailable (offline?)"
            finally:
                self.weather_ready.emit()
        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------------------------ page
    def create_page(self):
        page = QWidget()
        self._page = page
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)
        card = ui.Card("Widgets", "\uE80A")
        card.add(ui.label("Drag widgets anywhere on your desktop. They stay behind your apps and pop back up "
                          "when you show the desktop (Win+D). Click the weather widget to refresh it.", "muted", wrap=True))
        for k in WIDGETS:
            sw = ui.ToggleSwitch(self.setting("on", {}).get(k, True))
            sw.toggled.connect(lambda on, k=k: self.set_widget(k, on))
            card.add(ui.hrow(ui.label(NAMES[k]), None, sw))
        lay.addWidget(card)

        wc = ui.Card("Weather", "\uE706")
        self.city = QLineEdit(placeholderText="Your city, e.g. Cairo", text=self.setting("city", ""))
        self.city.returnPressed.connect(self._save_city)
        wc.add(ui.hrow(self.city, ui.button("Save", "primary", "\uE73E", self._save_city)))
        fahr = ui.ToggleSwitch(self.setting("fahrenheit", False))
        fahr.toggled.connect(lambda on: (self.set_setting("fahrenheit", on), self.refresh_weather()))
        wc.add(ui.hrow(ui.label("Use °F"), None, fahr))
        wc.add(ui.label("Weather from Open-Meteo (free, no account). Only the city name is sent.", "muted"))
        lay.addWidget(wc)

        look = ui.Card("Look", "\uE790")
        op = QSlider(Qt.Horizontal)
        op.setRange(20, 100)
        op.setValue(self.setting("opacity", 78))
        op.setFixedWidth(300)
        op.valueChanged.connect(lambda v: (self.set_setting("opacity", v), [w.update() for w in self.shown.values()]))
        look.add(ui.hrow(ui.label("Background opacity"), None, op))
        lock = ui.ToggleSwitch(self.setting("locked", False))
        lock.toggled.connect(lambda on: self.set_setting("locked", on))
        look.add(ui.hrow(ui.label("Lock positions (clicks go to buttons instead of dragging)"), None, lock))
        look.add(ui.hrow(None, ui.button("Reset positions", "ghost", "\uE72C", self._reset_positions)))
        lay.addWidget(look)
        return page

    def _save_city(self):
        self.set_setting("city", self.city.text().strip())
        self.weather = None
        self.refresh_weather()
        self.notify("Weather location saved", "\uE706")

    def _reset_positions(self):
        self.set_setting("pos", {})
        was = bool(self.shown)
        self.hide_all()
        if was:
            self.show_all()
