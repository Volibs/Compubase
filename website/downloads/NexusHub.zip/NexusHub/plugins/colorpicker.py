"""Grab the colour of any pixel on screen with a hotkey."""
import colorsys
import ctypes
from ctypes import wintypes

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QGuiApplication
from PySide6.QtWidgets import QButtonGroup, QGridLayout, QPushButton, QVBoxLayout, QWidget

from core import ui
from core.plugin import Plugin

user32 = ctypes.WinDLL("user32")
gdi32 = ctypes.WinDLL("gdi32")
user32.GetDC.restype = wintypes.HDC
user32.GetDC.argtypes = [wintypes.HWND]
user32.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
gdi32.GetPixel.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int]
gdi32.GetPixel.restype = wintypes.DWORD


def pixel_under_cursor():
    pt = wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(pt))
    dc = user32.GetDC(None)
    try:
        c = gdi32.GetPixel(dc, pt.x, pt.y)
    finally:
        user32.ReleaseDC(None, dc)
    if c == 0xFFFFFFFF:
        return None
    return c & 0xFF, (c >> 8) & 0xFF, (c >> 16) & 0xFF


def fmt(rgb, mode):
    r, g, b = rgb
    if mode == "rgb":
        return f"rgb({r}, {g}, {b})"
    if mode == "hsl":
        h, l, s = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
        return f"hsl({round(h * 360)}, {round(s * 100)}%, {round(l * 100)}%)"
    return f"#{r:02X}{g:02X}{b:02X}"


class ColorPicker(Plugin):
    id = "colorpicker"
    name = "Color Picker"
    icon = ""
    category = "Tools"
    order = 90
    description = "Point at anything on screen and press the hotkey. The colour code is copied, ready to paste."
    hotkeys = {"pick": ("Pick colour under mouse", "ctrl+alt+shift+p")}

    def status(self):
        hist = self.setting("history", [])
        return f"Last: {fmt(hist[0], 'hex')}" if hist else "No colours yet"

    def on_hotkey(self, action):
        if action != "pick":
            return
        rgb = pixel_under_cursor()
        if not rgb:
            self.notify("Couldn't read that pixel", "")
            return
        text = fmt(rgb, self.setting("format", "hex"))
        QGuiApplication.clipboard().setText(text)
        hist = [list(rgb)] + [h for h in self.setting("history", []) if h != list(rgb)]
        self.set_setting("history", hist[:24])
        self.hub.osd.show_message(f"{text}  copied", color=fmt(rgb, "hex"))
        self._build()

    def create_page(self):
        page = QWidget()
        self._page = page
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)
        how = ui.Card("How to use", "")
        how.add(ui.label(f"Hover over anything (a game, a website, a photo) and press "
                         f"<b>{ui.hotkeys.pretty(self.hub.combo_for(self, 'pick'))}</b>. The colour is copied to your clipboard.",
                         "muted", wrap=True))
        group = QButtonGroup(page)
        row = []
        for mode, text in (("hex", "HEX  #7C6CFF"), ("rgb", "RGB  rgb(124, 108, 255)"), ("hsl", "HSL  hsl(247, 100%, 71%)")):
            b = QPushButton(text, checkable=True)
            b.setChecked(self.setting("format", "hex") == mode)
            b.setStyleSheet(f"QPushButton:checked {{ background:{ui.ACCENT}; border:none; color:white; }}")
            b.clicked.connect(lambda _=False, m=mode: (self.set_setting("format", m), self._build()))
            group.addButton(b)
            row.append(b)
        how.add(ui.hrow(ui.label("Copy as"), *row, None))
        lay.addWidget(how)
        hist = ui.Card("Recent colours", "")
        hist.header.addWidget(ui.button("Clear", "ghost", "", lambda: (self.set_setting("history", []), self._build())))
        self.grid = QGridLayout()
        self.grid.setSpacing(10)
        hist.add(self.grid)
        lay.addWidget(hist)
        self._build()
        return page

    def _build(self):
        if self._page is None:
            return
        while self.grid.count():
            w = self.grid.takeAt(0).widget()
            if w:
                w.deleteLater()
        hist = self.setting("history", [])
        if not hist:
            self.grid.addWidget(ui.label("Colours you pick will show up here. Click one to copy it again.", "muted"), 0, 0)
        mode = self.setting("format", "hex")
        for i, rgb in enumerate(hist):
            hexc = fmt(rgb, "hex")
            text_col = "#000" if QColor(hexc).lightness() > 150 else "#fff"
            b = QPushButton(fmt(rgb, mode))
            b.setMinimumHeight(64)
            b.setCursor(Qt.PointingHandCursor)
            b.setStyleSheet(f"QPushButton {{ background:{hexc}; color:{text_col}; border:1px solid #ffffff22; "
                            f"border-radius:10px; font-weight:600; }} QPushButton:hover {{ border:2px solid white; }}")
            b.clicked.connect(lambda _=False, t=fmt(rgb, mode), h=hexc: (
                QGuiApplication.clipboard().setText(t), self.hub.osd.show_message(f"{t}  copied", color=h)))
            self.grid.addWidget(b, i // 6, i % 6)
