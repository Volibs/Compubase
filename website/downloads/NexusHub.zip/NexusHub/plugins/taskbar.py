"""Nexus Dock: replaces the Windows taskbar with a magnifying dock, a live "island" and a Launchpad.

Safety first: the Windows taskbar is only *hidden*, never removed. It comes back when you switch this
module off, quit NexusHub, or if NexusHub ever crashes (the guardian process restores it).
"""
import ctypes
import datetime
import json
import math
import os
import time
from ctypes import wintypes

import psutil
from PySide6.QtCore import QEasingCurve, QEvent, QPoint, QPointF, QRect, QRectF, QSize, Qt, QTimer, QVariantAnimation
from PySide6.QtGui import (QColor, QCursor, QFont, QGuiApplication, QImage, QLinearGradient, QPainter, QPainterPath,
                           QPen, QPixmap, QRadialGradient)
from PySide6.QtWidgets import (QColorDialog, QComboBox, QHBoxLayout, QLineEdit, QMenu, QMessageBox, QPushButton,
                               QSlider, QVBoxLayout, QWidget)

from core import audio, icons, ui, win
from core.config import APP_DIR
from core.plugin import Plugin

STATE = os.path.join(APP_DIR, "taskbar_state.json")
u32 = win.user32
u32.FindWindowExW.restype = wintypes.HWND
u32.GetClassLongPtrW.restype = ctypes.c_size_t
u32.GetClassLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int]
u32.IsIconic.argtypes = [wintypes.HWND]

DEFAULTS = {
    # dock
    "position": "bottom", "icon_size": 48, "magnify": 70, "spacing": 10, "opacity": 82, "roundness": 22,
    "tint": "glass", "tint_color": "#1a1d2a", "show_running": True, "separators": True, "labels": True,
    "indicator": "dot", "autohide": False, "reserve": True, "bounce": True, "orb": True, "nexus_pin": True,
    # island
    "island": "right", "island_hover": True, "clock24": True, "seconds": False, "show_date": True,
    "island_music": True, "equalizer": True, "toggles": True,
    # launchpad
    "lp_columns": 7, "lp_icon": 72, "lp_all_apps": True, "lp_dim": 78,
}


# ====================================================================== Windows taskbar control
class APPBARDATA(ctypes.Structure):
    _fields_ = [("cbSize", ctypes.c_uint), ("hWnd", wintypes.HWND), ("uCallbackMessage", ctypes.c_uint),
                ("uEdge", ctypes.c_uint), ("rc", wintypes.RECT), ("lParam", ctypes.c_ssize_t)]


# A private handle: other modules also call SHAppBarMessage with their own struct type, and ctypes
# shares argtypes on windll.shell32, so each module must load its own copy to avoid clashing.
_shell32 = ctypes.WinDLL("shell32")
_shell32.SHAppBarMessage.restype = ctypes.c_size_t
_shell32.SHAppBarMessage.argtypes = [ctypes.c_uint, ctypes.POINTER(APPBARDATA)]
ABM_NEW, ABM_REMOVE, ABM_QUERYPOS, ABM_SETPOS, ABM_GETSTATE, ABM_SETSTATE = 0, 1, 2, 3, 4, 10
ABE_TOP, ABE_BOTTOM = 1, 3


def _abd(hwnd=None):
    a = APPBARDATA()
    a.cbSize = ctypes.sizeof(a)
    a.hWnd = hwnd
    return a


def windows_autohide(on=None):
    a = _abd()
    state = _shell32.SHAppBarMessage(ABM_GETSTATE, ctypes.byref(a))
    if on is None:
        return bool(state & 1)
    a.lParam = (state & ~1) | (1 if on else 0)
    _shell32.SHAppBarMessage(ABM_SETSTATE, ctypes.byref(a))


def tray_windows():
    out = []
    for cls in ("Shell_TrayWnd", "Shell_SecondaryTrayWnd"):
        h = u32.FindWindowExW(None, None, cls, None)
        while h:
            out.append(h)
            h = u32.FindWindowExW(None, h, cls, None)
    return out


def _save_state(state):
    try:
        with open(STATE, "w", encoding="utf-8") as f:
            json.dump(state, f)
    except OSError:
        pass


def _load_state():
    try:
        with open(STATE, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def hide_windows_taskbar():
    state = _load_state()
    if not state.get("hidden"):
        _save_state({"hidden": True, "prev_autohide": windows_autohide()})   # also read by the guardian
        windows_autohide(True)       # frees the screen space the Windows taskbar reserves
    for h in tray_windows():
        u32.ShowWindow(h, 0)


def show_windows_taskbar():
    state = _load_state()
    for h in tray_windows():
        u32.ShowWindow(h, 5)
    if state.get("hidden"):
        windows_autohide(bool(state.get("prev_autohide", False)))
        _save_state({"hidden": False})


def is_start_or_search_open():
    fg = win.foreground()
    return bool(fg) and win.class_name(fg) in ("Windows.UI.Core.CoreWindow", "XamlExplorerHostIslandWindow",
                                                "Shell_TrayWnd", "NotifyIconOverflowWindow",
                                                "TopLevelWindowForOverflowXamlIsland")


def activate(hwnd):
    """Bring a window to the front reliably (restores it if minimised)."""
    if u32.IsIconic(hwnd):
        u32.ShowWindow(hwnd, 9)
    u32.SetForegroundWindow(hwnd)
    if win.foreground() != hwnd:
        u32.keybd_event(0x12, 0, 0, 0)      # a tap of Alt lets Windows hand focus over
        u32.keybd_event(0x12, 0, 2, 0)
        u32.SetForegroundWindow(hwnd)


def window_icon(hwnd, size=64):
    for getter in (lambda: u32.SendMessageW(hwnd, 0x7F, 1, 0), lambda: u32.GetClassLongPtrW(hwnd, -14)):
        try:
            h = getter()
        except OSError:
            h = 0
        if h:
            img = QImage.fromHICON(h)
            if not img.isNull():
                return QPixmap.fromImage(img).scaled(size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
    return None


def _norm(s):
    return "".join(c for c in s.lower() if c.isalnum())


def toggle_desktop():
    import comtypes.client
    try:
        comtypes.client.CreateObject("Shell.Application", dynamic=True).ToggleDesktop()
    except Exception:
        pass


def tfont(px, weight=QFont.Normal):
    f = QFont(ui.TEXT_FONT)
    f.setPixelSize(int(px))
    f.setWeight(weight)
    return f


def letter_tile(name, size):
    """Placeholder icon (first letter on a gradient) while the real one loads."""
    pm = QPixmap(size, size)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    g = QLinearGradient(0, 0, size, size)
    g.setColorAt(0, QColor(ui.ACCENT))
    g.setColorAt(1, QColor(ui.ACCENT2))
    p.setBrush(g)
    p.setPen(Qt.NoPen)
    p.drawRoundedRect(QRectF(0, 0, size, size), size * 0.26, size * 0.26)
    p.setFont(tfont(size * 0.46, QFont.Bold))
    p.setPen(QColor("white"))
    p.drawText(pm.rect(), Qt.AlignCenter, (name[:1] or "?").upper())
    p.end()
    return pm


# ====================================================================== app model (shared)
class Group:
    """One dock item: a pinned app and/or the open windows of one program."""
    __slots__ = ("key", "name", "pin", "hwnds", "exe")

    def __init__(self, key, name):
        self.key, self.name = key, name
        self.pin = None
        self.hwnds = []
        self.exe = ""


class AppModel:
    """Works out what's pinned and what's running. Cheap: caches everything it can."""

    def __init__(self, plugin):
        self.plugin = plugin
        self._exe = {}          # pid -> exe
        self._pin_keys = {}     # (item id, target) -> resolved exe path
        self._icons = {}        # (group key, size) -> pixmap
        self.app_icons = {}     # installed-app target -> pixmap (Launchpad)

    def launcher(self):
        la = self.plugin.hub.by_id.get("launcher")
        return la if la and la.enabled else None

    def pins(self):
        la = self.launcher()
        return la.setting("items", []) if la else []

    def _pin_key(self, it):
        k = (it["id"], it["target"])
        if k not in self._pin_keys:
            t = it["target"]
            try:
                if t.lower().endswith(".lnk"):
                    t = icons.resolve_shortcut(t)[0] or t
                elif t.lower().startswith("shell:appsfolder\\"):
                    t = icons.real_path(t.split("\\", 1)[1])
            except Exception:
                pass
            self._pin_keys[k] = t.lower()
        return self._pin_keys[k]

    def exe_of(self, hwnd):
        pid = win.pid_of(hwnd)
        if pid not in self._exe:
            try:
                self._exe[pid] = psutil.Process(pid).exe()
            except psutil.Error:
                self._exe[pid] = ""
        return self._exe[pid]

    def groups(self):
        groups, order = {}, []
        for it in self.pins():
            g = Group("pin:" + it["id"], it["name"])
            g.pin = it
            groups[g.key] = g
            order.append(g.key)
        pin_count = len(order)
        own = os.getpid()
        windows = win.app_windows()
        hub_win = getattr(self.plugin.hub, "window", None)
        if (hub_win is not None and hub_win.isVisible() and not hub_win.isMinimized()
                and not self.plugin.opt("nexus_pin")):          # when pinned, NexusHub has its own spot
            windows.append(int(hub_win.winId()))
        for hwnd in windows:
            if win.pid_of(hwnd) == own:
                if hub_win is None or hwnd != int(hub_win.winId()):
                    continue
                exe, base = "nexushub", "nexushub"
            else:
                exe = self.exe_of(hwnd)
                base = os.path.basename(exe).lower()
            key = None
            if base == "applicationframehost.exe":
                key = "uwp:" + win.title(hwnd)
            else:
                for pk in order[:pin_count]:
                    it = groups[pk].pin
                    if self._pin_key(it) == exe.lower() or (_norm(it["name"]) and _norm(it["name"]) in _norm(base)):
                        key = pk
                        break
            key = key or "exe:" + exe.lower()
            if key not in groups:
                if not self.plugin.opt("show_running"):
                    continue
                title = win.title(hwnd)
                if exe == "nexushub":
                    name = "NexusHub"
                elif key.startswith("uwp:") or (len(title) <= 24 and " - " not in title and title):
                    name = title[:30]          # short titles are friendlier ("Task Manager" vs "Taskmgr")
                else:
                    name = os.path.splitext(base)[0].capitalize()
                groups[key] = Group(key, name)
                order.append(key)
            groups[key].hwnds.append(hwnd)
            groups[key].exe = exe
        return [groups[k] for k in order], pin_count

    def icon(self, g, size):
        k = (g.key, size)
        if k in self._icons:
            return self._icons[k]
        pm = None
        la = self.launcher()
        if g.pin and la:
            pm = la.item_pixmap(g.pin, size)
        elif g.exe == "nexushub":
            pm = ui.app_icon(size).pixmap(size, size)
        elif g.exe:
            pm = icons.extract(g.exe, 0, size)
        if pm is None and g.hwnds:
            pm = window_icon(g.hwnds[0], size)
        if pm is None:
            pm = letter_tile(g.name, size)
        self._icons[k] = pm
        return pm

    def forget_icons(self):
        self._icons.clear()


# ====================================================================== the Dock
class Dock(QWidget):
    CALLBACK = 0x8000 + 0x77

    def __init__(self, plugin):
        super().__init__(None, Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint | Qt.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setMouseTracking(True)
        self.setAcceptDrops(True)
        self.plugin = plugin
        self.model = plugin.model
        self.groups, self.pin_count = [], 0
        self.foreground = None
        self.mouse_x = None
        self.mag = 0.0                  # 0..1, eases in/out so magnification feels smooth
        self.bounce = {}
        self.drag = None                # (index, start_x) while reordering pinned apps
        self.drag_x = None
        self._registered = False
        self._reveal = 1.0
        self._away = None
        self._peek_until = 0
        self._sig = None
        self._anim = QTimer(self, interval=16, timeout=self._animate)
        self._win_timer = QTimer(self, interval=1200, timeout=self.refresh_windows)
        # the NexusHub glow breathes slowly; only its own small area is repainted, so it's cheap
        self._breath = QTimer(self, interval=70, timeout=self._breathe)
        self._fg_timer = QTimer(self, interval=300, timeout=self._watch_foreground)

    # --- settings & geometry ---------------------------------------------------
    def opt(self, k):
        return self.plugin.opt(k)

    @property
    def S(self):
        return int(self.opt("icon_size"))

    @property
    def M(self):
        return self.S * (1 + self.opt("magnify") / 100)

    def strip_height(self):
        return self.S + 26 + 20      # pill (icons + padding) + its 15 px gap from the screen edge + a little air

    def screen_geo(self):
        return QGuiApplication.primaryScreen().geometry()

    def apply_settings(self):
        self.model.forget_icons()
        self._place()
        if self.opt("reserve") and not self.opt("autohide"):
            self.register_appbar()
        else:
            self.unregister_appbar()
        self.update()

    def _place(self):
        geo = self.screen_geo()
        h = int(self.M + 26 + 46)       # magnified icons + padding + room for the name label
        bottom = self.opt("position") == "bottom"
        hide = int((1 - self._reveal) * (self.strip_height() + 6))
        y = geo.bottom() - h + 1 - 8 + hide if bottom else geo.top() + 8 - hide
        self.setGeometry(geo.left(), y, geo.width(), h)

    def register_appbar(self):
        """Keep maximised windows out of the dock's strip (like the real taskbar does)."""
        hwnd = int(self.winId())
        dpr = self.devicePixelRatioF()
        geo = self.screen_geo()
        a = _abd(hwnd)
        a.uCallbackMessage = self.CALLBACK
        if not self._registered:
            _shell32.SHAppBarMessage(ABM_NEW, ctypes.byref(a))
            self._registered = True
        bottom = self.opt("position") == "bottom"
        a.uEdge = ABE_BOTTOM if bottom else ABE_TOP
        h = int(self.strip_height() * dpr)
        a.rc.left, a.rc.right = int(geo.left() * dpr), int((geo.right() + 1) * dpr)
        if bottom:
            a.rc.bottom = int((geo.bottom() + 1) * dpr)
            a.rc.top = a.rc.bottom - h
        else:
            a.rc.top = int(geo.top() * dpr)
            a.rc.bottom = a.rc.top + h
        _shell32.SHAppBarMessage(ABM_QUERYPOS, ctypes.byref(a))
        if bottom:
            a.rc.top = a.rc.bottom - h
        else:
            a.rc.bottom = a.rc.top + h
        _shell32.SHAppBarMessage(ABM_SETPOS, ctypes.byref(a))

    def unregister_appbar(self):
        if self._registered:
            _shell32.SHAppBarMessage(ABM_REMOVE, ctypes.byref(_abd(int(self.winId()))))
            self._registered = False

    def start(self):
        self._reveal = 0.0 if self.opt("autohide") else 1.0
        self._place()
        self.show()
        self.apply_settings()
        self.refresh_windows()
        self._win_timer.start()
        self._fg_timer.start()
        self._breath.start()

    def _breathe(self):
        if not self.isVisible() or not self.opt("nexus_pin"):
            return
        for kind, _, r in self._layout():
            if kind == "nexus":
                self.update(r.adjusted(-r.width(), -r.height(), r.width(), r.height()).toRect())
                return

    def stop(self):
        self._breath.stop()
        self._win_timer.stop()
        self._fg_timer.stop()
        self._anim.stop()
        self.unregister_appbar()
        self.hide()

    # --- data ----------------------------------------------------------------------
    def refresh_windows(self):
        if time.time() > self._peek_until and not is_start_or_search_open():
            for h in tray_windows():               # Explorer sometimes brings its taskbar back
                if u32.IsWindowVisible(h):
                    u32.ShowWindow(h, 0)
        if self.drag is not None:
            return
        groups, pins = self.model.groups()
        sig = tuple((g.key, len(g.hwnds)) for g in groups)
        self.groups, self.pin_count = groups, pins
        if sig != self._sig:                       # only repaint when something actually changed
            self._sig = sig
            self.update()

    def _watch_foreground(self):
        fg = win.foreground()
        fs = win.foreground_is_fullscreen() and win.pid_of(fg) != os.getpid()
        if fs and self.isVisible():
            self.hide()
            self.plugin.island_visible(False)
        elif not fs and not self.isVisible() and (self._reveal > 0 or self.opt("autohide")):
            self.show()
            self.plugin.island_visible(True)
        if fs:
            return
        if fg != self.foreground:
            self.foreground = fg
            self.update()
        if self.opt("autohide"):
            self._autohide_tick()

    def _autohide_tick(self):
        pos = QCursor.pos()
        geo = self.screen_geo()
        bottom = self.opt("position") == "bottom"
        at_edge = pos.y() >= geo.bottom() - 2 if bottom else pos.y() <= geo.top() + 2
        pill = self._pill_rect().translated(self.x(), self.y())
        near = pill.adjusted(-30, -40, 30, 40).contains(QPointF(pos))
        if at_edge and pill.left() - 60 <= pos.x() <= pill.right() + 60:
            self._away = None
            self._slide(1.0)
        elif near and self._reveal > 0.5:
            self._away = None
        elif self._reveal > 0:
            self._away = self._away or time.monotonic()
            if time.monotonic() - self._away > 0.7:
                self._slide(0.0)

    def _slide(self, target):
        self._reveal_target = target
        if not self._anim.isActive():
            self._anim.start()

    # --- animation loop (only runs while something is moving) ------------------------
    def _animate(self):
        busy = False
        target = 1.0 if self.mouse_x is not None else 0.0
        if abs(self.mag - target) > 0.01:
            self.mag += (target - self.mag) * 0.25
            busy = True
        else:
            self.mag = target
        rt = getattr(self, "_reveal_target", self._reveal)
        if abs(self._reveal - rt) > 0.01:
            self._reveal += (rt - self._reveal) * 0.3
            self._place()
            busy = True
        elif self._reveal != rt:
            self._reveal = rt
            self._place()
        for k in list(self.bounce):
            self.bounce[k] += 0.03
            if self.bounce[k] >= 1:
                del self.bounce[k]
            busy = True
        self.update()
        if not busy:
            self._anim.stop()

    # --- layout of icons -------------------------------------------------------------
    def _items(self):
        """[(kind, group)] kinds: orb, app, sep."""
        out = []
        if self.opt("orb"):
            out.append(("orb", None))
            if self.opt("separators") and self.groups:
                out.append(("sep", None))
        apps = []
        for i, g in enumerate(self.groups):
            if i == self.pin_count and i > 0 and self.opt("separators"):
                apps.append(("sep", None))
            apps.append(("app", g))
        if self.opt("nexus_pin"):
            # NexusHub sits right in the middle of your apps
            real = [k for k, (kind, _) in enumerate(apps) if kind == "app"]
            mid = real[len(real) // 2] if real else 0
            apps.insert(mid, ("nexus", None))
        return out + apps

    def _sizes(self, items):
        S, gap = self.S, self.opt("spacing")
        base_x = []
        x = 0.0
        for kind, _ in items:
            w = 10 if kind == "sep" else S
            base_x.append(x + w / 2)
            x += w + gap
        total = x - gap
        start = (self.width() - total) / 2
        centers = [start + c for c in base_x]
        sizes = []
        for (kind, _), cx in zip(items, centers):
            if kind == "sep":
                sizes.append(10)
                continue
            s = S
            if self.mouse_x is not None or self.mag > 0:
                mx = self.mouse_x if self.mouse_x is not None else getattr(self, "_last_mx", cx)
                d = (mx - cx) / (S * 1.7)
                s = S + (self.M - S) * math.exp(-d * d) * self.mag
            sizes.append(s)
        return sizes

    def _layout(self):
        items = self._items()
        sizes = self._sizes(items)
        gap = self.opt("spacing")
        total = sum(sizes) + gap * (len(sizes) - 1)
        x = self.width() / 2 - total / 2
        bottom = self.opt("position") == "bottom"
        base_line = self.height() - 8 - 13 if bottom else 8 + 13
        rects = []
        for (kind, g), s in zip(items, sizes):
            lift = 0.0
            if g is not None and g.key in self.bounce:
                b = self.bounce[g.key]
                lift = abs(math.sin(b * math.pi * 3)) * 18 * (1 - b)
            if kind == "sep":
                r = QRectF(x, 0, s, 0)
            elif bottom:
                r = QRectF(x, base_line - s - lift, s, s)
            else:
                r = QRectF(x, base_line + lift, s, s)
            rects.append((kind, g, r))
            x += s + gap
        return rects

    def _pill_rect(self):
        items = self._items()
        S, gap = self.S, self.opt("spacing")
        widths = [10 if k == "sep" else S for k, _ in items]
        total = sum(widths) + gap * (len(widths) - 1) + 26
        if self.mag > 0:
            total += (self.M - S) * 1.6 * self.mag
        h = S + 26
        bottom = self.opt("position") == "bottom"
        y = self.height() - 8 - h if bottom else 8
        return QRectF((self.width() - total) / 2, y, total, h)

    # --- paint -----------------------------------------------------------------------------
    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        pill = self._pill_rect()
        rad = min(self.opt("roundness"), pill.height() / 2)
        tint = self.opt("tint")
        alpha = int(255 * self.opt("opacity") / 100)
        if tint == "accent":
            c1, c2 = QColor(ui.ACCENT).darker(260), QColor(ui.ACCENT2).darker(300)
        elif tint == "custom":
            c1 = QColor(self.opt("tint_color"))
            c2 = c1.darker(130)
        elif tint == "dark":
            c1, c2 = QColor(10, 11, 16), QColor(6, 7, 10)
        else:   # glass
            c1, c2 = QColor(40, 44, 60), QColor(18, 20, 28)
        c1.setAlpha(alpha)
        c2.setAlpha(alpha)
        g = QLinearGradient(pill.topLeft(), pill.bottomLeft())
        g.setColorAt(0, c1)
        g.setColorAt(1, c2)
        p.setBrush(g)
        edge = QLinearGradient(pill.topLeft(), pill.topRight())
        a1, a2 = QColor(ui.ACCENT), QColor(ui.ACCENT2)
        a1.setAlpha(120)
        a2.setAlpha(120)
        edge.setColorAt(0, QColor(255, 255, 255, 30))
        edge.setColorAt(0.5, a1 if self.mag > 0.3 else QColor(255, 255, 255, 40))
        edge.setColorAt(1, QColor(255, 255, 255, 30))
        p.setPen(QPen(edge, 1.2))
        p.drawRoundedRect(pill, rad, rad)

        hover = self._index_at(QPointF(self.mouse_x, pill.center().y())) if self.mouse_x is not None else None
        bottom = self.opt("position") == "bottom"
        for i, (kind, grp, r) in enumerate(self._layout()):
            if kind == "sep":
                p.setPen(QPen(QColor(255, 255, 255, 45), 1))
                p.drawLine(QPointF(r.center().x(), pill.top() + 12), QPointF(r.center().x(), pill.bottom() - 12))
                continue
            if self.drag is not None and kind == "app" and self.drag[0] == self.groups.index(grp):
                p.setOpacity(0.35)
            if kind == "orb":
                self._paint_orb(p, r)
            elif kind == "nexus":
                self._paint_nexus(p, r, pill, bottom)
            else:
                active = self.foreground in grp.hwnds
                if active and self.opt("indicator") == "glow":
                    glow = QRadialGradient(r.center(), r.width() * 0.8)
                    c = QColor(ui.ACCENT)
                    c.setAlpha(110)
                    glow.setColorAt(0, c)
                    c.setAlpha(0)
                    glow.setColorAt(1, c)
                    p.setPen(Qt.NoPen)
                    p.setBrush(glow)
                    p.drawEllipse(r.center(), r.width() * 0.8, r.width() * 0.8)
                pm = self.model.icon(grp, 128)
                p.drawPixmap(r.toRect(), pm)
                if grp.hwnds:
                    self._paint_indicator(p, r, pill, active, len(grp.hwnds), bottom)
            p.setOpacity(1.0)
            if i == hover and self.opt("labels") and self.drag is None:
                if kind == "orb":
                    name = "Launchpad"
                elif kind == "nexus":
                    name = self.plugin.hub.look().get("app_name") or "NexusHub"
                else:
                    name = win.title(grp.hwnds[0])[:40] if len(grp.hwnds) == 1 and not grp.pin else grp.name
                p.setFont(tfont(12, QFont.DemiBold))
                tw = p.fontMetrics().horizontalAdvance(name) + 22
                ly = r.top() - 34 if bottom else r.bottom() + 10
                lab = QRectF(r.center().x() - tw / 2, ly, tw, 26)
                p.setPen(QPen(QColor(255, 255, 255, 30), 1))
                p.setBrush(QColor(12, 13, 20, 235))
                p.drawRoundedRect(lab, 9, 9)
                p.setPen(QColor("white"))
                p.drawText(lab, Qt.AlignCenter, name)
        if self.drag is not None and self.drag_x is not None:
            g = self.groups[self.drag[0]]
            s = self.S * 1.15
            y = pill.top() - s * 0.25 if bottom else pill.top() + 10
            p.drawPixmap(QRectF(self.drag_x - s / 2, y, s, s).toRect(), self.model.icon(g, 128))

    def _paint_nexus(self, p, r, pill, bottom):
        """NexusHub's own icon: a soft accent glow that gently breathes, brighter than the other apps."""
        breathe = 0.5 + 0.5 * math.sin(time.monotonic() * 2.2)
        c = r.center()
        rad = r.width() * (0.95 + 0.12 * breathe)
        glow = QRadialGradient(c, rad)
        a1 = QColor(ui.ACCENT)
        a1.setAlpha(int(120 + 70 * breathe))
        a2 = QColor(ui.ACCENT2)
        a2.setAlpha(int(50 + 40 * breathe))
        glow.setColorAt(0.0, a1)
        glow.setColorAt(0.55, a2)
        glow.setColorAt(1.0, QColor(0, 0, 0, 0))
        p.setPen(Qt.NoPen)
        p.setBrush(glow)
        p.drawEllipse(c, rad, rad)
        p.drawPixmap(r.toRect(), ui.app_icon(128).pixmap(128, 128))
        ring = QColor(255, 255, 255, int(60 + 60 * breathe))
        p.setPen(QPen(ring, 1.2))
        p.setBrush(Qt.NoBrush)
        p.drawRoundedRect(r.adjusted(-1, -1, 1, 1), r.width() * 0.27, r.width() * 0.27)
        hub_win = self.plugin.hub.window
        if hub_win.isVisible() and not hub_win.isMinimized():
            y = pill.bottom() - 6 if bottom else pill.top() + 6
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(ui.ACCENT2))
            p.drawEllipse(QPointF(c.x(), y), 2.6, 2.6)

    def _paint_orb(self, p, r):
        g = QLinearGradient(r.topLeft(), r.bottomRight())
        g.setColorAt(0, QColor(ui.ACCENT))
        g.setColorAt(1, QColor(ui.ACCENT2))
        p.setPen(Qt.NoPen)
        p.setBrush(g)
        p.drawEllipse(r.adjusted(2, 2, -2, -2))
        p.setBrush(QColor(255, 255, 255, 40))
        p.drawEllipse(QRectF(r.left() + r.width() * 0.2, r.top() + r.height() * 0.12, r.width() * 0.6, r.height() * 0.35))
        # four-dot "grid" mark: a hint that it opens your apps
        p.setBrush(QColor("white"))
        d = r.width() * 0.09
        for dx in (-1, 1):
            for dy in (-1, 1):
                p.drawEllipse(QPointF(r.center().x() + dx * r.width() * 0.13, r.center().y() + dy * r.width() * 0.13), d, d)

    def _paint_indicator(self, p, r, pill, active, count, bottom):
        style = self.opt("indicator")
        y = pill.bottom() - 6 if bottom else pill.top() + 6
        p.setPen(Qt.NoPen)
        col = QColor(ui.ACCENT2) if active else QColor(255, 255, 255, 170)
        p.setBrush(col)
        if style == "line":
            w = r.width() * (0.55 if active else 0.25)
            p.drawRoundedRect(QRectF(r.center().x() - w / 2, y - 1.5, w, 3), 1.5, 1.5)
        else:
            n = min(count, 3)
            for i in range(n):
                p.drawEllipse(QPointF(r.center().x() + (i - (n - 1) / 2) * 7, y), 2.4 if active else 2, 2.4 if active else 2)

    # --- mouse -----------------------------------------------------------------------------
    def _index_at(self, pt):
        for i, (kind, g, r) in enumerate(self._layout()):
            if kind != "sep" and r.adjusted(-self.opt("spacing") / 2, -12, self.opt("spacing") / 2, 12).contains(pt):
                return i
        return None

    def _item(self, i):
        lay = self._layout()
        return lay[i] if i is not None and 0 <= i < len(lay) else (None, None, None)

    def mouseMoveEvent(self, e):
        x = e.position().x()
        if self.drag is not None:
            self.drag_x = x
            self.update()
            return
        if not self._pill_rect().adjusted(-20, -60, 20, 10).contains(e.position()):
            self.leaveEvent(None)
            return
        if getattr(self, "_press", None) is not None and abs(x - self._press[1]) > 12:
            kind, g, _ = self._item(self._press[0])
            if kind == "app" and g.pin:
                self.drag = (self.groups.index(g), self._press[1])
                self.drag_x = x
        self.mouse_x = x
        self._last_mx = x
        if not self._anim.isActive():
            self._anim.start()
        self.update()

    def leaveEvent(self, e):
        if self.mouse_x is not None:
            self.mouse_x = None
            if not self._anim.isActive():
                self._anim.start()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._press = (self._index_at(e.position()), e.position().x())

    def mouseReleaseEvent(self, e):
        press = getattr(self, "_press", None)
        self._press = None
        if self.drag is not None:
            self._finish_drag(e.position().x())
            return
        i = self._index_at(e.position())
        kind, g, r = self._item(i)
        if kind is None:
            return
        if e.button() == Qt.LeftButton and press and press[0] == i:
            if kind == "orb":
                self.plugin.open_launchpad()
            elif kind == "nexus":
                w = self.plugin.hub.window
                if w.isVisible() and not w.isMinimized() and win.foreground() == int(w.winId()):
                    w.hide()
                else:
                    self.plugin.hub.show_window()
                QTimer.singleShot(200, self.update)
            else:
                self.click_group(g)
        elif e.button() == Qt.MiddleButton and kind == "app":
            self.launch_new(g)
        elif e.button() == Qt.RightButton:
            self.context_menu(g if kind == "app" else None, e.globalPosition().toPoint())

    def _finish_drag(self, x):
        idx, _ = self.drag
        self.drag, self.drag_x = None, None
        la = self.model.launcher()
        if not la:
            return
        items = la.setting("items", [])
        rects = [(g, r) for kind, g, r in self._layout() if kind == "app" and g.pin]
        new = sum(1 for g, r in rects if r.center().x() < x and g is not self.groups[idx])
        it = items.pop(idx)
        items.insert(min(new, len(items)), it)
        la.set_setting("items", items)
        la._build()
        self.refresh_windows()
        self._sig = None
        self.update()

    # --- actions ----------------------------------------------------------------------------
    def click_group(self, g):
        if g.hwnds:
            if self.foreground in g.hwnds:
                if len(g.hwnds) > 1:
                    i = g.hwnds.index(self.foreground)
                    activate(g.hwnds[(i + 1) % len(g.hwnds)])
                else:
                    u32.ShowWindow(self.foreground, 6)   # minimise
            else:
                activate(g.hwnds[0])
        elif g.pin and self.model.launcher():
            self.model.launcher().launch(g.pin, quiet=True)
            if self.opt("bounce"):
                self.bounce[g.key] = 0.0
                self._anim.start()
        QTimer.singleShot(300, self.refresh_windows)

    def launch_new(self, g):
        if g.pin and self.model.launcher():
            self.model.launcher().launch(g.pin, quiet=True)
        elif g.exe and os.path.isfile(g.exe):
            os.startfile(g.exe)

    def context_menu(self, g, pos):
        m = QMenu(self)
        if g is not None:
            for h in g.hwnds[:10]:
                m.addAction(ui.glyph_icon(""), win.title(h)[:60] or g.name, lambda h=h: activate(h))
            if g.hwnds:
                m.addSeparator()
            m.addAction(ui.glyph_icon(""), f"Open {g.name}", lambda: self.launch_new(g))
            la = self.model.launcher()
            if la:
                if g.pin:
                    m.addAction(ui.glyph_icon(""), "Remove from dock", lambda: la.remove_item(g.pin))
                elif g.exe and os.path.isfile(g.exe):
                    m.addAction(ui.glyph_icon(""), "Keep in dock", lambda: la.add(g.name, g.exe, "app"))
            if g.hwnds:
                m.addSeparator()
                m.addAction(ui.glyph_icon(""), "Close window" if len(g.hwnds) == 1 else f"Close {len(g.hwnds)} windows",
                            lambda: [u32.PostMessageW(h, win.WM_CLOSE, 0, 0) for h in g.hwnds])
            m.addSeparator()
        m.addAction(ui.glyph_icon(""), "Wi-Fi", lambda: self.plugin.open_control(0))
        m.addAction(ui.glyph_icon(""), "Sound mixer", lambda: self.plugin.open_control(1))
        m.addAction(ui.glyph_icon(""), "Control Center", lambda: self.plugin.open_control(2))
        m.addSeparator()
        m.addAction(ui.glyph_icon(""), "Show desktop", toggle_desktop)
        m.addAction(ui.glyph_icon(""), "Windows taskbar for 10 s (tray icons)", self.peek_windows_taskbar)
        m.addAction(ui.glyph_icon(""), "Dock settings…", self.plugin.open_settings)
        m.exec(pos)

    def peek_windows_taskbar(self):
        self._peek_until = time.time() + 10
        for h in tray_windows():
            u32.ShowWindow(h, 5)
            win.set_topmost(h, True)
        self.hide()
        self.plugin.island_visible(False)
        QTimer.singleShot(10_500, lambda: (self.show(), self.plugin.island_visible(True)))

    # --- drop to add ---------------------------------------------------------------------------
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        la = self.model.launcher()
        if la:
            for url in e.mimeData().urls():
                la.add_from_url(url)
            self.refresh_windows()


# ====================================================================== the Island
class Island(QWidget):
    """A pill with the time and music that stretches open into a little control centre."""

    def __init__(self, plugin):
        super().__init__(None, Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setMouseTracking(True)
        self.plugin = plugin
        self.t = 0.0             # 0 = compact, 1 = open
        self.eq = [0.3] * 4
        self._hover_timer = QTimer(self, singleShot=True, interval=280, timeout=lambda: self.expand(True))
        self._leave_timer = QTimer(self, singleShot=True, interval=500, timeout=lambda: self.expand(False))
        self._anim = QVariantAnimation(self, duration=260, easingCurve=QEasingCurve.OutCubic)
        self._anim.valueChanged.connect(self._set_t)
        self._tick = QTimer(self, interval=1000, timeout=self._second)
        self._eq_timer = QTimer(self, interval=90, timeout=self._eq_step)
        self._slow = 0
        self.volume = 0.5
        self.muted = False
        self.net = ("", "")
        self.out_name = ""
        self._build_panel()

    # --- geometry -----------------------------------------------------------------
    def compact_size(self):
        sp = self._spotify()
        w = 150
        if self.plugin.opt("island_music") and sp and sp.running and sp.track:
            w += 150
        if self.plugin.opt("seconds"):
            w += 26
        return w, 44

    OPEN = (380, 340)

    def _anchor(self):
        """Where the Island sits: level with the dock's pill (so they look like a pair), or top centre."""
        geo = QGuiApplication.primaryScreen().geometry()
        pos = self.plugin.opt("island")
        dock_bottom = self.plugin.opt("position") == "bottom"
        pill_h = int(self.plugin.opt("icon_size")) + 26
        if pos == "top" and dock_bottom:
            return "top-center", QPoint(geo.center().x(), geo.top() + 10)
        if dock_bottom:
            pill_center = geo.bottom() - 15 - pill_h / 2          # the dock pill ends 15 px above the screen edge
            return "bottom-right", QPoint(geo.right() - 16, int(pill_center + 22))
        pill_center = geo.top() + 16 + pill_h / 2
        return "top-right", QPoint(geo.right() - 16, int(pill_center - 22))

    def _place(self):
        cw, ch = self.compact_size()
        w = cw + (self.OPEN[0] - cw) * self.t
        h = ch + (self.OPEN[1] - ch) * self.t
        mode, a = self._anchor()
        if mode == "top-center":
            x, y = a.x() - w / 2, a.y()
        elif mode == "bottom-right":
            x, y = a.x() - w, a.y() - h          # grows upwards from the bottom edge
        else:
            x, y = a.x() - w, a.y()               # grows downwards from the top edge
        self.setGeometry(int(x), int(y), int(w), int(h))
        self.panel.setGeometry(0, 0, int(w), int(h))

    def _set_t(self, v):
        self.t = float(v)
        self._place()
        self.panel.setVisible(self.t > 0.75)
        self.update()

    def expand(self, on):
        if on and not self.plugin.opt("island_hover") and not getattr(self, "_clicked", False):
            return
        self._clicked = False
        target = 1.0 if on else 0.0
        if abs(self.t - target) < 0.01:
            return
        if on:
            self._refresh_panel()
        self._anim.stop()
        self._anim.setStartValue(self.t)
        self._anim.setEndValue(target)
        self._anim.start()

    def start(self):
        self._second()
        self._place()
        self.show()
        self._tick.start()

    def stop(self):
        self._tick.stop()
        self._eq_timer.stop()
        self.hide()

    # --- mouse ----------------------------------------------------------------------
    def enterEvent(self, e):
        self._leave_timer.stop()
        if self.t < 0.5:
            self._hover_timer.start()

    def leaveEvent(self, e):
        self._hover_timer.stop()
        if self.panel.vol.isSliderDown():
            return
        self._leave_timer.start()

    def mouseReleaseEvent(self, e):
        if self.t < 0.5:
            hit = getattr(self, "_hit", {})
            if hit.get("wifi") and hit["wifi"].contains(e.position()):
                self.plugin.open_control(0)          # Wi-Fi tab
                return
            if hit.get("vol") and hit["vol"].contains(e.position()):
                self.plugin.open_control(1)          # Sound mixer tab
                return
            self._clicked = True
            self.expand(True)

    # --- data ------------------------------------------------------------------------
    def _spotify(self):
        sp = self.plugin.hub.by_id.get("spotify")
        return sp if sp and sp.enabled else None

    def _second(self):
        self._slow -= 1
        if self._slow <= 0:             # the slower stuff only every 3 s
            self._slow = 3
            try:
                spk = audio.speakers()
                self.volume, self.muted = spk.GetMasterVolumeLevelScalar(), bool(spk.GetMute())
            except Exception:
                pass
            stats = psutil.net_if_stats()
            up = [n for n, s in stats.items() if s.isup and not n.lower().startswith(("loopback", "vethernet", "vmware", "virtualbox"))]
            wifi = next((n for n in up if any(k in n.lower() for k in ("wi-fi", "wifi", "wlan", "wireless"))), None)
            self.net = ("", wifi) if wifi else (("", up[0]) if up else ("", "Offline"))
        sp = self._spotify()
        playing = bool(sp and sp.running and sp.track and self.plugin.opt("equalizer"))
        if playing and not self._eq_timer.isActive():
            self._eq_timer.start()
        elif not playing and self._eq_timer.isActive():
            self._eq_timer.stop()
            self.eq = [0.3] * 4
        if self.t == 0:
            self._place()
        elif self.panel.isVisible():
            self._refresh_panel(light=True)
        self.update()

    def _eq_step(self):
        # fake but lively equaliser bars; they only move while music is playing
        import random
        self.eq = [max(0.15, min(1.0, v + random.uniform(-0.35, 0.35))) for v in self.eq]
        if self.t < 0.75:
            self.update()

    # --- compact paint ------------------------------------------------------------------
    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        rad = min(22, r.height() / 2) if self.t < 0.2 else 22
        alpha = int(255 * max(0.9, self.plugin.opt("opacity") / 100))
        g = QLinearGradient(r.topLeft(), r.bottomLeft())
        g.setColorAt(0, QColor(28, 30, 42, alpha))
        g.setColorAt(1, QColor(12, 13, 20, alpha))
        p.setBrush(g)
        edge = QLinearGradient(r.topLeft(), r.topRight())
        a1, a2 = QColor(ui.ACCENT), QColor(ui.ACCENT2)
        a1.setAlpha(150)
        a2.setAlpha(150)
        edge.setColorAt(0, a1)
        edge.setColorAt(1, a2)
        p.setPen(QPen(edge, 1.3))
        p.drawRoundedRect(r, rad, rad)
        if self.t > 0.75:
            return
        p.setOpacity(1 - self.t / 0.75)
        now = datetime.datetime.now()
        fmt = ("%H:%M" if self.plugin.opt("clock24") else "%I:%M") + (":%S" if self.plugin.opt("seconds") else "")
        x = 16.0
        sp = self._spotify()
        if self.plugin.opt("island_music") and sp and sp.running and sp.track:
            # equaliser + song
            for i, v in enumerate(self.eq):
                h = 6 + 16 * v
                c = QColor(ui.ACCENT2) if i % 2 else QColor(ui.ACCENT)
                p.setPen(Qt.NoPen)
                p.setBrush(c)
                p.drawRoundedRect(QRectF(x + i * 5, r.center().y() - h / 2, 3, h), 1.5, 1.5)
            x += 28
            song = sp.track.partition(" - ")[2] or sp.track
            p.setFont(tfont(12, QFont.DemiBold))
            p.setPen(QColor(ui.TEXT))
            p.drawText(QRectF(x, 0, 128, r.height()), Qt.AlignVCenter | Qt.AlignLeft,
                       p.fontMetrics().elidedText(song, Qt.ElideRight, 124))
            x += 136
        # status glyphs
        p.setFont(ui.icon_font(13))
        p.setPen(QColor(ui.MUTED))
        vg = "" if self.muted else ("" if self.volume < 0.34 else "" if self.volume < 0.67 else "")
        self._hit = {"wifi": QRectF(x - 4, 0, 24, r.height()), "vol": QRectF(x + 18, 0, 24, r.height())}
        p.drawText(QRectF(x, 0, 18, r.height()), Qt.AlignCenter, self.net[0])
        p.drawText(QRectF(x + 20, 0, 18, r.height()), Qt.AlignCenter, vg)
        x += 46
        p.setFont(tfont(15, QFont.Bold))
        p.setPen(QColor("white"))
        t = now.strftime(fmt).lstrip("0") if not self.plugin.opt("clock24") else now.strftime(fmt)
        p.drawText(QRectF(x, 0, r.width() - x - 12, r.height()), Qt.AlignVCenter | Qt.AlignRight, t)

    # --- expanded panel -------------------------------------------------------------------
    def _build_panel(self):
        self.panel = QWidget(self)
        self.panel.hide()
        lay = QVBoxLayout(self.panel)
        lay.setContentsMargins(20, 16, 20, 16)
        lay.setSpacing(8)
        self.panel.clock = ui.label("", "big")
        self.panel.date = ui.label("", "muted")
        lay.addLayout(ui.hrow(self.panel.clock, None, self._small_btn("", "Dock settings", self.plugin.open_settings)))
        lay.addWidget(self.panel.date)
        # music
        self.panel.song = ui.label("", "h2")
        self.panel.artist = ui.label("", "muted")
        self.panel.prev = self._small_btn("", "Previous", lambda: self._sp("prev"))
        self.panel.play = self._small_btn("", "Play / pause", lambda: self._sp("play_pause"))
        self.panel.next = self._small_btn("", "Next", lambda: self._sp("next"))
        col = QVBoxLayout()
        col.setSpacing(0)
        col.addWidget(self.panel.song)
        col.addWidget(self.panel.artist)
        music = QHBoxLayout()
        music.addLayout(col, 1)
        for b in (self.panel.prev, self.panel.play, self.panel.next):
            music.addWidget(b)
        self.panel.music = QWidget()
        self.panel.music.setLayout(music)
        music.setContentsMargins(0, 4, 0, 4)
        lay.addWidget(self.panel.music)
        # volume + output
        self.panel.mute = self._small_btn("", "Mute", self._mute)
        self.panel.vol = QSlider(Qt.Horizontal)
        self.panel.vol.setRange(0, 100)
        self.panel.vol.valueChanged.connect(self._set_volume)
        self.vol = self.panel.vol
        lay.addLayout(ui.hrow(self.panel.mute, self.panel.vol))
        self.panel.out = QPushButton()
        self.panel.out.setCursor(Qt.PointingHandCursor)
        self.panel.out.setStyleSheet("text-align:left; padding:6px 10px; font-size:12px;")
        self.panel.out.clicked.connect(self._next_output)
        self.panel.out.setToolTip("Click to switch speakers / headphones")
        lay.addWidget(self.panel.out)
        # quick toggles
        self.panel.chips = QHBoxLayout()
        self.panel.chips.setSpacing(6)
        lay.addLayout(self.panel.chips)
        # doors into the full Control Center
        doors = QHBoxLayout()
        doors.setSpacing(6)
        for i, (glyph, text) in enumerate((("", "Wi-Fi"), ("", "Mixer"), ("", "More"))):
            b = QPushButton(f" {text}")
            b.setIcon(ui.glyph_icon(glyph, "white"))
            b.setCursor(Qt.PointingHandCursor)
            b.setStyleSheet("QPushButton { background: rgba(255,255,255,0.08); border: none; border-radius: 10px;"
                            " padding: 7px; font-size: 12px; font-weight: 600; }"
                            "QPushButton:hover { background: rgba(255,255,255,0.16); }")
            b.clicked.connect(lambda _=False, i=i: (self.expand(False), self.plugin.open_control(i)))
            doors.addWidget(b)
        lay.addLayout(doors)
        lay.addStretch()

    def _small_btn(self, glyph, tip, fn):
        b = QPushButton()
        b.setIcon(ui.glyph_icon(glyph, "white"))
        b.setIconSize(QSize(15, 15))
        b.setFixedSize(34, 30)
        b.setToolTip(tip)
        b.setCursor(Qt.PointingHandCursor)
        b.setStyleSheet("QPushButton { background: rgba(255,255,255,0.07); border: none; border-radius: 9px; }"
                        "QPushButton:hover { background: rgba(255,255,255,0.16); }")
        b.clicked.connect(fn)
        return b

    def _sp(self, action):
        sp = self._spotify()
        if sp:
            sp.on_hotkey(action)
            QTimer.singleShot(900, lambda: self._refresh_panel(light=True))

    def _mute(self):
        try:
            spk = audio.speakers()
            spk.SetMute(int(not spk.GetMute()), None)
            self.muted = bool(spk.GetMute())
        except Exception:
            pass
        self._refresh_panel(light=True)

    def _set_volume(self, v):
        try:
            audio.speakers().SetMasterVolumeLevelScalar(v / 100, None)
            self.volume = v / 100
        except Exception:
            pass

    def _next_output(self):
        snd = self.plugin.hub.by_id.get("sound")
        if snd and snd.enabled:
            snd.next_output()
        self._refresh_panel()

    def _toggle_chips(self):
        """(label, glyph, is_on, toggle) for modules that are switched on."""
        hub = self.plugin.hub
        out = []
        ka = hub.by_id.get("keepawake")
        if ka and ka.enabled:
            out.append(("Awake", "", ka.active, lambda: ka.on_hotkey("toggle")))
        d = hub.by_id.get("display")
        if d and d.enabled:
            out.append(("Night", "", bool(d.setting("night", False)), lambda: d.on_hotkey("night")))
        gm = hub.by_id.get("gamemode")
        if gm and gm.enabled:
            out.append(("Game", "", gm.active, lambda: gm.on_hotkey("toggle")))
        w = hub.by_id.get("widgets")
        if w and w.enabled:
            out.append(("Widgets", "", bool(w.shown), lambda: w.on_hotkey("toggle")))
        so = hub.by_id.get("sound")
        if so and so.enabled:
            try:
                mic_muted = bool(audio.microphone().GetMute())
            except Exception:
                mic_muted = False
            out.append(("Mic", "", not mic_muted, lambda: so.on_hotkey("mic")))
        return out[:5]

    def _refresh_panel(self, light=False):
        pn = self.panel
        now = datetime.datetime.now()
        pn.clock.setText(now.strftime("%H:%M" if self.plugin.opt("clock24") else "%I:%M %p").lstrip("0"))
        pn.date.setText(now.strftime("%A, %d %B %Y") if self.plugin.opt("show_date") else "")
        sp = self._spotify()
        pn.music.setVisible(bool(self.plugin.opt("island_music") and sp and sp.running))
        if sp and sp.running:
            artist, _, song = sp.track.partition(" - ")
            pn.song.setText((song or sp.track or "Paused")[:34])
            pn.artist.setText(artist if song else "Spotify")
            pn.play.setIcon(ui.glyph_icon("" if sp.track else "", "white"))
        if not pn.vol.isSliderDown():
            pn.vol.blockSignals(True)
            pn.vol.setValue(round(self.volume * 100))
            pn.vol.blockSignals(False)
        pn.mute.setIcon(ui.glyph_icon("" if self.muted else "", ui.BAD if self.muted else "white"))
        if light:
            return
        try:
            cur = audio.default_output_id()
            name = next((n for i, n in audio.outputs() if i == cur), "")
        except Exception:
            name = ""
        pn.out.setText(f"   Output:  {audio.short_name(name) if name else 'unknown'}     ⇄")
        pn.out.setIcon(ui.glyph_icon("", ui.ACCENT2))
        while pn.chips.count():
            w = pn.chips.takeAt(0).widget()
            if w:
                w.deleteLater()
        if self.plugin.opt("toggles"):
            for label, glyph, on, fn in self._toggle_chips():
                b = QPushButton(label)
                b.setIcon(ui.glyph_icon(glyph, "white"))
                b.setCursor(Qt.PointingHandCursor)
                b.setStyleSheet(
                    "QPushButton { border: none; border-radius: 10px; padding: 7px 8px; font-size: 11px; font-weight: 600;"
                    + (f" background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 {ui.ACCENT}, stop:1 {ui.ACCENT2}); color: white; }}"
                       if on else " background: rgba(255,255,255,0.08); }"))
                b.clicked.connect(lambda _=False, fn=fn: (fn(), QTimer.singleShot(300, self._refresh_panel)))
                pn.chips.addWidget(b)
        pn.chips.addStretch()


# ====================================================================== Launchpad
class Launchpad(QWidget):
    """Full-screen app grid with search. Opened from the orb or its hotkey."""

    def __init__(self, plugin):
        super().__init__(None, Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setMouseTracking(True)
        self.plugin = plugin
        self.model = plugin.model
        self.tiles = []          # (kind, name, payload)
        self.actions = []        # Nexus Bar results while searching
        self.hover = None
        self.scroll = 0.0
        self.t = 0.0
        self.search = QLineEdit(self, placeholderText="Search your apps, NexusHub actions and the web…")
        self.search.setStyleSheet(
            f"QLineEdit {{ background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.14);"
            f" border-radius: 22px; padding: 10px 20px; font-size: 16px; color: white; }}"
            f"QLineEdit:focus {{ border-color: {ui.ACCENT}; }}")
        self.search.textChanged.connect(self._filter)
        self.search.returnPressed.connect(self._enter)
        self.search.installEventFilter(self)
        self._anim = QVariantAnimation(self, duration=240, easingCurve=QEasingCurve.OutCubic)
        self._anim.valueChanged.connect(lambda v: (setattr(self, "t", float(v)), self.update()))
        self._loader = QTimer(self, interval=30, timeout=self._load_some)
        self._pending = []

    def popup(self):
        geo = QGuiApplication.primaryScreen().geometry()
        self.setGeometry(geo)
        self.search.setGeometry(self.width() // 2 - 280, 70, 560, 46)
        self.search.clear()
        self.scroll = 0
        self._filter("")
        self.show()
        self.raise_()
        self.activateWindow()
        activate(int(self.winId()))
        self.search.setFocus()
        self._anim.stop()
        self._anim.setStartValue(0.0)
        self._anim.setEndValue(1.0)
        self._anim.start()

    def close_pad(self):
        self._loader.stop()
        self.hide()

    # --- content ----------------------------------------------------------------------
    def _filter(self, text):
        q = text.strip().lower()
        pins = [("pin", it["name"], it) for it in self.model.pins()]
        apps = [("app", n, t) for n, t in sorted(icons.installed_apps(), key=lambda a: a[0].lower())] \
            if self.plugin.opt("lp_all_apps") else []
        pinned_names = {n.lower() for _, n, _ in pins}
        apps = [a for a in apps if a[1].lower() not in pinned_names]
        if q:
            tiles = [t for t in pins + apps if q in t[1].lower()]
            tiles.sort(key=lambda t: (not t[1].lower().startswith(q), t[1].lower()))
            nb = self.plugin.hub.by_id.get("nexusbar")
            self.actions = [a for a in (nb.search(text)[:5] if nb and nb.enabled else []) if not a.key.startswith("app:")][:4]
        else:
            tiles = pins + ([("sep", "All apps", None)] if apps and pins else []) + apps
            self.actions = []
        self.tiles = tiles
        self.hover = 0 if q and tiles else None
        self.scroll = 0
        self._pending = [t for t in tiles if t[0] == "app" and t[2] not in self.model.app_icons]
        if self._pending:
            self._loader.start()
        self.update()

    def _load_some(self):
        # real icons load a few at a time so the Launchpad opens instantly
        # never sleep here (it would freeze the UI): try once, and if Explorer isn't ready, retry later
        for _ in range(3):
            if not self._pending:
                self._loader.stop()
                break
            kind, name, target, *tries = self._pending.pop(0)
            tries = tries[0] if tries else 0
            pm = icons.best_icon(target, 128, retries=1)
            if pm is None and tries < 2:
                self._pending.append((kind, name, target, tries + 1))
                continue
            self.model.app_icons[target] = pm if pm is not None else letter_tile(name, 128)
        self.update()

    def _tile_pm(self, kind, name, payload):
        if kind == "pin":
            la = self.model.launcher()
            return la.item_pixmap(payload, 128) if la else letter_tile(name, 128)
        pm = self.model.app_icons.get(payload)
        return pm if pm is not None else letter_tile(name, 128)

    # --- layout -----------------------------------------------------------------------
    def _grid(self):
        cols = int(self.plugin.opt("lp_columns"))
        icon = int(self.plugin.opt("lp_icon"))
        cell_w, cell_h = icon + 70, icon + 48
        total_w = cols * cell_w
        x0 = (self.width() - total_w) / 2
        y = 150 + (len(self.actions) * 44 + 16 if self.actions else 0) - self.scroll
        out = []
        col = 0
        for i, t in enumerate(self.tiles):
            if t[0] == "sep":
                if col:
                    y += cell_h
                    col = 0
                out.append((i, QRectF(x0, y + 10, total_w, 30)))
                y += 44
                continue
            r = QRectF(x0 + col * cell_w, y, cell_w, cell_h)
            out.append((i, r))
            col += 1
            if col == cols:
                col = 0
                y += cell_h
        self._content_h = y + (cell_h if col else 0) + self.scroll
        return out

    def _power_rects(self):
        out = []
        for i, (glyph, label, fn) in enumerate(self._power()):
            out.append((QRectF(self.width() - 70 - i * 58, self.height() - 80, 46, 46), glyph, label, fn))
        return out

    def _power(self):
        return [("", "Shut down", lambda: self._confirm("Shut down", lambda: os.system("shutdown /s /t 0"))),
                ("", "Restart", lambda: self._confirm("Restart", lambda: os.system("shutdown /r /t 0"))),
                ("", "Sleep", lambda: self._confirm("Sleep", lambda: ctypes.windll.powrprof.SetSuspendState(False, False, False))),
                ("", "Lock", lambda: (self.close_pad(), win.lock_pc()))]

    def _confirm(self, what, fn):
        self.close_pad()
        if QMessageBox.question(None, what, f"{what} your PC now? Save your work first.") == QMessageBox.Yes:
            fn()

    # --- paint ----------------------------------------------------------------------------
    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        t = self.t
        dim = self.plugin.opt("lp_dim") / 100
        p.fillRect(self.rect(), QColor(6, 7, 12, int(255 * dim * t)))
        for cx, cy, col in ((0.2, 0.15, ui.ACCENT), (0.85, 0.8, ui.ACCENT2)):
            g = QRadialGradient(QPointF(self.width() * cx, self.height() * cy), self.width() * 0.45)
            c = QColor(col)
            c.setAlpha(int(55 * t))
            g.setColorAt(0, c)
            c.setAlpha(0)
            g.setColorAt(1, c)
            p.fillRect(self.rect(), g)
        p.setOpacity(t)
        now = datetime.datetime.now()
        p.setFont(tfont(15, QFont.DemiBold))
        p.setPen(QColor(255, 255, 255, 200))
        hour = now.hour
        greet = "Good morning" if 5 <= hour < 12 else "Good afternoon" if hour < 18 else "Good evening"
        p.drawText(QRectF(40, 30, 600, 30), Qt.AlignLeft, f"{greet}, {os.environ.get('USERNAME', '')}")
        p.setFont(tfont(13))
        p.setPen(QColor(255, 255, 255, 140))
        p.drawText(QRectF(40, 56, 600, 24), Qt.AlignLeft, now.strftime("%A %d %B · %H:%M"))

        # action results (while searching)
        y = 140
        for i, a in enumerate(self.actions):
            r = QRectF(self.width() / 2 - 280, y, 560, 38)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(255, 255, 255, 18))
            p.drawRoundedRect(r, 12, 12)
            p.setFont(ui.icon_font(14))
            p.setPen(QColor(ui.ACCENT2))
            p.drawText(QRectF(r.left() + 12, r.top(), 24, r.height()), Qt.AlignCenter, a.glyph)
            p.setFont(tfont(13, QFont.DemiBold))
            p.setPen(QColor("white"))
            p.drawText(r.adjusted(46, 0, -10, 0), Qt.AlignVCenter | Qt.AlignLeft, a.title)
            p.setFont(tfont(11))
            p.setPen(QColor(255, 255, 255, 120))
            p.drawText(r.adjusted(0, 0, -14, 0), Qt.AlignVCenter | Qt.AlignRight, a.sub)
            y += 44

        icon = int(self.plugin.opt("lp_icon"))
        p.setClipRect(QRectF(0, 130, self.width(), self.height() - 230))
        grow = 0.85 + 0.15 * t
        for i, r in self._grid():
            kind, name, payload = self.tiles[i]
            if r.bottom() < 120 or r.top() > self.height():
                continue
            if kind == "sep":
                p.setFont(tfont(13, QFont.DemiBold))
                p.setPen(QColor(255, 255, 255, 150))
                p.drawText(r, Qt.AlignLeft | Qt.AlignVCenter, "   " + name.upper())
                continue
            if i == self.hover:
                p.setPen(Qt.NoPen)
                p.setBrush(QColor(255, 255, 255, 22))
                p.drawRoundedRect(r.adjusted(8, 2, -8, -2), 18, 18)
            s = icon * grow * (1.08 if i == self.hover else 1.0)
            ir = QRectF(r.center().x() - s / 2, r.top() + 10 + (icon - s) / 2, s, s)
            p.drawPixmap(ir.toRect(), self._tile_pm(kind, name, payload))
            p.setFont(tfont(12))
            p.setPen(QColor("white"))
            p.drawText(QRectF(r.left() + 4, r.top() + icon + 16, r.width() - 8, 22), Qt.AlignHCenter | Qt.AlignTop,
                       p.fontMetrics().elidedText(name, Qt.ElideRight, int(r.width() - 10)))
        p.setClipping(False)
        if not self.tiles and not self.actions:
            p.setFont(tfont(15))
            p.setPen(QColor(255, 255, 255, 150))
            p.drawText(QRectF(0, 200, self.width(), 40), Qt.AlignCenter,
                       "Nothing found. Press Enter to search the web")
        # power buttons
        for r, glyph, label, fn in self._power_rects():
            hov = r.contains(QPointF(self.mapFromGlobal(QCursor.pos())))
            p.setPen(QPen(QColor(255, 255, 255, 40), 1))
            p.setBrush(QColor(255, 255, 255, 40 if hov else 16))
            p.drawEllipse(r)
            p.setFont(ui.icon_font(17))
            p.setPen(QColor("white"))
            p.drawText(r, Qt.AlignCenter, glyph)
            if hov:
                p.setFont(tfont(11))
                p.drawText(QRectF(r.center().x() - 50, r.top() - 22, 100, 18), Qt.AlignCenter, label)
        p.setFont(tfont(11))
        p.setPen(QColor(255, 255, 255, 90))
        p.drawText(QRectF(0, self.height() - 34, self.width(), 20), Qt.AlignCenter,
                   "Type to search · Enter opens · Esc or click empty space to close")

    # --- input ---------------------------------------------------------------------------------
    def _tile_at(self, pt):
        for i, r in self._grid():
            if self.tiles[i][0] != "sep" and r.contains(pt) and 130 < pt.y() < self.height() - 100:
                return i
        return None

    def mouseMoveEvent(self, e):
        h = self._tile_at(e.position())
        if h != self.hover:
            self.hover = h
            self.update()
        else:
            self.update(QRect(self.width() - 320, self.height() - 120, 320, 120))   # power hover labels

    def mouseReleaseEvent(self, e):
        pt = e.position()
        for r, glyph, label, fn in self._power_rects():
            if r.contains(pt):
                fn()
                return
        y = 140
        for a in self.actions:
            if QRectF(self.width() / 2 - 280, y, 560, 38).contains(pt):
                self._run_action(a)
                return
            y += 44
        i = self._tile_at(pt)
        if i is None:
            self.close_pad()
        else:
            self._launch(i)

    def wheelEvent(self, e):
        self._grid()
        max_scroll = max(0.0, self._content_h - (self.height() - 120))
        self.scroll = max(0.0, min(max_scroll, self.scroll - e.angleDelta().y() * 0.8))
        self.update()

    def eventFilter(self, obj, e):
        if e.type() == QEvent.KeyPress:
            k = e.key()
            if k == Qt.Key_Escape:
                self.close_pad()
                return True
            cols = int(self.plugin.opt("lp_columns"))
            moves = {Qt.Key_Right: 1, Qt.Key_Left: -1, Qt.Key_Down: cols, Qt.Key_Up: -cols}
            if k in moves and self.tiles:
                cur = self.hover if self.hover is not None else -moves[k]
                nxt = max(0, min(len(self.tiles) - 1, cur + moves[k]))
                while 0 < nxt < len(self.tiles) - 1 and self.tiles[nxt][0] == "sep":
                    nxt += 1 if moves[k] > 0 else -1
                self.hover = nxt
                self.update()
                return True
        return super().eventFilter(obj, e)

    def changeEvent(self, e):
        if e.type() == QEvent.ActivationChange and not self.isActiveWindow() and self.isVisible():
            QTimer.singleShot(0, self.close_pad)
        super().changeEvent(e)

    def _enter(self):
        if self.hover is not None and self.tiles:
            self._launch(self.hover)
        elif self.actions:
            self._run_action(self.actions[0])
        elif self.search.text().strip():
            q = self.search.text().strip()
            nb = self.plugin.hub.by_id.get("nexusbar")
            items = nb.search(q) if nb and nb.enabled else []
            if items:
                self._run_action(items[-1])      # the "search the web" row

    def _launch(self, i):
        kind, name, payload = self.tiles[i]
        self.close_pad()
        if kind == "pin":
            la = self.model.launcher()
            if la:
                la.launch(payload, quiet=True)
        elif kind == "app":
            QTimer.singleShot(50, lambda: os.startfile(payload))

    def _run_action(self, a):
        self.close_pad()
        nb = self.plugin.hub.by_id.get("nexusbar")
        if nb:
            nb.bump(a.key)
        QTimer.singleShot(60, a.run)


# ====================================================================== plugin
class Taskbar(Plugin):
    id = "taskbar"
    name = "Nexus Dock"
    icon = ""
    category = "Desktop"
    order = 3
    default_enabled = False
    description = "Replace the Windows taskbar with a magnifying dock, a live Island (music, volume, toggles) and a Launchpad."
    hotkeys = {
        "launchpad": ("Open the Launchpad", "ctrl+alt+shift+space"),
        "peek": ("Show the Windows taskbar for 10 s (tray icons)", "ctrl+alt+shift+t"),
        "island": ("Open / close the Island", ""),
        "control": ("Open the Control Center (Wi-Fi, sound mixer, toggles)", "ctrl+alt+i"),
    }

    def __init__(self, hub):
        super().__init__(hub)
        self.model = AppModel(self)
        self.dock = None
        self.island = None
        self.pad = None
        self.cc = None
        self._warm = []
        self._warm_timer = QTimer(self, interval=60, timeout=self._warm_icons)

    def opt(self, key):
        return self.setting(key, DEFAULTS[key])

    # --- lifecycle ----------------------------------------------------------------
    def on_enable(self):
        hide_windows_taskbar()
        try:
            la = self.hub.by_id.get("launcher")
            if la and la.dock:                      # the Nexus Dock replaces Quick Launch's own dock
                la.set_dock(False, save=False)
            self._build()
        except Exception:
            show_windows_taskbar()                  # never leave you without a taskbar
            raise
        # quietly pre-load Launchpad icons in the background so it opens instantly later
        QTimer.singleShot(6000, self._start_warmup)

    def on_disable(self):
        self._warm_timer.stop()
        self._teardown()
        show_windows_taskbar()
        la = self.hub.by_id.get("launcher")
        if la and la.enabled and la.setting("dock_on", True) and not la.dock:
            la.set_dock(True, save=False)

    def _build(self):
        self._teardown()
        self.dock = Dock(self)
        self.dock.start()
        if self.opt("island") != "off":
            self.island = Island(self)
            self.island.start()

    def _teardown(self):
        if self.cc is not None:
            self.cc.hide()
            self.cc.deleteLater()
            self.cc = None
        for w in (self.dock, self.island, self.pad):
            if w is not None:
                (w.stop() if hasattr(w, "stop") else w.close_pad())
                w.deleteLater()
        self.dock = self.island = self.pad = None

    def _start_warmup(self):
        self._warm = [t for _, t in icons.installed_apps() if t not in self.model.app_icons]
        self._warm_timer.start()

    def _warm_icons(self):
        if not self._warm or (self.pad and self.pad.isVisible()):
            if not self._warm:
                self._warm_timer.stop()
            return
        t = self._warm.pop(0)
        pm = icons.best_icon(t, 128, retries=1)
        if pm is not None:
            self.model.app_icons[t] = pm

    def island_visible(self, on):
        if self.island:
            self.island.setVisible(on)

    def status(self):
        return "Dock, Island and Launchpad active" if self.dock else "Off (Windows taskbar in use)"

    def tray_actions(self):
        return [("Open the Launchpad", lambda: self.on_hotkey("launchpad")),
                ("Show Windows taskbar for 10 s", lambda: self.on_hotkey("peek"))]

    def on_hotkey(self, action):
        if not self.dock:
            return
        if action == "launchpad":
            self.open_launchpad()
        elif action == "peek":
            self.dock.peek_windows_taskbar()
        elif action == "island" and self.island:
            self.island._clicked = True
            self.island.expand(self.island.t < 0.5)
        elif action == "control":
            self.open_control(0, toggle=True)

    def open_control(self, tab=0, toggle=False):
        """The Control Center pops up next to the Island (or the right end of the dock)."""
        from core.control_center import ControlCenter
        if self.cc is None:
            self.cc = ControlCenter(self.hub, self._cc_anchor)
        if toggle:
            self.cc.toggle(tab)
        else:
            self.cc.open(tab)

    def _cc_anchor(self):
        geo = QGuiApplication.primaryScreen().geometry()
        bottom = self.opt("position") == "bottom"
        if self.island and self.island.isVisible() and self.opt("island") != "top":
            g = self.island.geometry()
            return g.right(), (g.top() if bottom else g.bottom()), bottom
        edge = geo.bottom() - self.dock.strip_height() if (self.dock and bottom) else geo.top() + (
            self.dock.strip_height() if self.dock else 40)
        return geo.right() - 16, edge, bottom

    def open_launchpad(self):
        if self.pad is None:
            self.pad = Launchpad(self)
        if self.pad.isVisible():
            self.pad.close_pad()
        else:
            self.pad.popup()

    def open_settings(self):
        self.hub.show_window()
        self.hub.window.open_page(self.id)

    # --- settings ---------------------------------------------------------------
    def _set(self, key, value, rebuild=False):
        self.set_setting(key, value)
        if not self.dock:
            return
        if rebuild:
            self._build()
        else:
            self.dock.apply_settings()
            if self.island:
                self.island._place()
                self.island.update()
            if self.pad and key.startswith("lp_"):
                self.pad.update()

    def _slider(self, key, lo, hi, suffix="", rebuild=False):
        s = QSlider(Qt.Horizontal)
        s.setRange(lo, hi)
        s.setValue(int(self.opt(key)))
        s.setFixedWidth(260)
        lbl = ui.label(f"{self.opt(key)}{suffix}", "muted")
        lbl.setFixedWidth(48)
        s.valueChanged.connect(lambda v: (lbl.setText(f"{v}{suffix}"), self._set(key, v, rebuild)))
        w = QWidget()
        w.setLayout(ui.hrow(s, lbl))
        w.setFixedWidth(330)          # every slider row lines up in one clean column
        return w

    def _combo(self, key, options, rebuild=False):
        c = QComboBox()
        for text, v in options:
            c.addItem(text, v)
        c.setCurrentIndex(max(0, c.findData(self.opt(key))))
        c.currentIndexChanged.connect(lambda _: self._set(key, c.currentData(), rebuild))
        return c

    def _switch(self, key, rebuild=False):
        sw = ui.ToggleSwitch(bool(self.opt(key)))
        sw.toggled.connect(lambda on: self._set(key, on, rebuild))
        return sw

    def create_page(self):
        page = QWidget()
        self._page = page
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)

        intro = ui.Card()
        intro.add(ui.label("Your desktop, your rules ✨", "h2"))
        intro.add(ui.label(
            "The ● orb opens the Launchpad. Hover the dock to magnify; drag pinned apps to reorder; drop files or "
            "links on it to add them; right-click anything for options. Hover the Island for music, volume, output "
            "and quick toggles. The Windows taskbar is only hidden: switching this off, quitting, or a crash always "
            "brings it back.", "muted", wrap=True))
        intro.add(ui.hrow(ui.button("Open Launchpad", "primary", "", self.open_launchpad),
                          ui.button("Pinned apps (Quick Launch)", None, "", lambda: self.hub.window.open_page("launcher")),
                          ui.button("Windows taskbar for 10 s", "ghost", "", lambda: self.on_hotkey("peek")), None))
        lay.addWidget(intro)

        dock = ui.Card("Dock", "")
        dock.add(ui.hrow(ui.label("Position"), None, self._combo("position", [("Bottom", "bottom"), ("Top", "top")], rebuild=True)))
        dock.add(ui.hrow(ui.label("Icon size"), None, self._slider("icon_size", 32, 80, " px")))
        dock.add(ui.hrow(ui.label("Magnification on hover"), None, self._slider("magnify", 0, 120, "%")))
        dock.add(ui.hrow(ui.label("Space between icons"), None, self._slider("spacing", 2, 30, " px")))
        dock.add(ui.hrow(ui.label("Background opacity"), None, self._slider("opacity", 0, 100, "%")))
        dock.add(ui.hrow(ui.label("Corner roundness"), None, self._slider("roundness", 0, 40, " px")))
        tint = self._combo("tint", [("Glass", "glass"), ("Accent colour", "accent"), ("Pure dark", "dark"), ("Custom colour…", "custom")])

        def tint_changed(_):
            if tint.currentData() == "custom":
                c = QColorDialog.getColor(QColor(self.opt("tint_color")), None, "Dock colour")
                if c.isValid():
                    self._set("tint_color", c.name())
        tint.currentIndexChanged.connect(tint_changed)
        dock.add(ui.hrow(ui.label("Colour"), None, tint))
        dock.add(ui.hrow(ui.label("Running-app indicator"), None,
                         self._combo("indicator", [("Dots", "dot"), ("Line", "line"), ("Glow", "glow")])))
        for key, text in (("orb", "Launchpad orb at the start of the dock"),
                          ("nexus_pin", "NexusHub pinned in the middle, with a glow"),
                          ("show_running", "Show open apps that aren't pinned"),
                          ("separators", "Separators between sections"),
                          ("labels", "Name labels on hover"),
                          ("bounce", "Bounce when an app launches"),
                          ("autohide", "Auto-hide: slides away until you push the mouse to the edge"),
                          ("reserve", "Keep maximised windows above the dock")):
            dock.add(ui.hrow(ui.label(text), None, self._switch(key)))
        lay.addWidget(dock)

        isl = ui.Card("Island", "")
        isl.add(ui.hrow(ui.label("Where"), None, self._combo(
            "island", [("Next to the dock (right)", "right"), ("Top centre", "top"), ("Off", "off")], rebuild=True)))
        for key, text in (("island_hover", "Opens when you hover it (off = click to open)"),
                          ("clock24", "24-hour clock"), ("seconds", "Show seconds"), ("show_date", "Date in the open view"),
                          ("island_music", "Spotify song and controls"), ("equalizer", "Dancing equaliser while music plays"),
                          ("toggles", "Quick toggles (Awake, Night, Game, Widgets, Mic)")):
            isl.add(ui.hrow(ui.label(text), None, self._switch(key)))
        lay.addWidget(isl)

        lp = ui.Card("Launchpad", "")
        lp.add(ui.hrow(ui.label("Columns"), None, self._slider("lp_columns", 4, 10)))
        lp.add(ui.hrow(ui.label("Icon size"), None, self._slider("lp_icon", 48, 110, " px")))
        lp.add(ui.hrow(ui.label("Background darkness"), None, self._slider("lp_dim", 30, 95, "%")))
        lp.add(ui.hrow(ui.label("Show all installed apps (not just pinned)"), None, self._switch("lp_all_apps")))
        lay.addWidget(lp)

        safe = ui.Card("Reset & safety", "")
        safe.add(ui.hrow(ui.button("Reset all dock settings", None, "", self._reset),
                         ui.button("Bring back the Windows taskbar", "danger", "",
                                   lambda: self.hub.set_enabled(self, False)), None))
        lay.addWidget(safe)
        return page

    def _reset(self):
        for k in DEFAULTS:
            self.settings.pop(k, None)
        self.hub.config.save()
        if self.dock:
            self._build()
        self.notify("Dock settings reset. Reopen this page to see them", self.icon)
