"""Live CPU / RAM / network / disk monitor with an in-game overlay."""
import datetime
import time

import psutil
from PySide6.QtCore import QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QCursor, QFont, QGuiApplication, QPainter
from PySide6.QtWidgets import (QComboBox, QGridLayout, QMessageBox, QProgressBar, QTreeWidget,
                               QTreeWidgetItem, QVBoxLayout, QWidget)

from core import ui
from core.plugin import Plugin


class Overlay(QWidget):
    """Tiny click-through stats box that floats over everything (borderless games included)."""

    def __init__(self, plugin):
        super().__init__(None, Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint
                         | Qt.WindowTransparentForInput | Qt.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.plugin = plugin
        self.lines = []
        self.setFixedSize(190, 104)

    def place(self):
        screen = QGuiApplication.primaryScreen().geometry()
        corner = self.plugin.setting("corner", "top-right")
        m = 14
        x = screen.left() + m if "left" in corner else screen.right() - self.width() - m
        y = screen.top() + m if "top" in corner else screen.bottom() - self.height() - m
        self.move(x, y)

    def set_lines(self, lines):
        self.lines = lines
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setBrush(QColor(10, 12, 18, 175))
        p.setPen(Qt.NoPen)
        p.drawRoundedRect(QRectF(self.rect()), 12, 12)
        f = QFont("Consolas")
        f.setPixelSize(13)
        p.setFont(f)
        y = 12
        for label, value, color in self.lines:
            p.setPen(QColor(ui.MUTED))
            p.drawText(QRectF(14, y, 60, 18), Qt.AlignLeft | Qt.AlignVCenter, label)
            p.setPen(QColor(color))
            p.drawText(QRectF(60, y, self.width() - 74, 18), Qt.AlignRight | Qt.AlignVCenter, value)
            y += 20


def level_color(pct):
    return ui.GOOD if pct < 60 else ui.WARN if pct < 85 else ui.BAD


class SysMonitor(Plugin):
    id = "sysmonitor"
    name = "System Monitor"
    icon = ""
    category = "System"
    order = 40
    description = "Live CPU, memory, network and disk usage, the apps using the most, and an overlay you can keep on top of games."
    hotkeys = {"overlay": ("Show / hide stats overlay", "ctrl+alt+o")}

    def __init__(self, hub):
        super().__init__(hub)
        self._timer = QTimer(self, interval=1000, timeout=self._sample)
        self._last_net = None
        self.cpu = self.ram = 0.0
        self.down = self.up = 0.0
        self.overlay = None
        self._slow = 0

    def on_enable(self):
        psutil.cpu_percent(None)
        self._last_net = (time.monotonic(), psutil.net_io_counters())
        self._timer.start()
        if self.setting("overlay", False):
            self._show_overlay(True)

    def on_disable(self):
        self._timer.stop()
        if self.overlay:
            self.overlay.close()
            self.overlay = None

    def status(self):
        return f"CPU {self.cpu:.0f}%  ·  RAM {self.ram:.0f}%  ·  ↓ {ui.human_bytes(self.down, True)}"

    def tray_actions(self):
        return [("Hide stats overlay" if self.overlay else "Show stats overlay", lambda: self.on_hotkey("overlay"))]

    def on_hotkey(self, action):
        if action == "overlay":
            on = self.overlay is None
            self._show_overlay(on)
            self.set_setting("overlay", on)
            self.notify("Stats overlay on" if on else "Stats overlay off")

    def _show_overlay(self, on):
        if on and not self.overlay:
            self.overlay = Overlay(self)
            self.overlay.place()
            self.overlay.show()
            self._sample()
        elif not on and self.overlay:
            self.overlay.close()
            self.overlay = None

    # ------------------------------------------------------------ sampling
    def _sample(self):
        self.cpu = psutil.cpu_percent(None)
        vm = psutil.virtual_memory()
        self.ram = vm.percent
        now, net = time.monotonic(), psutil.net_io_counters()
        t0, n0 = self._last_net
        dt = max(0.001, now - t0)
        self.down = (net.bytes_recv - n0.bytes_recv) / dt
        self.up = (net.bytes_sent - n0.bytes_sent) / dt
        self._last_net = (now, net)

        if self.overlay:
            self.overlay.set_lines([
                ("CPU", f"{self.cpu:.0f}%", level_color(self.cpu)),
                ("RAM", f"{self.ram:.0f}%", level_color(self.ram)),
                ("NET", f"↓{ui.human_bytes(self.down, True)}", ui.ACCENT2),
                ("TIME", datetime.datetime.now().strftime("%H:%M"), ui.TEXT),
            ])
            self.overlay.raise_()

        if self._page is None or not self._page.isVisible():
            return
        self.g_cpu.push(self.cpu)
        self.g_ram.push(self.ram)
        self.g_down.push(self.down)
        self.g_up.push(self.up)
        self.v_cpu.setText(f"{self.cpu:.0f}%")
        self.v_ram.setText(f"{self.ram:.0f}%")
        self.s_ram.setText(f"{ui.human_bytes(vm.used)} of {ui.human_bytes(vm.total)}")
        self.v_down.setText(ui.human_bytes(self.down, True))
        self.v_up.setText(ui.human_bytes(self.up, True))
        self._slow -= 1
        if self._slow <= 0:
            self._slow = 3
            self._update_processes()
            self._update_disks()

    def _update_processes(self):
        n = psutil.cpu_count() or 1
        rows = []
        for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_info"]):
            info = proc.info
            if not info["name"] or info["pid"] == 0 or info["name"] == "System Idle Process":
                continue
            mem = info["memory_info"].rss if info["memory_info"] else 0
            rows.append(((info["cpu_percent"] or 0) / n, mem, info["name"], info["pid"]))
        key = 0 if self.sort.currentIndex() == 0 else 1
        rows.sort(key=lambda r: r[key], reverse=True)
        self.procs.clear()
        for cpu, mem, name, pid in rows[:12]:
            it = QTreeWidgetItem([name, f"{cpu:.1f}%", ui.human_bytes(mem), str(pid)])
            it.setData(0, Qt.UserRole, pid)
            self.procs.addTopLevelItem(it)

    def _update_disks(self):
        for bar, lbl, mount in self.disk_rows:
            try:
                du = psutil.disk_usage(mount)
            except OSError:
                continue
            bar.setValue(int(du.percent))
            lbl.setText(f"{ui.human_bytes(du.free)} free of {ui.human_bytes(du.total)}")

    def _kill_selected(self):
        it = self.procs.currentItem()
        if not it:
            return
        pid, name = it.data(0, Qt.UserRole), it.text(0)
        if QMessageBox.question(None, "End app", f"Force close {name}? Unsaved work in it will be lost.") != QMessageBox.Yes:
            return
        try:
            psutil.Process(pid).kill()
            self.notify(f"Closed {name}", "")
        except psutil.Error as e:
            self.notify(f"Couldn't close {name}", "")
        self._update_processes()

    # ------------------------------------------------------------ page
    def _stat_card(self, title, glyph, color, max_value=None):
        card = ui.Card(title, glyph)
        value = ui.label("–", "big")
        sub = ui.label("", "muted")
        graph = ui.LineGraph(color, max_value=max_value)
        card.header.addWidget(value)
        card.add(graph)
        card.add(sub)
        return card, value, sub, graph

    def create_page(self):
        page = QWidget()
        self._page = page   # so refresh helpers work while building
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)
        grid = QGridLayout()
        grid.setSpacing(14)
        c1, self.v_cpu, s_cpu, self.g_cpu = self._stat_card("Processor", "", ui.ACCENT, 100)
        s_cpu.setText(f"{psutil.cpu_count(logical=False)} cores · {psutil.cpu_count()} threads")
        c2, self.v_ram, self.s_ram, self.g_ram = self._stat_card("Memory", "", ui.ACCENT2, 100)
        c3, self.v_down, s3, self.g_down = self._stat_card("Download", "", ui.GOOD)
        c4, self.v_up, s4, self.g_up = self._stat_card("Upload", "", ui.WARN)
        s3.setText("Across all network adapters")
        s4.setText("Across all network adapters")
        for i, c in enumerate((c1, c2, c3, c4)):
            grid.addWidget(c, i // 2, i % 2)
        lay.addLayout(grid)

        disks = ui.Card("Drives", "")
        self.disk_rows = []
        for part in psutil.disk_partitions():
            if "cdrom" in part.opts or not part.fstype:
                continue
            bar = QProgressBar()
            bar.setFixedHeight(8)
            lbl = ui.label("", "muted")
            disks.add(ui.hrow(ui.label(part.mountpoint, "h2"), None, lbl))
            disks.add(bar)
            self.disk_rows.append((bar, lbl, part.mountpoint))
        battery = psutil.sensors_battery() if hasattr(psutil, "sensors_battery") else None
        if battery:
            disks.add(ui.label(f"Battery: {battery.percent:.0f}%" + (" (charging)" if battery.power_plugged else ""), "muted"))
        lay.addWidget(disks)

        apps = ui.Card("Busiest apps", "")
        self.sort = QComboBox()
        self.sort.addItems(["Sort by CPU", "Sort by memory"])
        self.sort.currentIndexChanged.connect(lambda _: self._update_processes())
        apps.header.addWidget(self.sort)
        self.procs = QTreeWidget()
        self.procs.setHeaderLabels(["App", "CPU", "Memory", "PID"])
        self.procs.setRootIsDecorated(False)
        self.procs.setColumnWidth(0, 280)
        self.procs.setMinimumHeight(320)
        apps.add(self.procs)
        apps.add(ui.hrow(None, ui.button("Force close selected", "danger", "", self._kill_selected)))
        lay.addWidget(apps)

        ov = ui.Card("Overlay", "")
        ov.add(ui.label("A small see-through stats box that stays on top, even over borderless-window games. "
                        "Clicks go straight through it.", "muted", wrap=True))
        toggle = ui.ToggleSwitch(self.setting("overlay", False))
        toggle.toggled.connect(lambda on: (self._show_overlay(on), self.set_setting("overlay", on)))
        corner = QComboBox()
        corners = ["top-right", "top-left", "bottom-right", "bottom-left"]
        corner.addItems([c.replace("-", " ").capitalize() for c in corners])
        corner.setCurrentIndex(corners.index(self.setting("corner", "top-right")))
        corner.currentIndexChanged.connect(
            lambda i: (self.set_setting("corner", corners[i]), self.overlay and self.overlay.place()))
        ov.add(ui.hrow(ui.label("Show overlay"), toggle, None, ui.label("Corner", "muted"), corner))
        lay.addWidget(ov)
        self._update_disks()
        return page
