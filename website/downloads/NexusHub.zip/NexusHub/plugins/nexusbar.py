"""Nexus Bar: a Spotlight-style command bar for everything in NexusHub (and your PC)."""
import ast
import operator
import os
import re
import time
import urllib.parse

from PySide6.QtCore import QEasingCurve, QEvent, QFileInfo, QPoint, QPropertyAnimation, QRectF, QSize, Qt, QTimer
from PySide6.QtGui import (QColor, QCursor, QFont, QGuiApplication, QIcon, QLinearGradient, QPainter, QPainterPath,
                           QPen)
from PySide6.QtWidgets import (QComboBox, QFileIconProvider, QHBoxLayout, QLabel, QLineEdit, QListWidget,
                               QListWidgetItem, QVBoxLayout, QWidget)

from core import icons, ui, win
from core.plugin import Plugin

START_MENUS = [os.path.join(os.environ.get("PROGRAMDATA", r"C:\ProgramData"), r"Microsoft\Windows\Start Menu\Programs"),
               os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs")]
SKIP_APP_WORDS = ("uninstall", "readme", "help", "documentation", "release notes", "website", "license")
ENGINES = {"Google": "https://www.google.com/search?q=", "DuckDuckGo": "https://duckduckgo.com/?q=",
           "Bing": "https://www.bing.com/search?q=", "YouTube": "https://www.youtube.com/results?search_query="}
WIN_SETTINGS = [
    ("Wi-Fi settings", "ms-settings:network-wifi"), ("Bluetooth settings", "ms-settings:bluetooth"),
    ("Display settings", "ms-settings:display"), ("Sound settings", "ms-settings:sound"),
    ("Apps & features", "ms-settings:appsfeatures"), ("Windows Update", "ms-settings:windowsupdate"),
    ("Default apps", "ms-settings:defaultapps"), ("Mouse settings", "ms-settings:mousetouchpad"),
    ("Personalization / background", "ms-settings:personalization-background"),
    ("Storage settings", "ms-settings:storagesense"), ("Power & battery", "ms-settings:powersleep"),
    ("Task Manager", "taskmgr.exe"), ("Control Panel", "control.exe"), ("Device Manager", "devmgmt.msc"),
]
OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
       ast.Pow: operator.pow, ast.Mod: operator.mod, ast.FloorDiv: operator.floordiv, ast.USub: operator.neg,
       ast.UAdd: operator.pos}


def calc(text):
    """Safe arithmetic: '2+2*3', '15% of 80', '2^10'. Returns a number or None."""
    t = text.strip().lower().replace("^", "**").replace("×", "*").replace("÷", "/").replace(",", "")
    m = re.fullmatch(r"([\d.]+)\s*%\s*of\s*([\d.]+)", t)
    if m:
        return float(m.group(1)) / 100 * float(m.group(2))
    if not re.fullmatch(r"[\d\s.+\-*/()%]+", t) or not re.search(r"\d\s*[+\-*/%]", t):
        return None

    def ev(n):
        if isinstance(n, ast.Expression):
            return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
            return n.value
        if isinstance(n, ast.BinOp) and type(n.op) in OPS:
            left, right = ev(n.left), ev(n.right)
            if isinstance(n.op, ast.Pow) and abs(right) > 100:
                raise ValueError
            return OPS[type(n.op)](left, right)
        if isinstance(n, ast.UnaryOp) and type(n.op) in OPS:
            return OPS[type(n.op)](ev(n.operand))
        raise ValueError
    try:
        return ev(ast.parse(t, mode="eval"))
    except (ValueError, SyntaxError, ZeroDivisionError, OverflowError, TypeError):
        return None


def score(query, text):
    """Fuzzy match: 0 = no match, higher = better (prefix > word start > anywhere > subsequence)."""
    q, t = query.lower(), text.lower()
    if not q:
        return 1
    if t.startswith(q):
        return 100 - len(t) * 0.1
    if f" {q}" in f" {t}":
        return 80 - len(t) * 0.1
    if q in t:
        return 60 - len(t) * 0.1
    it = iter(t)
    if all(ch in it for ch in q):   # subsequence, e.g. "sptf" -> "spotify"
        return 30 - len(t) * 0.1
    words = q.split()
    if len(words) > 1 and all(w in t for w in words):
        return 50
    return 0


class Item:
    __slots__ = ("title", "sub", "glyph", "run", "key", "hint", "icon")

    def __init__(self, title, sub, glyph, run, key, hint="", icon=None):
        self.title, self.sub, self.glyph, self.run, self.key, self.hint, self.icon = title, sub, glyph, run, key, hint, icon


class ResultRow(QWidget):
    def __init__(self, item):
        super().__init__()
        lay = QHBoxLayout(self)
        lay.setContentsMargins(10, 6, 12, 6)
        lay.setSpacing(12)
        if item.icon is not None:
            ic = QLabel()
            ic.setPixmap(item.icon.pixmap(QSize(26, 26)))
            ic.setFixedSize(34, 34)
            ic.setAlignment(Qt.AlignCenter)
        else:
            ic = ui.glyph_label(item.glyph, 16, "white")
            ic.setFixedSize(34, 34)
        ic.setStyleSheet(ic.styleSheet() + f"background: {ui.rgba(ui.ACCENT, 0.22)}; border-radius: 9px;")
        lay.addWidget(ic)
        col = QVBoxLayout()
        col.setSpacing(0)
        t = QLabel(item.title)
        t.setStyleSheet("font-size: 14px; font-weight: 600; background: transparent;")
        s = QLabel(item.sub)
        s.setStyleSheet(f"font-size: 11px; color: {ui.MUTED}; background: transparent;")
        col.addWidget(t)
        col.addWidget(s)
        lay.addLayout(col, 1)
        if item.hint:
            h = QLabel(item.hint)
            h.setStyleSheet(f"font-size: 11px; color: {ui.MUTED}; background: {ui.SURFACE2}; border-radius: 6px; padding: 3px 7px;")
            lay.addWidget(h)
        for w in self.findChildren(QLabel):
            w.setAttribute(Qt.WA_TransparentForMouseEvents)


class Bar(QWidget):
    WIDTH = 680

    def __init__(self, plugin):
        super().__init__(None, Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint)
        self.plugin = plugin
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedWidth(self.WIDTH)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 20, 22, 18)
        lay.setSpacing(10)
        row = QHBoxLayout()
        row.setSpacing(12)
        row.addWidget(ui.glyph_label("\uE721", 20, ui.ACCENT2))
        self.input = QLineEdit(placeholderText="Search apps, actions, favourites, settings… or type maths")
        self.input.setStyleSheet("QLineEdit { background: transparent; border: none; font-size: 19px; padding: 4px 0; }")
        self.input.textChanged.connect(self.refresh)
        self.input.installEventFilter(self)
        row.addWidget(self.input, 1)
        self.count = ui.label("", "muted")
        row.addWidget(self.count)
        lay.addLayout(row)
        self.list = QListWidget()
        self.list.setStyleSheet(
            "QListWidget { background: transparent; border: none; padding: 0; }"
            f"QListWidget::item {{ border-radius: 10px; padding: 0; margin: 1px 0; }}"
            f"QListWidget::item:selected {{ background: {ui.rgba(ui.ACCENT, 0.28)}; }}"
            f"QListWidget::item:hover {{ background: rgba(255,255,255,0.05); }}")
        self.list.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.list.itemActivated.connect(self._run)
        self.list.itemClicked.connect(self._run)
        lay.addWidget(self.list)
        foot = ui.label("↑↓ to move   ·   Enter to run   ·   Esc to close", "muted")
        foot.setStyleSheet(f"color:{ui.MUTED}; font-size: 11px;")
        lay.addWidget(foot)
        self.items = []
        self._anim = QPropertyAnimation(self, b"windowOpacity", self)
        self._anim.setDuration(140)
        self._slide = QPropertyAnimation(self, b"pos", self)
        self._slide.setDuration(180)
        self._slide.setEasingCurve(QEasingCurve.OutCubic)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(6, 6, -6, -6)
        # soft glow
        for i in range(6, 0, -1):
            c = QColor(ui.ACCENT)
            c.setAlpha(8 * (7 - i))
            p.setPen(QPen(c, i * 2))
            p.setBrush(Qt.NoBrush)
            p.drawRoundedRect(r, 20, 20)
        p.setBrush(QColor(16, 18, 26, 246))
        g = QLinearGradient(r.topLeft(), r.topRight())
        g.setColorAt(0, QColor(ui.ACCENT))
        g.setColorAt(1, QColor(ui.ACCENT2))
        p.setPen(QPen(g, 1.4))
        p.drawRoundedRect(r, 20, 20)

    def popup(self):
        self.plugin.rebuild_index()
        self.input.clear()
        self.refresh()
        screen = QGuiApplication.screenAt(QCursor.pos()) or QGuiApplication.primaryScreen()
        geo = screen.availableGeometry()
        target = QPoint(geo.center().x() - self.WIDTH // 2, geo.top() + int(geo.height() * 0.18))
        self.move(target + QPoint(0, -14))
        self.setWindowOpacity(0)
        self.show()
        self.raise_()
        self.activateWindow()
        win.focus(int(self.winId()))
        self.input.setFocus()
        self._anim.setStartValue(0.0)
        self._anim.setEndValue(1.0)
        self._anim.start()
        self._slide.setStartValue(self.pos())
        self._slide.setEndValue(target)
        self._slide.start()

    def refresh(self):
        q = self.input.text().strip()
        self.items = self.plugin.search(q)
        self.list.clear()
        for it in self.items:
            li = QListWidgetItem()
            li.setSizeHint(QSize(0, 50))
            self.list.addItem(li)
            self.list.setItemWidget(li, ResultRow(it))
        if self.items:
            self.list.setCurrentRow(0)
        rows = min(len(self.items), 8)
        self.list.setFixedHeight(max(1, rows * 52))
        self.list.setVisible(bool(self.items))
        self.count.setText(f"{len(self.items)} results" if q else "")
        self.adjustSize()

    def eventFilter(self, obj, e):
        if e.type() == QEvent.KeyPress:
            k = e.key()
            if k == Qt.Key_Escape:
                self.hide()
                return True
            if k in (Qt.Key_Down, Qt.Key_Up, Qt.Key_Tab):
                row = self.list.currentRow() + (-1 if k == Qt.Key_Up else 1)
                self.list.setCurrentRow(row % max(1, self.list.count()))
                return True
            if k in (Qt.Key_Return, Qt.Key_Enter):
                if self.list.currentItem():
                    self._run(self.list.currentItem())
                return True
        return super().eventFilter(obj, e)

    def changeEvent(self, e):
        if e.type() == QEvent.ActivationChange and not self.isActiveWindow() and self.isVisible():
            self.hide()
        super().changeEvent(e)

    def _run(self, li):
        idx = self.list.row(li)
        if 0 <= idx < len(self.items):
            item = self.items[idx]
            self.hide()
            self.plugin.bump(item.key)
            QTimer.singleShot(60, item.run)   # let focus return to the previous window first


class NexusBar(Plugin):
    id = "nexusbar"
    name = "Nexus Bar"
    icon = "\uE721"
    category = "Productivity"
    order = 1
    description = "One hotkey to do anything: open apps, run any NexusHub action, play favourites, change settings, do maths, search the web."
    hotkeys = {"open": ("Open the Nexus Bar", "alt+space")}

    def __init__(self, hub):
        super().__init__(hub)
        self.bar = None
        self.apps = []
        self._apps_at = 0
        self._icons = QFileIconProvider()
        self._icon_cache = {}

    def status(self):
        return f"Press {ui.hotkeys.pretty(self.hub.combo_for(self, 'open'))}"

    def on_hotkey(self, action):
        if action == "open":
            if self.bar and self.bar.isVisible():
                self.bar.hide()
                return
            if not self.bar:
                self.bar = Bar(self)
            self.bar.popup()

    def on_disable(self):
        if self.bar:
            self.bar.hide()

    # ------------------------------------------------------------ index
    def rebuild_index(self):
        if time.time() - self._apps_at > 600 or not self.apps:
            self._apps_at = time.time()
            seen, apps = set(), []
            for base in START_MENUS:
                for root, _, files in os.walk(base):
                    for f in files:
                        name, ext = os.path.splitext(f)
                        if ext.lower() not in (".lnk", ".url") or name.lower() in seen:
                            continue
                        if any(w in name.lower() for w in SKIP_APP_WORDS):
                            continue
                        seen.add(name.lower())
                        apps.append((name, os.path.join(root, f)))
            # Store apps and anything else in Start → All apps that has no shortcut file
            for name, target in icons.installed_apps(refresh=True):
                if name.lower() not in seen and not any(w in name.lower() for w in SKIP_APP_WORDS):
                    seen.add(name.lower())
                    apps.append((name, target))
            self.apps = apps

    def _icon(self, path):
        if path not in self._icon_cache:
            pm = icons.best_icon(path, 64, retries=1)   # never block typing waiting for an icon
            self._icon_cache[path] = QIcon(pm) if pm is not None else self._icons.icon(QFileInfo(path))
        return self._icon_cache[path]

    def bump(self, key):
        use = self.settings.setdefault("usage", {})
        use[key] = use.get(key, 0) + 1
        if len(use) > 400:   # keep the file small
            for k in sorted(use, key=use.get)[:100]:
                use.pop(k)
        self.hub.config.save()

    def _candidates(self):
        hub = self.hub
        for p in hub.plugins:
            yield Item(f"Open {p.name}", "NexusHub module", p.icon,
                       lambda p=p: (hub.show_window(), hub.window.open_page(p.id)), f"page:{p.id}", "Module")
            if p.id != self.id:
                yield Item(f"Turn {p.name} {'off' if p.enabled else 'on'}", "Module switch", "\uE7E8",
                           lambda p=p: (hub.set_enabled(p, not p.enabled),
                                        self.notify(f"{p.name} {'on' if p.enabled else 'off'}", p.icon)),
                           f"toggle:{p.id}")
            if not p.enabled:
                continue
            for action, (label, _) in list(p.hotkeys.items()):
                if p.id == self.id:
                    continue
                combo = hub.combo_for(p, action)
                yield Item(label, p.name, p.icon, lambda p=p, a=action: p.on_hotkey(a), f"act:{p.id}.{action}",
                           ui.hotkeys.pretty(combo) if combo else "")
            try:
                extra = p.tray_actions()
            except Exception:
                extra = []
            labels = {l for l, _ in p.hotkeys.values()}
            for label, cb in extra:
                if label not in labels:
                    yield Item(label, p.name, p.icon, cb, f"tray:{p.id}.{label}")
        for title, target in WIN_SETTINGS:
            yield Item(title, "Windows", "\uE713", lambda t=target: os.startfile(t), f"win:{target}")
        yield Item("NexusHub settings", "NexusHub", "\uE713",
                   lambda: (hub.show_window(), hub.window.open_page("settings")), "page:settings")
        if self.setting("apps", True):
            for name, path in self.apps:
                yield Item(name, "App", "\uE7AC", lambda path=path: os.startfile(path), f"app:{name}", icon=None)

    def search(self, q):
        results = []
        value = calc(q) if q else None
        if value is not None:
            text = f"{value:,.10g}".replace(",", " ") if isinstance(value, float) else f"{value:,}".replace(",", " ")
            plain = f"{value:.10g}" if isinstance(value, float) else str(value)
            results.append((10_000, Item(f"= {text}", "Calculator · Enter copies the result", "\uE8EF",
                                         lambda: (QGuiApplication.clipboard().setText(plain),
                                                  self.notify(f"{plain} copied", "\uE8EF")), "calc")))
        use = self.setting("usage", {})
        for it in self._candidates():
            s = score(q, it.title) if q else (use.get(it.key, 0) * 10 if use.get(it.key) else 0)
            if not s and q:
                s = score(q, it.sub) * 0.4
            if s:
                results.append((s + min(use.get(it.key, 0), 20) * 2, it))
        results.sort(key=lambda r: -r[0])
        items = [it for _, it in results[:40]]
        for it in items[:12]:
            if it.key.startswith("app:"):
                it.icon = self._icon(next(p for n, p in self.apps if f"app:{n}" == it.key))
        if q:
            if re.fullmatch(r"(https?://)?[\w-]+(\.[\w-]+)+(/\S*)?", q):
                url = q if q.startswith("http") else "https://" + q
                items.append(Item(f"Open {q}", "Website", "\uE774", lambda: self.hub.open_url(url), "web:url"))
            engine = self.setting("engine", "Google")
            items.append(Item(f"Search {engine} for “{q}”", "Web", "\uE721",
                              lambda: self.hub.open_url(ENGINES[engine] + urllib.parse.quote(q)), "web:search"))
        elif not items:
            items = [it for it in self._candidates() if it.key.startswith("page:")][:8]
        return items

    # ------------------------------------------------------------ page
    def create_page(self):
        page = QWidget()
        self._page = page
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)
        hero = ui.Card()
        big = ui.label(f"Press  {ui.hotkeys.pretty(self.hub.combo_for(self, 'open'))}", "big")
        hero.add(big)
        hero.add(ui.label("A command bar for your whole PC. Start typing and press Enter. Try:", "muted"))
        for ex, what in (("spot", "Spotify controls, and your favourite albums by name"),
                         ("air horn", "play a soundboard pad"), ("dark", "switch dark/light mode"),
                         ("discord", "open any installed app"), ("15% of 80", "quick maths (copies the answer)"),
                         ("wifi", "jump to Windows settings"), ("how to cook rice", "search the web")):
            hero.add(ui.hrow(ui.label(ex, "pill"), ui.label(what, "muted"), None))
        hero.add(ui.hrow(None, ui.button("Try it now", "primary", "\uE721", lambda: self.on_hotkey("open"))))
        lay.addWidget(hero)
        opts = ui.Card("Options", "\uE713")
        eng = QComboBox()
        eng.addItems(list(ENGINES))
        eng.setCurrentText(self.setting("engine", "Google"))
        eng.currentTextChanged.connect(lambda t: self.set_setting("engine", t))
        opts.add(ui.hrow(ui.label("Web search with"), None, eng))
        apps = ui.ToggleSwitch(self.setting("apps", True))
        apps.toggled.connect(lambda on: self.set_setting("apps", on))
        opts.add(ui.hrow(ui.label("Include installed apps from the Start menu"), None, apps))
        opts.add(ui.hrow(ui.label("Things you use most float to the top automatically."), None,
                         ui.button("Forget usage", "ghost", "\uE74D", lambda: self.set_setting("usage", {}))))
        lay.addWidget(opts)
        return page
