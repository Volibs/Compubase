"""
TEMPLATE FOR YOUR OWN MODULE
============================
1. Copy this file and rename the copy, e.g. `plugins/my_tool.py`
   (files starting with "_" are ignored, so the copy must not).
2. Change `id`, `name`, `description`, and write your code.
3. Restart NexusHub (tray icon → Quit, then open it again). Your module appears in the sidebar.

Handy things you can use:
    self.notify("text")                 pop-up on screen
    self.setting("key", default)        read a saved setting
    self.set_setting("key", value)      save a setting (kept after restart)
    self.hub.osd.show_message(text, glyph, value=0.5)   pop-up with a bar
    core.win   → window tricks (foreground(), set_topmost(), set_opacity(), press_key()…)
    core.audio → volume (speakers(), microphone(), app_volume("spotify.exe"))
    core.ui    → Card, button, label, ToggleSwitch, LineGraph, hrow… (same look as the rest of the app)

Icons are Segoe Fluent Icons glyphs, e.g. "" play. Browse them at
https://learn.microsoft.com/windows/apps/design/style/segoe-fluent-icons-font
"""
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QVBoxLayout, QWidget

from core import ui
from core.plugin import Plugin


class MyModule(Plugin):
    id = "my_module"                       # unique, lowercase
    name = "My Module"
    icon = ""                        # star
    category = "Tools"
    description = "What this module does, in one sentence."
    default_enabled = True
    order = 200                            # position in the sidebar
    hotkeys = {
        # "action": ("What it does", "default combo")  users can change these in Settings
        "hello": ("Say hello", "ctrl+alt+h"),
    }

    def __init__(self, hub):
        super().__init__(hub)
        self.count = self.setting("count", 0)
        self.timer = QTimer(self, interval=60_000, timeout=self.every_minute)

    # runs when the module is switched on (and at startup if it was on)
    def on_enable(self):
        self.timer.start()

    # runs when switched off or when NexusHub quits: stop your timers/threads here
    def on_disable(self):
        self.timer.stop()

    def every_minute(self):
        pass  # background work goes here

    def on_hotkey(self, action):
        if action == "hello":
            self.count += 1
            self.set_setting("count", self.count)
            self.notify(f"Hello! You pressed me {self.count} times")
            self._update()

    def status(self):
        return f"Pressed {self.count} times"   # shown on the Home card

    def tray_actions(self):
        return [("Say hello", lambda: self.on_hotkey("hello"))]

    def create_page(self):
        page = QWidget()
        self._page = page   # so refresh helpers work while building
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        card = ui.Card("Hello", "")
        self.lbl = ui.label("", "big")
        card.add(self.lbl)
        card.add(ui.hrow(ui.button("Say hello", "primary", on_click=lambda: self.on_hotkey("hello")), None))
        lay.addWidget(card)
        self._update()
        return page

    def _update(self):
        if self._page is not None or hasattr(self, "lbl"):
            self.lbl.setText(str(self.count))
