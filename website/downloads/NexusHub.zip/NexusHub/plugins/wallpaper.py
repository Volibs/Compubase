"""Live wallpapers behind your desktop icons: animated scenes, videos and GIFs."""
import ctypes
import math
import os
import random
import time
from ctypes import wintypes

from PySide6.QtCore import QPointF, QRectF, QSize, Qt, QTimer, QUrl
from PySide6.QtGui import (QColor, QFont, QGuiApplication, QImage, QLinearGradient, QMovie, QPainter,
                           QPainterPath, QPen, QPixmap, QRadialGradient)
from PySide6.QtWidgets import (QComboBox, QFileDialog, QGridLayout, QHBoxLayout, QLabel, QListWidget,
                               QListWidgetItem, QPushButton, QSlider, QVBoxLayout, QWidget)

from core import audio, ui, win
from core.plugin import Plugin

try:
    from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer, QVideoSink
    HAS_VIDEO = True
except ImportError:
    HAS_VIDEO = False

u = win.user32
u.GetWindow.restype = wintypes.HWND
u.GetWindow.argtypes = [wintypes.HWND, wintypes.UINT]
u.GetCursorPos.argtypes = [ctypes.POINTER(wintypes.POINT)]
u.SystemParametersInfoW.argtypes = [wintypes.UINT, wintypes.UINT, ctypes.c_void_p, wintypes.UINT]
MONITORENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HMONITOR, wintypes.HDC,
                                     ctypes.POINTER(wintypes.RECT), wintypes.LPARAM)

VIDEO_EXT = (".mp4", ".webm", ".mkv", ".mov", ".avi", ".wmv", ".m4v")
IMAGE_EXT = (".png", ".jpg", ".jpeg", ".bmp", ".webp")


# ====================================================================== desktop plumbing
def monitors():
    """Physical rects (l, t, r, b, primary) of every display."""
    out = []

    def cb(hmon, _hdc, _rect, _):
        mi = win.MONITORINFO()
        mi.cbSize = ctypes.sizeof(mi)
        u.GetMonitorInfoW(hmon, ctypes.byref(mi))
        r = mi.rcMonitor
        out.append((r.left, r.top, r.right, r.bottom, bool(mi.dwFlags & 1)))
        return True

    u.EnumDisplayMonitors(None, None, MONITORENUMPROC(cb), 0)
    return out


def desktop_host():
    """Ask Explorer to split the desktop into layers, then return where to put our window.

    Returns (parent_hwnd, insert_below_hwnd). Windows 11 24H2+ keeps the layers
    inside Progman; older builds use a separate top-level WorkerW.
    """
    progman = u.FindWindowW("Progman", None)
    res = ctypes.c_size_t()
    u.SendMessageTimeoutW(progman, 0x052C, 0xD, 0x1, 0, 1000, ctypes.byref(res))
    u.SendMessageTimeoutW(progman, 0x052C, 0, 0, 0, 1000, ctypes.byref(res))
    defview = u.FindWindowExW(progman, None, "SHELLDLL_DefView", None)
    if defview and u.FindWindowExW(progman, None, "WorkerW", None):
        return progman, defview
    found = [None]

    def cb(hwnd, _):
        if u.FindWindowExW(hwnd, None, "SHELLDLL_DefView", None):
            found[0] = u.FindWindowExW(None, hwnd, "WorkerW", None)
        return True

    u.EnumWindows(win.WNDENUMPROC(cb), 0)
    return found[0], None


def attach(hwnd, mon_rect):
    parent, below = desktop_host()
    if not parent:
        return None
    style = u.GetWindowLongPtrW(hwnd, win.GWL_STYLE)
    u.SetWindowLongPtrW(hwnd, win.GWL_STYLE, (style & ~win.WS_POPUP) | win.WS_CHILD)
    u.SetParent(hwnd, parent)
    pl, pt, _, _ = win.rect(parent)
    l, t, r, b = mon_rect
    flags = win.SWP_NOACTIVATE | win.SWP_SHOWWINDOW | win.SWP_FRAMECHANGED
    u.SetWindowPos(hwnd, below, l - pl, t - pt, r - l, b - t, flags | (0 if below else win.SWP_NOZORDER))
    ex = u.GetWindowLongPtrW(hwnd, win.GWL_EXSTYLE)
    u.SetWindowLongPtrW(hwnd, win.GWL_EXSTYLE, ex | win.WS_EX_LAYERED)
    u.SetLayeredWindowAttributes(hwnd, 0, 255, win.LWA_ALPHA)
    return parent


def refresh_static_wallpaper():
    buf = ctypes.create_unicode_buffer(520)
    if u.SystemParametersInfoW(0x73, 520, buf, 0):  # SPI_GETDESKWALLPAPER
        u.SystemParametersInfoW(0x14, 0, buf, 0x2)  # SPI_SETDESKWALLPAPER, SPIF_SENDCHANGE


def cursor_physical():
    pt = wintypes.POINT()
    u.GetCursorPos(ctypes.byref(pt))
    return pt.x, pt.y


# ====================================================================== scenes
class Scene:
    title = ""
    blurb = ""

    def __init__(self):
        self.t = 0.0
        self.w = self.h = 0

    def resize(self, w, h):
        self.w, self.h = w, h

    def step(self, dt, mouse=None):
        self.t += dt

    def paint(self, p):
        raise NotImplementedError


class Aurora(Scene):
    title = "Aurora"
    blurb = "Slow northern lights over a starfield"

    def resize(self, w, h):
        super().resize(w, h)
        rnd = random.Random(7)
        self.bg = QPixmap(w, h)
        p = QPainter(self.bg)
        g = QLinearGradient(0, 0, 0, h)
        g.setColorAt(0, QColor("#030612"))
        g.setColorAt(1, QColor("#0a1024"))
        p.fillRect(0, 0, w, h, g)
        p.setPen(Qt.NoPen)
        for _ in range(int(w * h / 5000)):
            a = rnd.randint(40, 200)
            p.setBrush(QColor(255, 255, 255, a))
            s = rnd.choice((1, 1, 1, 1.6))
            p.drawEllipse(QPointF(rnd.random() * w, rnd.random() * h * 0.8), s, s)
        p.end()
        self.ribbons = [
            (QColor(52, 211, 153), 0.36, 0.0022, 0.35, 70, 1.0),
            (QColor(34, 211, 238), 0.44, 0.0016, -0.22, 90, 0.8),
            (QColor(124, 108, 255), 0.30, 0.0030, 0.18, 55, 0.7),
        ]

    def paint(self, p):
        p.drawPixmap(0, 0, self.bg)
        p.setCompositionMode(QPainter.CompositionMode_Plus)
        w, h, t = self.w, self.h, self.t
        for color, base, freq, speed, amp, strength in self.ribbons:
            top = QPainterPath()
            pts = []
            for i in range(0, w + 40, 30):
                y = (h * base + math.sin(i * freq + t * speed) * amp
                     + math.sin(i * freq * 2.3 - t * speed * 1.7) * amp * 0.45)
                pts.append(QPointF(i, y))
            top.moveTo(pts[0])
            for pt in pts[1:]:
                top.lineTo(pt)
            height = h * 0.28
            for pt in reversed(pts):
                top.lineTo(pt.x(), pt.y() + height)
            top.closeSubpath()
            g = QLinearGradient(0, h * base - amp, 0, h * base + height)
            c1, c2, c3 = QColor(color), QColor(color), QColor(color)
            pulse = 0.75 + 0.25 * math.sin(t * 0.4 + base * 10)
            c1.setAlpha(0)
            c2.setAlpha(int(150 * strength * pulse))
            c3.setAlpha(0)
            g.setColorAt(0, c1)
            g.setColorAt(0.2, c2)
            g.setColorAt(1, c3)
            p.fillPath(top, g)
        p.setCompositionMode(QPainter.CompositionMode_SourceOver)


class Constellation(Scene):
    title = "Constellation"
    blurb = "Drifting stars that link up and follow your mouse"

    def resize(self, w, h):
        super().resize(w, h)
        n = max(40, min(140, int(w * h / 16000)))
        self.pts = [[random.random() * w, random.random() * h,
                     (random.random() - 0.5) * 30, (random.random() - 0.5) * 30] for _ in range(n)]
        self.bg = QLinearGradient(0, 0, w, h)
        self.bg.setColorAt(0, QColor("#0b0d1a"))
        self.bg.setColorAt(1, QColor("#120c24"))
        self.mouse = None

    def step(self, dt, mouse=None):
        super().step(dt)
        self.mouse = mouse
        for pt in self.pts:
            if mouse:
                dx, dy = mouse[0] - pt[0], mouse[1] - pt[1]
                d2 = dx * dx + dy * dy
                if 100 < d2 < 200 * 200:
                    pt[2] += dx / math.sqrt(d2) * 40 * dt
                    pt[3] += dy / math.sqrt(d2) * 40 * dt
            speed = math.hypot(pt[2], pt[3])
            if speed > 45:
                pt[2] *= 45 / speed
                pt[3] *= 45 / speed
            pt[0] += pt[2] * dt
            pt[1] += pt[3] * dt
            if not 0 <= pt[0] <= self.w:
                pt[2] *= -1
                pt[0] = max(0, min(self.w, pt[0]))
            if not 0 <= pt[1] <= self.h:
                pt[3] *= -1
                pt[1] = max(0, min(self.h, pt[1]))

    def paint(self, p):
        p.fillRect(0, 0, self.w, self.h, self.bg)
        link = 150
        link2 = link * link
        pts = self.pts
        pen = QPen()
        pen.setWidthF(1.0)
        for i, a in enumerate(pts):
            ax, ay = a[0], a[1]
            for b in pts[i + 1:]:
                dx, dy = ax - b[0], ay - b[1]
                d2 = dx * dx + dy * dy
                if d2 < link2:
                    pen.setColor(QColor(140, 150, 255, int(110 * (1 - d2 / link2))))
                    p.setPen(pen)
                    p.drawLine(QPointF(ax, ay), QPointF(b[0], b[1]))
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(200, 220, 255))
        for a in pts:
            p.drawEllipse(QPointF(a[0], a[1]), 1.8, 1.8)
        if self.mouse:
            g = QRadialGradient(QPointF(*self.mouse), 180)
            g.setColorAt(0, QColor(124, 108, 255, 40))
            g.setColorAt(1, QColor(124, 108, 255, 0))
            p.setBrush(g)
            p.drawEllipse(QPointF(*self.mouse), 180, 180)


class DigitalRain(Scene):
    title = "Digital Rain"
    blurb = "Falling code, straight from the Matrix"
    CHARS = "アイウエオカキクケコサシスセソタチツテトナニヌネノ0123456789ABCDEF"

    def resize(self, w, h):
        super().resize(w, h)
        self.cell = 18
        self.buf = QImage(w, h, QImage.Format_RGB32)
        self.buf.fill(QColor("#000400"))
        self.cols = [random.uniform(-h, 0) for _ in range(w // self.cell + 1)]
        self.speeds = [random.uniform(8, 20) for _ in self.cols]
        self.font = QFont("MS Gothic")
        self.font.setPixelSize(self.cell - 2)
        self.acc = 0.0

    def step(self, dt, mouse=None):
        super().step(dt)
        self.acc += dt
        if self.acc < 1 / 20:   # the rain looks best at a steady 20 fps
            return
        self.acc = 0
        p = QPainter(self.buf)
        p.fillRect(0, 0, self.w, self.h, QColor(0, 4, 0, 26))
        p.setFont(self.font)
        c = self.cell
        for i, y in enumerate(self.cols):
            if y >= 0:
                p.setPen(QColor(180, 255, 190))
                p.drawText(i * c, int(y), random.choice(self.CHARS))
                p.setPen(QColor(30, 200, 80))
                p.drawText(i * c, int(y - c), random.choice(self.CHARS))
            self.cols[i] = y + self.speeds[i] * 1.2
            if y > self.h and random.random() > 0.97:
                self.cols[i] = random.uniform(-200, 0)
        p.end()

    def paint(self, p):
        p.drawImage(0, 0, self.buf)


class Nebula(Scene):
    title = "Nebula"
    blurb = "Soft colour clouds that slowly blend. Easiest on the CPU"
    COLORS = ("#7c6cff", "#22d3ee", "#f472b6", "#34d399")

    def resize(self, w, h):
        super().resize(w, h)
        self.small = QImage(max(1, w // 6), max(1, h // 6), QImage.Format_RGB32)

    def paint(self, p):
        sw, sh = self.small.width(), self.small.height()
        sp = QPainter(self.small)
        sp.setRenderHint(QPainter.Antialiasing)
        sp.fillRect(0, 0, sw, sh, QColor("#07080f"))
        sp.setCompositionMode(QPainter.CompositionMode_Plus)
        sp.setPen(Qt.NoPen)
        t = self.t * 0.08
        for i, col in enumerate(self.COLORS):
            x = sw * (0.5 + 0.38 * math.sin(t * (1 + i * 0.3) + i * 1.7))
            y = sh * (0.5 + 0.36 * math.cos(t * (0.8 + i * 0.25) + i))
            r = max(sw, sh) * (0.45 + 0.1 * math.sin(t + i))
            g = QRadialGradient(QPointF(x, y), r)
            c = QColor(col)
            c.setAlpha(150)
            g.setColorAt(0, c)
            c.setAlpha(0)
            g.setColorAt(1, c)
            sp.setBrush(g)
            sp.drawEllipse(QPointF(x, y), r, r)
        sp.end()
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.drawImage(QRectF(0, 0, self.w, self.h), self.small)


class MusicPulse(Scene):
    title = "Music Pulse"
    blurb = "A glowing ring that dances to whatever you're playing"
    wants_audio = True
    BARS = 96

    def resize(self, w, h):
        super().resize(w, h)
        self.level = 0.55          # the live wallpaper overwrites this every frame; previews keep it
        self.smooth = 0.0
        self.avg = 0.05
        self.flash = 0.0
        self.bars = [0.0] * self.BARS
        self.seeds = [random.random() * 6.28 for _ in range(self.BARS)]
        rnd = random.Random(5)
        self.dust = [[rnd.random() * w, rnd.random() * h, rnd.uniform(0.2, 1.0)] for _ in range(140)]
        self.bg = QRadialGradient(QPointF(w / 2, h / 2), max(w, h) * 0.7)
        self.bg.setColorAt(0, QColor("#140f2a"))
        self.bg.setColorAt(1, QColor("#05060c"))

    def step(self, dt, mouse=None):
        super().step(dt)
        lv = min(1.0, self.level * 1.6)
        self.smooth += (lv - self.smooth) * min(1.0, dt * 12)
        self.avg += (lv - self.avg) * min(1.0, dt * 1.5)
        if lv > self.avg * 1.45 and lv > 0.12:      # a beat: level jumps above its recent average
            self.flash = 1.0
        self.flash = max(0.0, self.flash - dt * 3)
        for i in range(self.BARS):
            # a fake "spectrum": each bar wobbles on its own, scaled by how loud things are
            wob = 0.5 + 0.5 * math.sin(self.t * (2.2 + (i % 7) * 0.6) + self.seeds[i])
            bass = 1.4 if i % 24 < 6 else 1.0
            target = self.smooth * (0.35 + 0.65 * wob) * bass
            self.bars[i] += (target - self.bars[i]) * min(1.0, dt * 14)
        speed = 12 + 180 * self.smooth
        cx, cy = self.w / 2, self.h / 2
        for d in self.dust:                           # dust flies outwards faster when it's loud
            dx, dy = d[0] - cx, d[1] - cy
            dist = math.hypot(dx, dy) or 1
            d[0] += dx / dist * speed * d[2] * dt
            d[1] += dy / dist * speed * d[2] * dt
            if not (0 <= d[0] <= self.w and 0 <= d[1] <= self.h):
                a = random.random() * 6.28
                d[0], d[1] = cx + math.cos(a) * 40, cy + math.sin(a) * 40

    def paint(self, p):
        w, h = self.w, self.h
        p.fillRect(0, 0, w, h, self.bg)
        c = QPointF(w / 2, h / 2)
        base = min(w, h) * (0.16 + 0.02 * self.smooth)
        p.setPen(Qt.NoPen)
        for d in self.dust:
            p.setBrush(QColor(200, 210, 255, int(60 + 120 * d[2])))
            p.drawEllipse(QPointF(d[0], d[1]), 1.2 * d[2] + 0.4, 1.2 * d[2] + 0.4)
        # glow
        glow = QRadialGradient(c, base * (2.2 + self.flash))
        a = QColor(ui.ACCENT)
        a.setAlpha(int(70 + 120 * self.smooth + 60 * self.flash))
        glow.setColorAt(0, a)
        a.setAlpha(0)
        glow.setColorAt(1, a)
        p.setBrush(glow)
        p.drawEllipse(c, base * (2.2 + self.flash), base * (2.2 + self.flash))
        # bars around the ring
        p.setCompositionMode(QPainter.CompositionMode_Plus)
        c1, c2 = QColor(ui.ACCENT), QColor(ui.ACCENT2)
        for i, v in enumerate(self.bars):
            ang = 2 * math.pi * i / self.BARS - math.pi / 2
            length = 6 + v * base * 1.6
            t = i / self.BARS
            col = QColor(int(c1.red() + (c2.red() - c1.red()) * abs(math.sin(t * math.pi))),
                         int(c1.green() + (c2.green() - c1.green()) * abs(math.sin(t * math.pi))),
                         int(c1.blue() + (c2.blue() - c1.blue()) * abs(math.sin(t * math.pi))))
            p.setPen(QPen(col, max(2.0, base * 0.035), Qt.SolidLine, Qt.RoundCap))
            x0, y0 = c.x() + math.cos(ang) * base, c.y() + math.sin(ang) * base
            p.drawLine(QPointF(x0, y0), QPointF(x0 + math.cos(ang) * length, y0 + math.sin(ang) * length))
        p.setCompositionMode(QPainter.CompositionMode_SourceOver)
        # centre disc
        p.setPen(QPen(QColor(255, 255, 255, 60 + int(120 * self.flash)), 2))
        p.setBrush(QColor(8, 8, 16, 230))
        p.drawEllipse(c, base * 0.92, base * 0.92)
        f = QFont(ui.TEXT_FONT)
        f.setPixelSize(int(base * 0.32))
        f.setWeight(QFont.Light)
        p.setFont(f)
        p.setPen(QColor(255, 255, 255, 220))
        p.drawText(QRectF(c.x() - base, c.y() - base * 0.3, base * 2, base * 0.45), Qt.AlignCenter,
                   time.strftime("%H:%M"))
        f.setPixelSize(int(base * 0.1))
        p.setFont(f)
        p.setPen(QColor(255, 255, 255, 140))
        p.drawText(QRectF(c.x() - base, c.y() + base * 0.18, base * 2, base * 0.2), Qt.AlignCenter,
                   time.strftime("%A %d %B").upper())


SCENES = {cls.__name__.lower(): cls for cls in (Aurora, Constellation, Nebula, DigitalRain, MusicPulse)}


# ====================================================================== the wallpaper window
def fit_rect(src_w, src_h, w, h, mode):
    if mode == "stretch" or not src_w or not src_h:
        return QRectF(0, 0, w, h)
    scale = (max if mode == "cover" else min)(w / src_w, h / src_h)
    dw, dh = src_w * scale, src_h * scale
    return QRectF((w - dw) / 2, (h - dh) / 2, dw, dh)


class Surface(QWidget):
    def __init__(self, source, mon_rect, fps, fit, volume):
        super().__init__(None, Qt.FramelessWindowHint | Qt.Tool | Qt.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WA_OpaquePaintEvent)
        self.setAttribute(Qt.WA_NativeWindow)
        self.mon_rect = mon_rect
        self.fit = fit
        self.scene = None
        self.image = None
        self.movie = None
        self.player = None
        self.frame = None
        self.paused = False
        self._last = time.perf_counter()
        self.timer = QTimer(self, interval=max(8, int(1000 / fps)), timeout=self._tick)
        self.timer.setTimerType(Qt.PreciseTimer)

        kind, value = source
        if kind == "scene":
            self.scene = SCENES.get(value, Aurora)()
        elif value.lower().endswith(".gif"):
            self.movie = QMovie(value)
            self.movie.frameChanged.connect(self.update)
        elif value.lower().endswith(VIDEO_EXT) and HAS_VIDEO:
            self.player = QMediaPlayer(self)
            self.audio = QAudioOutput(self)
            self.audio.setVolume(volume)
            self.player.setAudioOutput(self.audio)
            self.sink = QVideoSink(self)
            self.sink.videoFrameChanged.connect(self._on_frame)
            self.player.setVideoSink(self.sink)
            self.player.setLoops(QMediaPlayer.Infinite)
            self.player.setSource(QUrl.fromLocalFile(value))
        else:
            self.image = QPixmap(value)

    def start(self):
        self.setWindowOpacity(0.0)   # avoid a flash before we move behind the icons
        self.show()
        self.parent_hwnd = attach(int(self.winId()), self.mon_rect)
        if self.scene:
            self.scene.resize(self.width(), self.height())
            self.timer.start()
        if self.movie:
            self.movie.start()
        if self.player:
            self.player.play()
        return self.parent_hwnd is not None

    def _audio_level(self):
        """Current output loudness (0..1). The meter is re-created if the output device changes."""
        try:
            if getattr(self, "_meter", None) is None:
                self._meter = audio.peak_meter()
            return self._meter.GetPeakValue()
        except Exception:
            self._meter = None
            return 0.0

    def stop(self):
        self._meter = None
        self.timer.stop()
        if self.movie:
            self.movie.stop()
        if self.player:
            self.player.stop()
        u.SetParent(int(self.winId()), None)
        self.close()
        self.deleteLater()

    def set_paused(self, paused):
        if paused == self.paused:
            return
        self.paused = paused
        if self.scene:
            self.timer.stop() if paused else self.timer.start()
            self._last = time.perf_counter()
        if self.movie:
            self.movie.setPaused(paused)
        if self.player:
            self.player.pause() if paused else self.player.play()

    def set_volume(self, v):
        if self.player:
            self.audio.setVolume(v)

    def resizeEvent(self, e):
        if self.scene and self.width() > 0:
            self.scene.resize(self.width(), self.height())

    def _on_frame(self, frame):
        if frame.isValid():
            self.frame = frame.toImage()
            self.update()

    def _tick(self):
        now = time.perf_counter()
        dt = min(0.1, now - self._last)
        self._last = now
        mouse = None
        mx, my = cursor_physical()
        l, t, r, b = self.mon_rect
        if l <= mx < r and t <= my < b:
            dpr = self.devicePixelRatioF()
            mouse = ((mx - l) / dpr, (my - t) / dpr)
        if getattr(self.scene, "wants_audio", False):
            self.scene.level = self._audio_level()
        self.scene.step(dt, mouse)
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        if self.scene:
            self.scene.paint(p)
            return
        p.fillRect(self.rect(), Qt.black)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        if self.frame is not None:
            p.drawImage(fit_rect(self.frame.width(), self.frame.height(), w, h, self.fit), self.frame)
        elif self.movie:
            pm = self.movie.currentPixmap()
            p.drawPixmap(fit_rect(pm.width(), pm.height(), w, h, self.fit).toRect(), pm)
        elif self.image and not self.image.isNull():
            p.drawPixmap(fit_rect(self.image.width(), self.image.height(), w, h, self.fit).toRect(), self.image)


# ====================================================================== plugin
class ScenePreview(QPushButton):
    def __init__(self, key, cls):
        super().__init__()
        self.key = key
        self.setCheckable(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(150)
        self.setMinimumWidth(200)
        scene = cls()
        scene.resize(320, 180)
        for _ in range(40):
            scene.step(0.1, (200, 90))
        pm = QPixmap(320, 180)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing)
        scene.paint(p)
        p.end()
        self.pm = pm
        self.title, self.blurb = cls.title, cls.blurb

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        path = QPainterPath()
        path.addRoundedRect(r, 12, 12)
        p.setClipPath(path)
        p.drawPixmap(fit_rect(320, 180, r.width(), r.height(), "cover").toRect(), self.pm)
        g = QLinearGradient(0, r.height() * 0.4, 0, r.height())
        g.setColorAt(0, QColor(0, 0, 0, 0))
        g.setColorAt(1, QColor(0, 0, 0, 200))
        p.fillRect(r, g)
        p.setClipping(False)
        p.setPen(QColor("white"))
        f = QFont(ui.TEXT_FONT)
        f.setPixelSize(14)
        f.setWeight(QFont.DemiBold)
        p.setFont(f)
        p.drawText(QRectF(14, r.height() - 46, r.width() - 20, 20), Qt.AlignLeft, self.title)
        f.setPixelSize(11)
        f.setWeight(QFont.Normal)
        p.setFont(f)
        p.setPen(QColor(220, 225, 235))
        p.drawText(QRectF(14, r.height() - 26, r.width() - 20, 20), Qt.AlignLeft,
                   p.fontMetrics().elidedText(self.blurb, Qt.ElideRight, int(r.width() - 24)))
        p.setBrush(Qt.NoBrush)
        p.setPen(QPen(QColor(ui.ACCENT2) if self.isChecked() else QColor(255, 255, 255, 30 if not self.underMouse() else 80),
                      2.5 if self.isChecked() else 1))
        p.drawRoundedRect(r, 12, 12)


class Wallpaper(Plugin):
    id = "wallpaper"
    name = "Live Wallpaper"
    icon = ""
    category = "Desktop"
    order = 20
    description = "Animated scenes, videos and GIFs behind your desktop icons. Pauses when a game or video is fullscreen."
    hotkeys = {"toggle": ("Turn live wallpaper on / off", "ctrl+alt+w")}

    def __init__(self, hub):
        super().__init__(hub)
        self.surfaces = []
        self.paused_reason = ""
        self._watch = QTimer(self, interval=1000, timeout=self._watchdog)
        self._restart_timer = QTimer(self, singleShot=True, interval=1500, timeout=self._restart_if_active)

    # ------------------------------------------------------------ lifecycle
    def on_enable(self):
        if self.setting("active", False):
            QTimer.singleShot(800, self.start)   # let Explorer settle when we launch at sign-in
        app = QGuiApplication.instance()
        app.screenAdded.connect(self._schedule_restart)
        app.screenRemoved.connect(self._schedule_restart)
        app.primaryScreenChanged.connect(self._schedule_restart)

    def on_disable(self):
        self.stop(remember=False)
        app = QGuiApplication.instance()
        for sig in (app.screenAdded, app.screenRemoved, app.primaryScreenChanged):
            try:
                sig.disconnect(self._schedule_restart)
            except (RuntimeError, TypeError):
                pass

    def status(self):
        if not self.surfaces:
            return "Off"
        return f"{self._source_name()}" + (f" · paused ({self.paused_reason})" if self.paused_reason else "")

    def tray_actions(self):
        return [("Stop live wallpaper" if self.surfaces else "Start live wallpaper", lambda: self.on_hotkey("toggle"))]

    def on_hotkey(self, action):
        if action == "toggle":
            if self.surfaces:
                self.stop()
                self.notify("Live wallpaper off")
            else:
                self.start()
                self.notify("Live wallpaper on")

    # ------------------------------------------------------------ control
    def source(self):
        return tuple(self.setting("source", ["scene", "aurora"]))

    def _source_name(self):
        kind, value = self.source()
        return SCENES[value].title if kind == "scene" and value in SCENES else os.path.basename(value)

    def start(self):
        self.stop(remember=False)
        kind, value = self.source()
        if kind == "file" and not os.path.exists(value):
            self.notify("Wallpaper file is missing", "")
            return
        mons = monitors()
        if self.setting("monitors", "all") == "primary":
            mons = [m for m in mons if m[4]] or mons[:1]
        fps = self.setting("fps", 30)
        for l, t, r, b, _ in mons:
            s = Surface((kind, value), (l, t, r, b), fps, self.setting("fit", "cover"), self.setting("volume", 0) / 100)
            if not s.start():
                s.stop()
                self.notify("Couldn't attach to the desktop", "")
                self.stop(remember=False)
                return
            self.surfaces.append(s)
        self.set_setting("active", True)
        self.paused_reason = ""
        self._watch.start()
        self._refresh_page()

    def stop(self, remember=True):
        self._watch.stop()
        had = bool(self.surfaces)
        for s in self.surfaces:
            s.stop()
        self.surfaces = []
        if had:
            refresh_static_wallpaper()
        if remember:
            self.set_setting("active", False)
        self._refresh_page()

    def apply(self, kind, value):
        self.set_setting("source", [kind, value])
        if kind == "file":
            lib = [x for x in self.setting("library", []) if x != value]
            self.set_setting("library", [value] + lib[:19])
        self.start()

    def _schedule_restart(self, *_):
        self._restart_timer.start()

    def _restart_if_active(self):
        if self.surfaces:
            self.start()

    def _watchdog(self):
        if not self.surfaces:
            return
        # Explorer restarted -> our parent window is gone, so re-attach
        if any(not u.IsWindow(s.parent_hwnd) for s in self.surfaces):
            self.start()
            return
        reason = ""
        if self.setting("pause_fullscreen", True) and win.foreground_is_fullscreen():
            reason = "fullscreen app"
        if reason != self.paused_reason:
            self.paused_reason = reason
            for s in self.surfaces:
                s.set_paused(bool(reason))

    # ------------------------------------------------------------ page
    def create_page(self):
        page = QWidget()
        self._page = page   # so refresh helpers work while building
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)

        top = ui.Card()
        self.lbl_status = ui.label("", "h2")
        self.lbl_sub = ui.label("", "muted")
        col = QVBoxLayout()
        col.setSpacing(2)
        col.addWidget(self.lbl_status)
        col.addWidget(self.lbl_sub)
        self.btn_toggle = ui.button("", "primary", "", lambda: self.on_hotkey("toggle"))
        row = QHBoxLayout()
        row.addLayout(col, 1)
        row.addWidget(ui.button("Add video / image / GIF", None, "", self._pick_file))
        row.addWidget(self.btn_toggle)
        top.add(row)
        lay.addWidget(top)

        scenes = ui.Card("Live scenes", "")
        grid = QGridLayout()
        grid.setSpacing(12)
        self.previews = []
        for i, (key, cls) in enumerate(SCENES.items()):
            b = ScenePreview(key, cls)
            b.clicked.connect(lambda _=False, k=key: self.apply("scene", k))
            grid.addWidget(b, i // 2, i % 2)
            self.previews.append(b)
        scenes.add(grid)
        lay.addWidget(scenes)

        libcard = ui.Card("Your library", "")
        libcard.add(ui.label("Videos (mp4, webm, mkv…), GIFs and images you've used. Double-click to apply. "
                             "Free sources: pexels.com/videos, motionbgs.com.", "muted", wrap=True))
        self.lib = QListWidget()
        self.lib.setMinimumHeight(140)
        self.lib.itemDoubleClicked.connect(lambda it: self.apply("file", it.data(Qt.UserRole)))
        libcard.add(self.lib)
        libcard.add(ui.hrow(None,
                            ui.button("Remove from list", "ghost", "", self._remove_selected),
                            ui.button("Apply", None, "", lambda: self.lib.currentItem() and
                                      self.apply("file", self.lib.currentItem().data(Qt.UserRole)))))
        lay.addWidget(libcard)

        opts = ui.Card("Options", "")
        fps = QComboBox()
        for v in (15, 24, 30, 60):
            fps.addItem(f"{v} fps", v)
        fps.setCurrentIndex([15, 24, 30, 60].index(self.setting("fps", 30)))
        fps.currentIndexChanged.connect(lambda _: self._set_and_restart("fps", fps.currentData()))
        opts.add(ui.hrow(ui.label("Animation smoothness (lower uses less CPU)"), None, fps))

        mons = QComboBox()
        mons.addItem("All monitors", "all")
        mons.addItem("Main monitor only", "primary")
        mons.setCurrentIndex(0 if self.setting("monitors", "all") == "all" else 1)
        mons.currentIndexChanged.connect(lambda _: self._set_and_restart("monitors", mons.currentData()))
        opts.add(ui.hrow(ui.label("Show on"), None, mons))

        fit = QComboBox()
        for text, v in (("Fill (crop edges)", "cover"), ("Fit (show everything)", "contain"), ("Stretch", "stretch")):
            fit.addItem(text, v)
        fit.setCurrentIndex(["cover", "contain", "stretch"].index(self.setting("fit", "cover")))
        fit.currentIndexChanged.connect(lambda _: self._set_and_restart("fit", fit.currentData()))
        opts.add(ui.hrow(ui.label("Videos and images"), None, fit))

        pause = ui.ToggleSwitch(self.setting("pause_fullscreen", True))
        pause.toggled.connect(lambda on: self.set_setting("pause_fullscreen", on))
        opts.add(ui.hrow(ui.label("Pause while a game or video is fullscreen"), None, pause))

        vol = QSlider(Qt.Horizontal)
        vol.setRange(0, 100)
        vol.setValue(self.setting("volume", 0))
        vol.setFixedWidth(220)
        vol.valueChanged.connect(lambda v: (self.set_setting("volume", v), [s.set_volume(v / 100) for s in self.surfaces]))
        opts.add(ui.hrow(ui.label("Video sound"), None, vol))
        lay.addWidget(opts)
        self._refresh_page()
        return page

    def _set_and_restart(self, key, value):
        self.set_setting(key, value)
        if self.surfaces:
            self.start()

    def _pick_file(self):
        exts = " ".join("*" + e for e in VIDEO_EXT + IMAGE_EXT + (".gif",))
        path, _ = QFileDialog.getOpenFileName(None, "Choose a wallpaper", os.path.expanduser("~/Videos"),
                                              f"Wallpapers ({exts})")
        if path:
            self.apply("file", os.path.normpath(path))

    def _remove_selected(self):
        it = self.lib.currentItem()
        if it:
            self.set_setting("library", [x for x in self.setting("library", []) if x != it.data(Qt.UserRole)])
            self._refresh_page()

    def _refresh_page(self):
        if self._page is None:
            return
        on = bool(self.surfaces)
        self.lbl_status.setText(f"Showing: {self._source_name()}" if on else "Live wallpaper is off")
        self.lbl_sub.setText(("Paused while a fullscreen app is open" if self.paused_reason else
                              f"Running on {len(self.surfaces)} monitor(s)") if on else
                             "Pick a scene below or add your own video.")
        self.btn_toggle.setText("  Stop" if on else "  Start")
        self.btn_toggle.setIcon(ui.glyph_icon("" if on else "", "white"))
        kind, value = self.source()
        for b in self.previews:
            b.setChecked(kind == "scene" and b.key == value)
        self.lib.clear()
        for path in self.setting("library", []):
            glyph = "" if path.lower().endswith(VIDEO_EXT) else ""
            it = QListWidgetItem(ui.glyph_icon(glyph, ui.ACCENT2), "  " + os.path.basename(path))
            it.setData(Qt.UserRole, path)
            it.setToolTip(path + ("" if os.path.exists(path) else "  (missing)"))
            self.lib.addItem(it)
