"""Per-app volume mixer and a global microphone mute hotkey."""
from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QPushButton, QSlider, QVBoxLayout, QWidget

from core import audio, ui
from core.plugin import Plugin


class Sound(Plugin):
    id = "sound"
    name = "Sound Control"
    icon = ""
    category = "Media"
    order = 15
    description = "Volume for each app in one place, plus a hotkey that mutes your microphone everywhere (Discord, games, calls)."
    hotkeys = {
        "mic": ("Mute / unmute microphone", "ctrl+alt+shift+m"),
        "master_mute": ("Mute / unmute all sound", ""),
        "next_output": ("Switch output (speakers ↔ headphones)", "ctrl+alt+a"),
    }

    def __init__(self, hub):
        super().__init__(hub)
        self._rows = {}
        self._timer = QTimer(self, interval=2000, timeout=self._refresh_sessions)

    def on_enable(self):
        if not audio.AVAILABLE:
            raise RuntimeError("pycaw is not installed")
        self._timer.start()

    def on_disable(self):
        self._timer.stop()

    def status(self):
        try:
            return "Mic muted" if audio.microphone().GetMute() else "Mic live"
        except Exception:
            return "No microphone"

    def tray_actions(self):
        return [("Mute / unmute mic", lambda: self.on_hotkey("mic")),
                ("Switch audio output", self.next_output)]

    # ------------------------------------------------------------ output devices
    def switch_output(self, device_id, name):
        try:
            audio.set_default_output(device_id)
        except Exception:
            self.notify("Windows refused to switch device", "")
            return
        self.hub.osd.show_message(audio.short_name(name), "", sub="Now playing sound through this")
        self._build_outputs()

    def next_output(self):
        skip = set(self.setting("skip_outputs", []))
        outs = [o for o in audio.outputs() if o[0] not in skip] or audio.outputs()
        if len(outs) < 2:
            self.notify("Only one output is plugged in", "")
            return
        cur = audio.default_output_id()
        ids = [o[0] for o in outs]
        nxt = outs[(ids.index(cur) + 1) % len(outs)] if cur in ids else outs[0]
        self.switch_output(*nxt)

    def _build_outputs(self):
        if self._page is None:
            return
        while self.out_box.count():
            w = self.out_box.takeAt(0).widget()
            if w:
                w.deleteLater()
        try:
            outs, cur = audio.outputs(), audio.default_output_id()
        except Exception:
            outs, cur = [], None
        skip = set(self.setting("skip_outputs", []))
        for dev_id, name in outs:
            active = dev_id == cur
            b = QPushButton(("   ✓  " if active else "   ") + name)
            b.setCursor(Qt.PointingHandCursor)
            b.setStyleSheet("text-align:left; padding:10px 12px;" + (
                f"background:{ui.ACCENT}; border:none; color:white; font-weight:600;" if active else ""))
            b.clicked.connect(lambda _=False, i=dev_id, n=name: self.switch_output(i, n))
            cyc = ui.ToggleSwitch(dev_id not in skip)
            cyc.setToolTip("Include in the hotkey cycle")
            cyc.toggled.connect(lambda on, i=dev_id: self._set_skip(i, not on))
            row = QWidget()
            row.setLayout(ui.hrow(b, cyc))
            row.layout().setStretch(0, 1)
            self.out_box.addWidget(row)

    def _set_skip(self, dev_id, skip):
        cur = set(self.setting("skip_outputs", []))
        (cur.add if skip else cur.discard)(dev_id)
        self.set_setting("skip_outputs", sorted(cur))

    def on_hotkey(self, action):
        if action == "next_output":
            self.next_output()
            return
        if action == "mic":
            try:
                mic = audio.microphone()
            except Exception:
                self.notify("No microphone found", "")
                return
            muted = not mic.GetMute()
            mic.SetMute(int(muted), None)
            self.notify("Microphone muted" if muted else "Microphone on", "" if muted else "")
        elif action == "master_mute":
            spk = audio.speakers()
            muted = not spk.GetMute()
            spk.SetMute(int(muted), None)
            self.notify("Sound muted" if muted else "Sound on", "" if muted else "")
        self._refresh_master()

    # ------------------------------------------------------------ page
    def create_page(self):
        page = QWidget()
        self._page = page   # so refresh helpers work while building
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)

        master = ui.Card("Main volume", "")
        self.master = QSlider(Qt.Horizontal)
        self.master.setRange(0, 100)
        self.master.valueChanged.connect(self._master_changed)
        self.master_lbl = ui.label("", "h2")
        self.master_lbl.setFixedWidth(50)
        master.add(ui.hrow(self.master, self.master_lbl))
        self.mic_btn = ui.button("", None, "", lambda: self.on_hotkey("mic"))
        master.add(ui.hrow(ui.label("Microphone"), None, self.mic_btn))
        lay.addWidget(master)

        outs = ui.Card("Output device", "")
        outs.add(ui.label(f"Click to switch where sound plays. {ui.hotkeys.pretty(self.hub.combo_for(self, 'next_output'))} "
                          "cycles through the ones switched on at the right.", "muted", wrap=True))
        self.out_box = QVBoxLayout()
        self.out_box.setSpacing(6)
        outs.add(self.out_box)
        lay.addWidget(outs)

        self.apps = ui.Card("Apps", "")
        self.apps.add(ui.label("Only apps that are currently using sound appear here.", "muted"))
        self.app_box = QVBoxLayout()
        self.app_box.setSpacing(10)
        self.apps.add(self.app_box)
        lay.addWidget(self.apps)
        self._refresh_master()
        self._refresh_sessions()
        self._build_outputs()
        return page

    def _master_changed(self, v):
        audio.speakers().SetMasterVolumeLevelScalar(v / 100, None)
        self.master_lbl.setText(f"{v}%")

    def _refresh_master(self):
        if self._page is None:
            return
        try:
            v = round(audio.speakers().GetMasterVolumeLevelScalar() * 100)
            self.master.blockSignals(True)
            self.master.setValue(v)
            self.master.blockSignals(False)
            self.master_lbl.setText(f"{v}%")
        except Exception:
            pass
        try:
            muted = audio.microphone().GetMute()
            self.mic_btn.setText("  Muted: click to unmute" if muted else "  Live: click to mute")
            self.mic_btn.setIcon(ui.glyph_icon("" if muted else "", ui.BAD if muted else ui.GOOD))
        except Exception:
            self.mic_btn.setText("No microphone")
            self.mic_btn.setEnabled(False)

    def _refresh_sessions(self):
        if self._page is None or (self._rows and not self._page.isVisible()):
            return
        self._refresh_master()
        try:
            sessions = audio.sessions()
        except Exception:
            sessions = []
        seen = set()
        for name, proc, vol in sessions:
            if proc in seen:
                continue
            seen.add(proc)
            if proc not in self._rows:
                row = {"vol": vol}
                slider = QSlider(Qt.Horizontal)
                slider.setRange(0, 100)
                slider.valueChanged.connect(lambda v, row=row: row["vol"].SetMasterVolume(v / 100, None))
                mute = QPushButton()
                mute.setProperty("kind", "ghost")
                mute.setFixedWidth(40)
                mute.clicked.connect(lambda _=False, row=row: (row["vol"].SetMute(int(not row["vol"].GetMute()), None),
                                                               self._refresh_sessions()))
                lbl = ui.label(name)
                lbl.setFixedWidth(180)
                holder = QWidget()
                holder.setLayout(ui.hrow(lbl, slider, mute))
                self.app_box.addWidget(holder)
                row.update(holder=holder, slider=slider, mute=mute)
                self._rows[proc] = row
            row = self._rows[proc]
            row["vol"] = vol   # sessions are re-created each refresh
            slider, mute = row["slider"], row["mute"]
            if not slider.isSliderDown():
                slider.blockSignals(True)
                slider.setValue(round(vol.GetMasterVolume() * 100))
                slider.blockSignals(False)
            muted = bool(vol.GetMute())
            mute.setIcon(ui.glyph_icon("" if muted else "", ui.BAD if muted else ui.TEXT))
        for proc in list(self._rows):
            if proc not in seen:
                self._rows.pop(proc)["holder"].deleteLater()
