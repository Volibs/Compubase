"""Hotkeys, a desktop dock and a radial wheel that open apps, websites and folders."""
import os
import threading
import time
import urllib.parse
import urllib.request
import uuid

from PySide6.QtCore import QFileInfo, QRectF, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QImage, QLinearGradient, QPainter, QPixmap
from PySide6.QtWidgets import (QComboBox, QFileDialog, QFileIconProvider, QFrame, QHBoxLayout, QInputDialog, QLabel,
                               QVBoxLayout, QWidget)

from core import icons, ui
from core.config import APP_DIR
from core.launcher_ui import Dock, Wheel
from core.plugin import Plugin

CACHE = os.path.join(APP_DIR, "cache")

KIND_GLYPH = {"app": "\uE7AC", "web": "\uE774", "folder": "\uE8B7"}
SUGGESTIONS = [
    ("Task Manager", "taskmgr.exe", "app"),
    ("Downloads", os.path.join(os.path.expanduser("~"), "Downloads"), "folder"),
    ("YouTube", "https://youtube.com", "web"),
    ("Calculator", "calc.exe", "app"),
]


class Launcher(Plugin):
    id = "launcher"
    name = "Quick Launch"
    icon = "\uE7AC"
    category = "Productivity"
    order = 55
    description = "Your apps, sites and folders in a desktop dock, a pop-up wheel (Alt+Q) and on their own hotkeys."
    hotkeys = {
        "wheel": ("Open the launcher wheel at the mouse", "alt+q"),
        "dock": ("Show / hide the dock", ""),
    }
    icon_ready = Signal()

    def __init__(self, hub):
        super().__init__(hub)
        self._icons = QFileIconProvider()
        self._pix = {}
        self._fetching = set()
        self.recent = set()
        self.dock = None
        self.wheel = None
        self.icon_ready.connect(self._icons_changed)
        for it in self.setting("items", []):
            self.hotkeys["open_" + it["id"]] = (f"Open {it['name']}", "")

    def on_enable(self):
        QTimer.singleShot(2500, self.repair_all)
        if self.setting("dock_on", True):
            self.set_dock(True, save=False)

    def on_disable(self):
        if self.dock:
            self.dock.stop()
            self.dock.deleteLater()
            self.dock = None
        if self.wheel:
            self.wheel.hide()

    def status(self):
        n = len(self.setting("items", []))
        return f"{n} shortcut{'s' if n != 1 else ''}" + (" \u00B7 dock on" if self.dock else "")

    def tray_actions(self):
        return [(f"Open {it['name']}", lambda it=it: self.launch(it)) for it in self.setting("items", [])[:8]]

    def on_hotkey(self, action):
        if action == "wheel":
            if not self.wheel:
                self.wheel = Wheel(self)
            self.wheel.popup()
            return
        if action == "dock":
            self.set_dock(self.dock is None)
            self.notify("Dock on" if self.dock else "Dock off", self.icon)
            return
        it = next((i for i in self.setting("items", []) if "open_" + i["id"] == action), None)
        if it:
            self.launch(it)

    def repair(self, it):
        """If an app's shortcut was moved or deleted, find the app again in Start → All apps."""
        t = it["target"]
        if it["kind"] != "app" or t.lower().startswith("shell:") or not os.path.isabs(t) or os.path.exists(t):
            return False
        found = icons.find_app(it["name"])
        if not found:
            return False
        it["target"] = found
        self.hub.config.save()
        self._pix = {k: v for k, v in self._pix.items() if k[0] != it["id"]}
        return True

    def repair_all(self):
        fixed = [it["name"] for it in self.setting("items", []) if self.repair(it)]
        if fixed:
            self.hub.osd.show_message("Fixed broken shortcuts", self.icon, sub=", ".join(fixed))
            self._build()

    def launch(self, it, quiet=False):
        self.repair(it)
        try:
            if it["kind"] == "web":
                self.hub.open_url(it["target"])
            else:
                os.startfile(it["target"])
            self.recent.add(it["id"])
            if not quiet:
                self.notify(f"Opening {it['name']}", KIND_GLYPH.get(it["kind"], self.icon))
        except OSError:
            self.notify(f"Couldn't open {it['name']}", "\uE783")

    # ------------------------------------------------------------ dock
    def set_dock(self, on, save=True):
        if save:
            self.set_setting("dock_on", on)
        if on and not self.dock:
            self.dock = Dock(self)
            self.dock.start()
        elif not on and self.dock:
            self.dock.stop()
            self.dock.deleteLater()
            self.dock = None

    def _restart_dock(self):
        if self.dock:
            self.set_dock(False, save=False)
            self.set_dock(True, save=False)

    def open_settings(self):
        self.hub.show_window()
        self.hub.window.open_page(self.id)

    def remove_item(self, it):
        self._remove(it)

    def add_from_url(self, url):
        if url.isLocalFile():
            path = os.path.normpath(url.toLocalFile())
            kind = "folder" if os.path.isdir(path) else "app"
            self.add(os.path.splitext(os.path.basename(path))[0] or path, path, kind)
        elif url.scheme().startswith("http"):
            self.add(url.host().removeprefix("www."), url.toString(), "web")

    # ------------------------------------------------------------ icons
    def item_pixmap(self, it, size):
        key = (it["id"], size)
        if key in self._pix:
            return self._pix[key]
        pm = None
        if it["kind"] == "web":
            host = urllib.parse.urlparse(it["target"]).hostname or ""
            path = os.path.join(CACHE, f"fav_{host}.png")
            if os.path.exists(path):
                pm = QPixmap(path)
            elif host and host not in self._fetching:
                self._fetch_favicon(host, path)
            if pm is None or pm.isNull():
                pm = self._glyph_tile(KIND_GLYPH["web"], it["name"], size)
            else:
                pm = self._framed(pm, size)
        else:
            target = it["target"]
            if it["kind"] == "app" and not os.path.isabs(target) and not target.lower().startswith("shell:"):
                target = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "System32", target)
            pm = icons.best_icon(target, 256) if it["kind"] == "app" else None
            if pm is not None:
                pm = pm.scaled(size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            else:
                pm = self._icons.icon(QFileInfo(target)).pixmap(QSize(size, size))
            if pm.isNull():
                pm = self._glyph_tile(KIND_GLYPH.get(it["kind"], self.icon), it["name"], size)
            elif pm.width() < size * 0.7:
                pm = pm.scaled(size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self._pix[key] = pm
        return pm

    def _glyph_tile(self, glyph, name, size):
        pm = QPixmap(size, size)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing)
        g = QLinearGradient(0, 0, size, size)
        g.setColorAt(0, QColor(ui.ACCENT))
        g.setColorAt(1, QColor(ui.ACCENT2))
        p.setBrush(g)
        p.setPen(Qt.NoPen)
        p.drawRoundedRect(QRectF(0, 0, size, size), size * 0.24, size * 0.24)
        p.setFont(ui.icon_font(int(size * 0.46)))
        p.setPen(QColor("white"))
        p.drawText(pm.rect(), Qt.AlignCenter, glyph)
        p.end()
        return pm

    def _framed(self, fav, size):
        """Favicons are tiny: put them on a white rounded tile like a phone app icon."""
        pm = QPixmap(size, size)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.setBrush(QColor("#f4f5f8"))
        p.setPen(Qt.NoPen)
        p.drawRoundedRect(QRectF(0, 0, size, size), size * 0.24, size * 0.24)
        inner = int(size * 0.6)
        p.drawPixmap((size - inner) // 2, (size - inner) // 2,
                     fav.scaled(inner, inner, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        p.end()
        return pm

    def _fetch_favicon(self, host, path):
        """Download the site's own favicon (straight from the site, no third-party service)."""
        self._fetching.add(host)

        def work():
            os.makedirs(CACHE, exist_ok=True)
            for url in (f"https://{host}/apple-touch-icon.png", f"https://{host}/favicon.ico"):
                try:
                    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 NexusHub"})
                    with urllib.request.urlopen(req, timeout=8) as r:
                        data = r.read(512 * 1024)
                    img = QImage()   # QImage (not QPixmap) is safe off the UI thread
                    if data and img.loadFromData(data) and not img.isNull():
                        img.save(path, "PNG")
                        self.icon_ready.emit()
                        return
                except (OSError, ValueError):
                    continue
        threading.Thread(target=work, daemon=True).start()

    def _icons_changed(self):
        self._pix.clear()
        if self.dock:
            self.dock.update()
        if self._page is not None:
            self._build()

    # ------------------------------------------------------------ editing
    def add(self, name, target, kind):
        it = {"id": uuid.uuid4().hex[:8], "name": name, "target": target, "kind": kind}
        self.set_setting("items", self.setting("items", []) + [it])
        self.add_hotkey("open_" + it["id"], f"Open {name}")
        self._build()

    def _add_app(self):
        path, _ = QFileDialog.getOpenFileName(None, "Choose an app", r"C:\ProgramData\Microsoft\Windows\Start Menu\Programs",
                                              "Apps & shortcuts (*.exe *.lnk *.url *.bat);;Any file (*)")
        if path:
            self.add(os.path.splitext(os.path.basename(path))[0], os.path.normpath(path), "app")

    def _add_folder(self):
        path = QFileDialog.getExistingDirectory(None, "Choose a folder")
        if path:
            self.add(os.path.basename(path) or path, os.path.normpath(path), "folder")

    def _add_web(self):
        url, ok = QInputDialog.getText(None, "Add website", "Web address:", text="https://")
        if not ok or len(url.strip()) < 4:
            return
        url = url.strip()
        if "://" not in url:
            url = "https://" + url
        name = url.split("://", 1)[1].split("/")[0].removeprefix("www.")
        self.add(name, url, "web")

    def _rename(self, it):
        name, ok = QInputDialog.getText(None, "Rename", "Name:", text=it["name"])
        if ok and name.strip():
            it["name"] = name.strip()
            self.hotkeys["open_" + it["id"]] = (f"Open {it['name']}", "")
            self.hub.config.save()
            self._build()

    def _remove(self, it):
        self.set_setting("items", [i for i in self.setting("items", []) if i["id"] != it["id"]])
        self.remove_hotkey("open_" + it["id"])
        self._build()

    # ------------------------------------------------------------ page
    def create_page(self):
        page = QWidget()
        self._page = page
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)
        card = ui.Card("Shortcuts", "\uE7AC")
        card.add(ui.hrow(ui.button("Add app", "primary", "\uE710", self._add_app),
                         ui.button("Add website", None, "\uE774", self._add_web),
                         ui.button("Add folder", None, "\uE8B7", self._add_folder), None))
        self.box = QVBoxLayout()
        self.box.setSpacing(8)
        card.add(self.box)
        card.add(ui.label("Tip: drag apps, folders or links from your desktop straight onto the dock to add them.", "muted"))
        lay.addWidget(card)

        pop = ui.Card("On your desktop", "\uE8A7")
        dock = ui.ToggleSwitch(self.dock is not None)
        dock.toggled.connect(self.set_dock)
        pop.add(ui.hrow(ui.label("Dock: your shortcuts in a bar that magnifies as you hover (like a Mac)"), None, dock))
        where = QComboBox()
        where.addItem("Bottom of the screen", "bottom")
        where.addItem("Top of the screen", "top")
        where.setCurrentIndex(0 if self.setting("dock_pos", "bottom") == "bottom" else 1)
        where.currentIndexChanged.connect(lambda _: (self.set_setting("dock_pos", where.currentData()), self._restart_dock()))
        pop.add(ui.hrow(ui.label("Dock position"), None, where))
        hide = ui.ToggleSwitch(self.setting("dock_autohide", True))
        hide.toggled.connect(lambda on: (self.set_setting("dock_autohide", on), self._restart_dock()))
        pop.add(ui.hrow(ui.label("Auto-hide: slides in when you push the mouse to that screen edge"), None, hide))
        pop.lay.addSpacing(6)
        combo = ui.hotkeys.pretty(self.hub.combo_for(self, "wheel"))
        pop.add(ui.hrow(ui.label(f"Launcher wheel: press {combo} and a ring of your apps pops up around the mouse. "
                                 "Point and click, or press 1\u20139."),
                        None, ui.button("Try it", "primary", "\uE768", lambda: self.on_hotkey("wheel"))))
        lay.addWidget(pop)

        sug = ui.Card("Ideas", "\uEA80")
        row = QHBoxLayout()
        for name, target, kind in SUGGESTIONS:
            row.addWidget(ui.button(name, None, KIND_GLYPH[kind], lambda _=False, n=name, t=target, k=kind: self.add(n, t, k)))
        row.addStretch()
        sug.add(row)
        lay.addWidget(sug)
        self._build()
        return page

    def _item_icon(self, it):
        lbl = QLabel()
        lbl.setFixedSize(40, 40)
        lbl.setAlignment(Qt.AlignCenter)
        lbl.setPixmap(self.item_pixmap(it, 64).scaled(34, 34, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        return lbl

    def _build(self):
        if self.dock:
            self.dock.reload()
        if self._page is None:
            return
        while self.box.count():
            w = self.box.takeAt(0).widget()
            if w:
                w.deleteLater()
        items = self.setting("items", [])
        if not items:
            self.box.addWidget(ui.label("Nothing here yet. Add an app, website or folder above, or pick an idea below.", "muted"))
        for it in items:
            row = QFrame()
            row.setStyleSheet(f"QFrame {{ background:{ui.SURFACE2}; border-radius:10px; }}")
            rl = QHBoxLayout(row)
            rl.setContentsMargins(10, 8, 10, 8)
            rl.addWidget(self._item_icon(it))
            col = QVBoxLayout()
            col.setSpacing(0)
            col.addWidget(ui.label(it["name"], "h2"))
            sub = ui.label(it["target"], "muted")
            sub.setMaximumWidth(420)
            col.addWidget(sub)
            rl.addLayout(col, 1)
            rl.addWidget(self.hotkey_editor("open_" + it["id"]))
            rl.addWidget(ui.button("", None, "\uE768", lambda _=False, it=it: self.launch(it)))
            rl.addWidget(ui.button("", "ghost", "\uE8AC", lambda _=False, it=it: self._rename(it)))
            rl.addWidget(ui.button("", "ghost", "\uE74D", lambda _=False, it=it: self._remove(it)))
            self.box.addWidget(row)
