@echo off
title NexusHub setup
cd /d "%~dp0"
echo Installing what NexusHub needs...
python -m pip install --upgrade -r requirements.txt
if errorlevel 1 (
  echo.
  echo Setup failed. Make sure Python is installed from python.org and try again.
  pause
  exit /b 1
)
echo Creating a desktop shortcut...
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\NexusHub.lnk'); $s.TargetPath=(Get-Command pythonw).Source; $s.Arguments='\"%~dp0NexusHub.pyw\"'; $s.WorkingDirectory='%~dp0'; $s.Save()"
echo Done! Starting NexusHub...
start "" pythonw "%~dp0NexusHub.pyw"
