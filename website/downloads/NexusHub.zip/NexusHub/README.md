# NexusHub

Your personal Windows control hub: one app in the tray that runs lots of small modules in the background.

## Start it
- **First time:** double-click `install.bat`. It installs what's needed, makes a desktop shortcut and launches the app.
- **After that:** use the desktop shortcut or double-click `NexusHub.pyw`.
- Closing the window just hides it; everything keeps working. A small guardian process restarts NexusHub if it's
  killed or crashes, and always restores the Windows taskbar. To really quit: Settings → "Quit NexusHub completely".
- **Settings → Start with Windows** makes it launch quietly when you sign in.

## Modules
| Module | What it does | Default hotkeys |
|---|---|---|
| **Taskbar** | Replaces the Windows taskbar: new Start menu, pinned quick apps + open windows, Spotify, volume/output switcher, Wi-Fi, clock & calendar. Full-width or floating, top or bottom, 3 sizes. The Windows taskbar is only hidden and always comes back (module off, quit, or crash) | Ctrl+Alt+Shift+Space Start, Ctrl+Alt+Shift+T show Windows taskbar 10 s |
| **Browser** | Tabbed browser inside NexusHub; stays signed in; searches and web shortcuts open here | Ctrl+Alt+B |
| **Nexus Bar** | Spotlight-style command bar: every NexusHub action, your apps, Windows settings, maths, web search. Learns what you use most | **Alt+Space** |
| **Desktop Widgets** | Clock, weather, PC stats and Spotify controls on your desktop. Drag them anywhere; they come back on Win+D | Ctrl+Alt+Shift+W |
| **Game Mode** | Detects games, switches to max performance, boosts the game, lowers Spotify, hides widgets. Restores everything after | Ctrl+Alt+G |
| Spotify Hotkeys | Play/pause, skip, Spotify-only volume, song popups, **favourite songs/albums/playlists on their own hotkeys**. Connect Spotify (Premium) for instant play, Like, Shuffle, ±15 s | Ctrl+Alt+P play/pause, Ctrl+Alt+← / → skip, Ctrl+Alt+↑ / ↓ volume, Ctrl+Alt+M mute, Ctrl+Alt+N now playing, Ctrl+Alt+L like, Ctrl+Alt+H shuffle, Ctrl+Alt+Shift+← / → seek |
| Soundboard | Sound pads with hotkeys, drag-and-drop, can play into Discord through VB-Cable | per pad, Ctrl+Alt+Shift+X stop all |
| Sound Control | Volume for each app, global mic mute, **switch speakers ↔ headphones** | Ctrl+Alt+Shift+M mic, Ctrl+Alt+A output |
| Live Wallpaper | Animated scenes, videos and GIFs behind your icons. Pauses in fullscreen games | Ctrl+Alt+W |
| Display | Extra dim below minimum brightness, warm night filter, scheduled dark/light mode | Ctrl+Alt+Shift+PgDn / PgUp dim, Ctrl+Alt+Shift+N night, Ctrl+Alt+Shift+D theme |
| Speed Test | Download/upload/ping, history, automatic tests | none |
| System Monitor | Live graphs, busiest apps, force-close, on-top stats overlay | Ctrl+Alt+O |
| Crosshair | Custom crosshair overlay for games | Ctrl+Alt+Shift+C |
| Window Tools | Pin on top, see-through, centre, force-close | Ctrl+Alt+T, Ctrl+Alt+PgUp/PgDn, Ctrl+Alt+C, Ctrl+Alt+Shift+K |
| Quick Launch | Your apps/sites/folders in a **magnifying desktop dock** and a **radial wheel**, plus per-app hotkeys. Broken shortcuts fix themselves | **Alt+Q** wheel, per shortcut |
| Keep Awake | Stop sleep for a set time | Ctrl+Alt+Shift+A |
| Power Tools | Screen off, fix taskbar, flush DNS, clean junk, power plans… | Ctrl+Alt+Shift+S screen off |
| Clipboard History | Search and paste older copies, pin favourites | Ctrl+Alt+V |
| Focus Timer | Pomodoro, water/eye-break reminders, "remind me in X min" | Ctrl+Alt+Shift+F |
| Color Picker | Copy the colour under the mouse (HEX/RGB/HSL) | Ctrl+Alt+Shift+P |

Change any hotkey in **Settings** (per-item ones on the module's page). If one says *"Taken by another app"*, pick a different combo.

## Customise
**Settings → Appearance**: 8 colour themes or your own colours, title-bar and border colour (Windows 11), app name, start page.
**Settings → Sidebar tabs**: reorder or hide tabs. Modules you switch off disappear from the sidebar automatically.
**Display → Taskbar**: alignment, search box, Task View, seconds on the clock, "End task" on right-click, auto-hide.

## Spotify favourites
Favourite hotkeys open the album/playlist and press **Shuffle + Play** for you (toggle 🔀 per favourite). No setup needed.
Optional, for instant play without Spotify's window:
1. Go to https://developer.spotify.com/dashboard, log in, and click **Create app**.
2. Set the Redirect URI to `http://127.0.0.1:8888/callback` and tick **Web API**.
3. Copy the **Client ID** into NexusHub → Spotify → Connect.

## Add your own module
Copy `plugins/_TEMPLATE.py` to `plugins/my_thing.py`, edit it, and restart NexusHub.

## Where things are saved
`%APPDATA%\NexusHub\`: `config.json` (settings, clipboard & speed history), `sounds\` (soundboard files), `nexushub.log` (errors).
