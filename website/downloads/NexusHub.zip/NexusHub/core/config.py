"""Tiny JSON config store. The live file is the active profile (see core/accounts.py)."""
import json
import os

APP_DIR = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "NexusHub")
CONFIG_PATH = os.path.join(APP_DIR, "config.json")     # pre-profiles location, migrated automatically


class Config:
    def __init__(self, path=None):
        if path is None:
            from .accounts import active_profile_path
            path = active_profile_path()
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        try:
            with open(path, "r", encoding="utf-8") as f:
                self.data = json.load(f)
            if not isinstance(self.data, dict):
                self.data = {}
        except (OSError, ValueError):
            self.data = {}

    def get(self, key, default=None):
        return self.data.get(key, default)

    def set(self, key, value):
        self.data[key] = value
        self.save()

    def section(self, name):
        """A dict that lives inside the config (mutate it, then call save())."""
        sec = self.data.get(name)
        if not isinstance(sec, dict):
            sec = self.data[name] = {}
        return sec

    def save(self):
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=2)
            os.replace(tmp, self.path)
        except OSError:
            pass
