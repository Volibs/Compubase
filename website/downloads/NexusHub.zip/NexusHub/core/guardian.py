"""NexusHub guardian: a tiny separate process that keeps your PC safe and NexusHub alive.

Run as:  pythonw guardian.py <nexushub pid>

* If NexusHub disappears while its custom taskbar has the Windows taskbar hidden, the Windows
  taskbar is put back immediately (so you're never left without one).
* If NexusHub didn't quit on purpose (crash, killed in Task Manager) and "keep NexusHub running"
  is on, it's started again.
Only uses the standard library so it stays tiny and starts instantly.
"""
import ctypes
import json
import os
import subprocess
import sys
import time
from ctypes import wintypes

APP_DIR = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "NexusHub")
STATE = os.path.join(APP_DIR, "taskbar_state.json")
CLEAN = os.path.join(APP_DIR, "clean_exit")
CONFIG = os.path.join(APP_DIR, "config.json")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

user32 = ctypes.WinDLL("user32")
kernel32 = ctypes.WinDLL("kernel32")
user32.FindWindowW.restype = wintypes.HWND
user32.FindWindowExW.restype = wintypes.HWND
user32.FindWindowExW.argtypes = [wintypes.HWND, wintypes.HWND, wintypes.LPCWSTR, wintypes.LPCWSTR]


def alive(pid):
    h = kernel32.OpenProcess(0x1000 | 0x00100000, False, pid)   # QUERY_LIMITED_INFORMATION | SYNCHRONIZE
    if not h:
        return False
    try:
        return kernel32.WaitForSingleObject(h, 0) == 0x102        # WAIT_TIMEOUT = still running
    finally:
        kernel32.CloseHandle(h)


class APPBARDATA(ctypes.Structure):
    _fields_ = [("cbSize", ctypes.c_uint), ("hWnd", ctypes.c_void_p), ("uCallbackMessage", ctypes.c_uint),
                ("uEdge", ctypes.c_uint), ("rc", ctypes.c_long * 4), ("lParam", ctypes.c_ssize_t)]


def set_autohide(on):
    shell = ctypes.windll.shell32
    shell.SHAppBarMessage.restype = ctypes.c_size_t
    abd = APPBARDATA()
    abd.cbSize = ctypes.sizeof(abd)
    state = shell.SHAppBarMessage(0x4, ctypes.byref(abd))
    abd.lParam = (state & ~0x1) | (0x1 if on else 0)
    shell.SHAppBarMessage(0xA, ctypes.byref(abd))


def restore_windows_taskbar():
    try:
        with open(STATE, encoding="utf-8") as f:
            state = json.load(f)
    except (OSError, ValueError):
        state = {}
    for cls in ("Shell_TrayWnd", "Shell_SecondaryTrayWnd"):
        hwnd = user32.FindWindowW(cls, None)
        while hwnd:
            user32.ShowWindow(hwnd, 5)     # SW_SHOW
            hwnd = user32.FindWindowExW(None, hwnd, cls, None)
    if state.get("hidden"):
        set_autohide(bool(state.get("prev_autohide", False)))
        state["hidden"] = False
        try:
            with open(STATE, "w", encoding="utf-8") as f:
                json.dump(state, f)
        except OSError:
            pass


def keep_alive_enabled():
    # the live settings are the active profile (profiles\<owner>\<id>.json); fall back to the old config.json
    path = CONFIG
    try:
        with open(os.path.join(APP_DIR, "session.json"), encoding="utf-8") as f:
            s = json.load(f)
        path = os.path.join(APP_DIR, "profiles", s.get("owner", "local"), s.get("profile", "default") + ".json")
    except (OSError, ValueError):
        pass
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f).get("keep_alive", True)
    except (OSError, ValueError):
        return True


def another_copy_running():
    """True if a different NexusHub is already up (e.g. after a theme restart)."""
    kernel32.OpenMutexW.restype = wintypes.HANDLE
    h = kernel32.OpenMutexW(0x00100000, False, "NexusHub-running-" + os.environ.get("USERNAME", "user"))
    if h:
        kernel32.CloseHandle(h)
        return True
    return False


def crash_looping():
    """Give up after 3 restarts in 2 minutes, so a broken module can't cause an endless loop."""
    path = os.path.join(APP_DIR, "restarts.json")
    now = time.time()
    try:
        with open(path, encoding="utf-8") as f:
            recent = [t for t in json.load(f) if now - t < 120]
    except (OSError, ValueError):
        recent = []
    recent.append(now)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(recent, f)
    except OSError:
        pass
    return len(recent) > 3


def main():
    pid = int(sys.argv[1])
    flag = f"{CLEAN}_{pid}"      # each NexusHub copy has its own "I quit on purpose" flag
    while alive(pid):
        time.sleep(1.0)
    clean = os.path.exists(flag)
    if clean:
        try:
            os.remove(flag)
        except OSError:
            pass
    if not another_copy_running():
        restore_windows_taskbar()     # a restarted copy re-hides it itself
    if clean or another_copy_running():
        return
    if keep_alive_enabled() and not crash_looping():
        time.sleep(2)   # let Windows settle, and avoid tight restart loops
        exe = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
        subprocess.Popen([exe if os.path.exists(exe) else sys.executable,
                          os.path.join(ROOT, "NexusHub.pyw"), "--minimized", "--recovered"],
                         creationflags=0x00000008 | 0x00000200, close_fds=True)   # DETACHED | NEW_PROCESS_GROUP


if __name__ == "__main__":
    main()
