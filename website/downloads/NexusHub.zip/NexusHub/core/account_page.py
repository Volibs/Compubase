"""Account & profiles page, plus background sync with Google Drive."""
import os
import threading
import time

from PySide6.QtCore import QObject, QRectF, QSize, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QFont, QGuiApplication, QLinearGradient, QPainter, QPainterPath, QPixmap
from PySide6.QtWidgets import (QFrame, QHBoxLayout, QInputDialog, QLabel, QLineEdit, QMessageBox, QPushButton,
                               QVBoxLayout, QWidget)

from . import accounts as acc
from . import ui


def avatar_pixmap(sub, name, size):
    """Round avatar: your Google photo, or your initial on the accent gradient."""
    pm = QPixmap(size, size)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    p.setRenderHint(QPainter.SmoothPixmapTransform)
    path = QPainterPath()
    path.addEllipse(QRectF(0, 0, size, size))
    p.setClipPath(path)
    photo = QPixmap(acc.avatar_path(sub)) if sub and sub != acc.LOCAL else QPixmap()
    if not photo.isNull():
        p.drawPixmap(0, 0, photo.scaled(size, size, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation))
    else:
        g = QLinearGradient(0, 0, size, size)
        g.setColorAt(0, QColor(ui.ACCENT))
        g.setColorAt(1, QColor(ui.ACCENT2))
        p.fillRect(pm.rect(), g)
        f = QFont(ui.TEXT_FONT)
        f.setPixelSize(int(size * 0.45))
        f.setWeight(QFont.Bold)
        p.setFont(f)
        p.setPen(QColor("white"))
        p.drawText(pm.rect(), Qt.AlignCenter, (name[:1] or "?").upper())
    p.end()
    return pm


def current_identity():
    s = acc.session()
    if s["owner"] == acc.LOCAL:
        return acc.LOCAL, os.environ.get("USERNAME", "You"), "Local account on this PC"
    info = acc.account(s["owner"]) or {}
    return s["owner"], info.get("name", "Google account"), info.get("email", "")


def profile_name(owner, pid):
    return next((p["name"] for p in acc.list_profiles(owner) if p["id"] == pid), pid)


class _Bridge(QObject):
    done = Signal(str, object)      # what, result-or-exception


class AccountSync(QObject):
    """Keeps a signed-in account's profiles backed up: every few minutes, only when something changed."""

    def __init__(self, hub):
        super().__init__()
        self.hub = hub
        self.bridge = _Bridge()
        self.bridge.done.connect(self._done)
        self.busy = False
        self.last = ""
        self.listeners = []
        self._timer = QTimer(self, interval=3 * 60 * 1000, timeout=lambda: self.run(only_if_changed=True))
        s = acc.session()
        if s["owner"] != acc.LOCAL and acc.signed_in(s["owner"]):
            self._timer.start()
            QTimer.singleShot(10_000, self.run)          # catch changes made on your other PCs

    def run(self, only_if_changed=False):
        s = acc.session()
        sub = s["owner"]
        if self.busy or sub == acc.LOCAL or not acc.signed_in(sub):
            return
        if only_if_changed:
            state = acc._read(os.path.join(acc.ACCOUNTS, f"{sub}.sync.json"), {})
            if os.path.getmtime(acc.profile_path(sub, s["profile"])) <= state.get("_last", 0):
                return
        self.hub.config.save()
        self.busy = True
        self._notify("Syncing…")

        def work():
            try:
                self.bridge.done.emit("sync", acc.sync(sub))
            except Exception as e:
                self.bridge.done.emit("sync", e)
        threading.Thread(target=work, daemon=True).start()

    def _done(self, what, res):
        self.busy = False
        if isinstance(res, Exception):
            self._notify(f"Sync failed: {res}")
            return
        self._notify(f"Synced with Google Drive at {time.strftime('%H:%M')}")
        if res.get("active_changed"):
            self.hub.osd.show_message("Profile updated from another PC", "", sub="Restart NexusHub to use the new version")

    def _notify(self, text):
        self.last = text
        for fn in self.listeners:
            fn(text)


class AccountPage(QWidget):
    def __init__(self, hub):
        super().__init__(objectName="page")
        self.hub = hub
        self.sync = hub.account_sync
        self.sync.listeners.append(self._sync_status)
        self.bridge = _Bridge()
        self.bridge.done.connect(self._signed_in)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        from .hub import scroll
        body = QWidget()
        self.lay = QVBoxLayout(body)
        self.lay.setContentsMargins(34, 28, 34, 30)
        self.lay.setSpacing(16)
        outer.addWidget(scroll(body))
        self.build()

    # ------------------------------------------------------------ layout
    def build(self):
        while self.lay.count():
            item = self.lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.lay.addWidget(ui.label("Account & profiles", "h1"))
        self.lay.addWidget(self._account_card())
        self.lay.addWidget(self._profiles_card())
        c = acc.client()
        if not c.get("client_id") or not c.get("client_secret") or getattr(self, "_show_setup", False):
            self.lay.addWidget(self._setup_card())
        self.lay.addStretch()

    def _account_card(self):
        sub, name, email = current_identity()
        card = ui.Card()
        row = QHBoxLayout()
        row.setSpacing(18)
        pic = QLabel()
        pic.setPixmap(avatar_pixmap(sub, name, 72))
        row.addWidget(pic)
        col = QVBoxLayout()
        col.setSpacing(2)
        col.addWidget(ui.label(name, "big"))
        col.addWidget(ui.label(email, "muted"))
        self.sync_lbl = ui.label(self.sync.last if sub != acc.LOCAL else
                                 "Sign in with Google to back up your profiles and use them on any PC.", "muted", wrap=True)
        self.sync_lbl.setStyleSheet(f"color:{ui.ACCENT2}; font-size:12px;")
        col.addWidget(self.sync_lbl)
        row.addLayout(col, 1)
        btns = QVBoxLayout()
        if sub == acc.LOCAL:
            b = ui.button("  Sign in with Google", "primary", "", self._sign_in)
            b.setMinimumHeight(42)
            btns.addWidget(b)
        else:
            btns.addWidget(ui.button("Sync now", None, "", lambda: self.sync.run()))
            btns.addWidget(ui.button("Sign out", "ghost", "", self._sign_out))
        row.addLayout(btns)
        card.add(row)
        return card

    def _profiles_card(self):
        s = acc.session()
        card = ui.Card("Profiles", "")
        card.add(ui.label("Each profile is a complete setup: theme, dock, hotkeys, favourites, sounds… "
                          "Switch between them in one click (NexusHub restarts in about 2 seconds).", "muted", wrap=True))
        for p in acc.list_profiles(s["owner"]):
            active = p["id"] == s["profile"]
            row = QFrame(objectName="profrow")
            row.setStyleSheet(
                f"#profrow {{ background: {ui.rgba(ui.ACCENT, 0.16) if active else ui.SURFACE2}; border-radius: 12px;"
                f" border: 1px solid {ui.rgba(ui.ACCENT, 0.6) if active else 'transparent'}; }}")
            h = QHBoxLayout(row)
            h.setContentsMargins(14, 10, 10, 10)
            h.addWidget(ui.glyph_label("", 16, ui.ACCENT2 if active else ui.MUTED))
            h.addWidget(ui.label(p["name"], "h2"))
            if active:
                h.addWidget(ui.label("In use", "pill"))
            h.addStretch()
            if not active:
                h.addWidget(ui.button("Switch", "primary", "", lambda _=False, pid=p["id"]: self._switch(pid)))
            h.addWidget(ui.button("", "ghost", "", lambda _=False, p=p: self._rename(p)))
            h.addWidget(ui.button("", "ghost", "", lambda _=False, p=p: self._duplicate(p)))
            if not active:
                h.addWidget(ui.button("", "ghost", "", lambda _=False, p=p: self._delete(p)))
            card.add(row)
        card.add(ui.hrow(ui.button("New profile", None, "", self._new), None))
        return card

    def _setup_card(self):
        card = ui.Card("Google sign-in setup (one time, about 5 minutes)", "")
        card.add(ui.label(
            "Google needs every app to have its own sign-in key. Create yours once:<br>"
            "1. Open <b>Google Cloud Console</b> and create a project (any name, e.g. NexusHub).<br>"
            "2. <b>APIs &amp; Services → Library</b>: enable <b>Google Drive API</b>.<br>"
            "3. <b>OAuth consent screen</b>: choose <b>External</b>, fill in the app name and your email. Then under "
            "Audience press <b>Publish app</b> (or add yourself as a test user; test logins expire every 7 days).<br>"
            "4. <b>Credentials → Create credentials → OAuth client ID</b> → type <b>Desktop app</b>.<br>"
            "5. Copy the <b>Client ID</b> and <b>Client secret</b> into the boxes below and press Save.",
            "muted", wrap=True))
        c = acc.client()
        cid = QLineEdit(placeholderText="Client ID (ends with .apps.googleusercontent.com)", text=c.get("client_id", ""))
        sec = QLineEdit(placeholderText="Client secret", text=c.get("client_secret", ""))
        sec.setEchoMode(QLineEdit.Password)
        card.add(cid)
        card.add(sec)
        card.add(ui.hrow(
            ui.button("Open Google Cloud Console", None, "",
                      lambda: QDesktopServices.openUrl(QUrl("https://console.cloud.google.com/apis/credentials"))),
            None,
            ui.button("Save", "primary", "", lambda: self._save_client(cid.text(), sec.text()))))
        return card

    # ------------------------------------------------------------ actions
    def _save_client(self, cid, secret):
        if ".apps.googleusercontent.com" not in cid or len(secret.strip()) < 10:
            QMessageBox.warning(self, "Google setup", "That doesn't look like a Desktop-app Client ID and secret.")
            return
        acc.set_client(cid, secret)
        self._show_setup = False
        self.hub.osd.show_message("Google sign-in is built in now", "",
                                  sub="Everyone you share NexusHub with can sign in without any setup")
        self.build()

    def _sign_in(self):
        c = acc.client()
        if not c.get("client_id") or not c.get("client_secret"):
            self._show_setup = True
            self.build()
            self.hub.osd.show_message("One-time Google setup needed", "", sub="Follow the steps on the Account page")
            return
        self.sync_lbl.setText("Finish signing in in your browser…")

        def work():
            try:
                info = acc.sign_in()
                sub = info["sub"]
                if acc.cloud_has_profiles(sub):
                    acc.sync(sub)                      # this account already has profiles: bring them here
                else:
                    acc.adopt_local_profiles(sub)      # first time: your current setup becomes the account's
                    acc.sync(sub)
                self.bridge.done.emit("signin", info)
            except Exception as e:
                self.bridge.done.emit("signin", e)
        threading.Thread(target=work, daemon=True).start()

    def _signed_in(self, what, res):
        if isinstance(res, Exception):
            self.sync_lbl.setText(f"Sign-in failed: {res}")
            return
        sub = res["sub"]
        cur = acc.session()["profile"]
        ids = [p["id"] for p in acc.list_profiles(sub)]
        acc.set_session(sub, cur if cur in ids else ids[0])
        self.hub.osd.show_message(f"Welcome, {res['name'].split(' ')[0]}!", "", sub="Loading your profile…")
        QTimer.singleShot(900, self.hub.restart)

    def _sign_out(self):
        sub = acc.session()["owner"]
        if QMessageBox.question(self, "Sign out", "Sign out of Google on this PC?\n\nYour profiles stay safe in your "
                                "Google Drive. NexusHub goes back to your local profiles.") != QMessageBox.Yes:
            return
        self.hub.config.save()
        try:
            acc.sync(sub)          # last backup before leaving
        except Exception:
            pass
        acc.sign_out(sub)
        ids = [p["id"] for p in acc.list_profiles(acc.LOCAL)]
        acc.set_session(acc.LOCAL, ids[0] if ids else "default")
        self.hub.restart()

    def _switch(self, pid):
        s = acc.session()
        self.hub.config.save()
        acc.set_session(s["owner"], pid)
        self.hub.osd.show_message(f"Switching to {profile_name(s['owner'], pid)}", "", sub="Restarting NexusHub…")
        QTimer.singleShot(600, self.hub.restart)

    def _new(self):
        name, ok = QInputDialog.getText(self, "New profile", "Name (e.g. Gaming, Work, Chill):")
        if not ok or not name.strip():
            return
        copy = QMessageBox.question(self, "New profile", "Start from a copy of your current setup?\n\n"
                                    "Yes = copy everything you have now.  No = start fresh with defaults.") == QMessageBox.Yes
        self.hub.config.save()
        pid = acc.create_profile(name, copy_from_current=copy)
        if QMessageBox.question(self, "New profile", f"Switch to “{name}” now?") == QMessageBox.Yes:
            self._switch(pid)
        else:
            self.build()

    def _rename(self, p):
        name, ok = QInputDialog.getText(self, "Rename profile", "Name:", text=p["name"])
        if ok and name.strip():
            acc.rename_profile(p["id"], name)
            self.build()
            self.hub.window.refresh_account_chip()

    def _duplicate(self, p):
        s = acc.session()
        self.hub.config.save()
        src = acc._read(acc.profile_path(s["owner"], p["id"]), {})
        pid = acc.create_profile(p["name"] + " copy", copy_from_current=False)
        acc._write(acc.profile_path(s["owner"], pid), src)
        self.build()

    def _delete(self, p):
        if QMessageBox.question(self, "Delete profile", f"Delete the profile “{p['name']}”?"
                                + ("\n\nIt will also be removed from your Google Drive." if acc.session()["owner"] != acc.LOCAL else "")
                                ) == QMessageBox.Yes:
            acc.delete_profile(p["id"])
            self.build()

    def _sync_status(self, text):
        try:
            self.sync_lbl.setText(text)
        except RuntimeError:
            pass
