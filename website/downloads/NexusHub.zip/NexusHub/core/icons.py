"""Crisp app icons: follow shortcuts (.lnk) to their real icon, at up to 256 px, without the shortcut arrow."""
import ctypes
import os
import time
from ctypes import wintypes

from PySide6.QtGui import QIcon, QImage, QPixmap

user32 = ctypes.WinDLL("user32")
user32.PrivateExtractIconsW.argtypes = [wintypes.LPCWSTR, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                        ctypes.POINTER(wintypes.HICON), ctypes.POINTER(wintypes.UINT),
                                        wintypes.UINT, wintypes.UINT]
user32.PrivateExtractIconsW.restype = wintypes.UINT
user32.DestroyIcon.argtypes = [wintypes.HICON]

_shell = None


def resolve_shortcut(path):
    """(target, icon_file, icon_index) for a .lnk; icon_file may be ''."""
    global _shell
    import comtypes.client
    if _shell is None:
        _shell = comtypes.client.CreateObject("WScript.Shell", dynamic=True)
    sc = _shell.CreateShortcut(path)
    icon, _, idx = (sc.IconLocation or "").rpartition(",")
    icon = os.path.expandvars(icon.strip()) if icon else ""
    try:
        idx = int(idx)
    except ValueError:
        idx = 0
    return os.path.expandvars(sc.TargetPath or ""), icon, idx


def extract(path, index=0, size=256):
    """Icon number `index` from an .exe/.dll/.ico at the given size, as a QPixmap (or None)."""
    if not path or not os.path.exists(path):
        return None
    if path.lower().endswith(".ico"):
        pm = QIcon(path).pixmap(size, size)
        return pm if not pm.isNull() else None
    hicon = wintypes.HICON()
    got = user32.PrivateExtractIconsW(path, index, size, size, ctypes.byref(hicon), None, 1, 0)
    if not got or not hicon:
        return None
    try:
        img = QImage.fromHICON(hicon.value)
    finally:
        user32.DestroyIcon(hicon)
    return QPixmap.fromImage(img) if not img.isNull() else None


def shell_image(path, size=256):
    """Ask Explorer itself for the picture (works for Store apps and 'advertised' shortcuts)."""
    import comtypes
    from comtypes import COMMETHOD, GUID, HRESULT, IUnknown

    class SIZE(ctypes.Structure):
        _fields_ = [("cx", ctypes.c_long), ("cy", ctypes.c_long)]

    class IShellItemImageFactory(IUnknown):
        _iid_ = GUID("{bcc18b79-ba16-442f-80c4-8a59c30c463b}")
        _methods_ = [COMMETHOD([], HRESULT, "GetImage", (["in"], SIZE, "size"), (["in"], ctypes.c_int, "flags"),
                               (["out"], ctypes.POINTER(wintypes.HBITMAP), "phbm"))]

    shell32 = ctypes.windll.shell32
    factory = ctypes.POINTER(IShellItemImageFactory)()
    hr = shell32.SHCreateItemFromParsingName(ctypes.c_wchar_p(path), None,
                                             ctypes.byref(IShellItemImageFactory._iid_), ctypes.byref(factory))
    if hr != 0 or not factory:
        return None
    hbm = factory.GetImage(SIZE(size, size), 0x1 | 0x4)       # BIGGERSIZEOK | ICONONLY
    try:
        img = _hbitmap_with_alpha(hbm)
    finally:
        ctypes.windll.gdi32.DeleteObject(hbm)
    return QPixmap.fromImage(img) if img is not None and not img.isNull() else None


class _BITMAP(ctypes.Structure):
    _fields_ = [("bmType", ctypes.c_long), ("bmWidth", ctypes.c_long), ("bmHeight", ctypes.c_long),
                ("bmWidthBytes", ctypes.c_long), ("bmPlanes", ctypes.c_ushort), ("bmBitsPixel", ctypes.c_ushort),
                ("bmBits", ctypes.c_void_p)]


class _BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [("biSize", ctypes.c_uint32), ("biWidth", ctypes.c_long), ("biHeight", ctypes.c_long),
                ("biPlanes", ctypes.c_ushort), ("biBitCount", ctypes.c_ushort), ("biCompression", ctypes.c_uint32),
                ("biSizeImage", ctypes.c_uint32), ("biXPelsPerMeter", ctypes.c_long), ("biYPelsPerMeter", ctypes.c_long),
                ("biClrUsed", ctypes.c_uint32), ("biClrImportant", ctypes.c_uint32)]


def _hbitmap_with_alpha(hbm):
    """QImage.fromHBITMAP drops transparency (black corners), so read the 32-bit pixels ourselves."""
    gdi32 = ctypes.windll.gdi32
    bm = _BITMAP()
    if not gdi32.GetObjectW(ctypes.c_void_p(hbm), ctypes.sizeof(bm), ctypes.byref(bm)):
        return None
    w, h = bm.bmWidth, abs(bm.bmHeight)
    bih = _BITMAPINFOHEADER(biSize=ctypes.sizeof(_BITMAPINFOHEADER), biWidth=w, biHeight=-h,   # top-down rows
                            biPlanes=1, biBitCount=32, biCompression=0)
    buf = (ctypes.c_ubyte * (w * h * 4))()
    hdc = user32.GetDC(None)
    try:
        rows = gdi32.GetDIBits(ctypes.c_void_p(hdc), ctypes.c_void_p(hbm), 0, h, buf, ctypes.byref(bih), 0)
    finally:
        user32.ReleaseDC(None, hdc)
    if rows != h:
        return None
    return QImage(bytes(buf), w, h, w * 4, QImage.Format_ARGB32_Premultiplied).copy()


def real_path(p):
    """'{7C5A40EF-…}\\Steam\\Steam.exe' (known-folder form used by Start) -> 'C:\\Program Files (x86)\\Steam\\Steam.exe'."""
    if p.startswith("{") and "}" in p:
        from comtypes import GUID
        guid, rest = p[:p.index("}") + 1], p[p.index("}") + 1:]
        out = ctypes.c_wchar_p()
        shell32 = ctypes.windll.shell32
        if shell32.SHGetKnownFolderPath(ctypes.byref(GUID(guid)), 0, None, ctypes.byref(out)) == 0:
            base = out.value
            ctypes.windll.ole32.CoTaskMemFree(out)
            return base + rest
    return p


_apps_cache = None


def installed_apps(refresh=False):
    """[(name, launch target)] for everything in Start → All apps (desktop and Store apps)."""
    global _apps_cache
    if _apps_cache is None or refresh:
        import comtypes.client
        try:
            shell = comtypes.client.CreateObject("Shell.Application", dynamic=True)
            items = shell.NameSpace("shell:AppsFolder").Items()
            apps = []
            for i in range(items.Count):
                it = items.Item(i)
                path = it.Path or ""
                if it.Name and path and not path.startswith("http"):
                    apps.append((it.Name, "shell:AppsFolder\\" + path))
            _apps_cache = apps
        except Exception:
            _apps_cache = []
    return _apps_cache


def find_app(name):
    """Best launch target for an app called `name` (exact match first, then 'starts with')."""
    n = name.casefold()
    apps = installed_apps()
    for app_name, target in apps:
        if app_name.casefold() == n:
            return target
    for app_name, target in apps:
        if app_name.casefold().startswith(n) or n.startswith(app_name.casefold()):
            return target
    return None


def best_icon(path, size=256, retries=4):
    """Best-looking icon for a file, folder or shortcut, or None to let the caller fall back."""
    try:
        if path.lower().startswith("shell:appsfolder"):
            # Explorer's own rendering is exactly what you see in the Start menu
            pm = None
            for attempt in range(retries):
                try:
                    pm = shell_image(path, size)
                    break
                except Exception:    # Explorer sometimes says "not ready yet" for icons it's still loading
                    if attempt + 1 < retries:
                        time.sleep(0.12 * (attempt + 1))
            if pm is None:
                inner = real_path(path.split("\\", 1)[1] if "\\" in path else "")
                if inner.lower().endswith(".exe"):
                    pm = extract(inner, 0, size)
            return pm
        if path.lower().endswith(".lnk"):
            target, icon, idx = resolve_shortcut(path)
            pm = extract(icon, idx, size) if icon else None
            if pm is None and target and os.path.isfile(target):
                pm = extract(target, 0, size)
            return pm or shell_image(path, size)
        if path.lower().endswith((".exe", ".dll", ".ico")):
            return extract(path, 0, size)
    except Exception:
        return None
    return None
