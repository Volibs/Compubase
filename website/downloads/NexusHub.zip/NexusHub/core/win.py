"""Thin ctypes wrappers around the Win32 calls NexusHub uses."""
import ctypes
import os
from ctypes import wintypes

import psutil

user32 = ctypes.WinDLL("user32", use_last_error=True)
dwmapi = ctypes.WinDLL("dwmapi")
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

HWND = wintypes.HWND
LONG_PTR = ctypes.c_ssize_t
WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, HWND, wintypes.LPARAM)

user32.GetForegroundWindow.restype = HWND
user32.GetShellWindow.restype = HWND
user32.GetDesktopWindow.restype = HWND
user32.FindWindowW.restype = HWND
user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
user32.FindWindowExW.restype = HWND
user32.FindWindowExW.argtypes = [HWND, HWND, wintypes.LPCWSTR, wintypes.LPCWSTR]
user32.EnumWindows.argtypes = [WNDENUMPROC, wintypes.LPARAM]
user32.EnumChildWindows.argtypes = [HWND, WNDENUMPROC, wintypes.LPARAM]
user32.GetWindowTextW.argtypes = [HWND, wintypes.LPWSTR, ctypes.c_int]
user32.GetWindowTextLengthW.argtypes = [HWND]
user32.GetClassNameW.argtypes = [HWND, wintypes.LPWSTR, ctypes.c_int]
user32.GetWindowThreadProcessId.argtypes = [HWND, ctypes.POINTER(wintypes.DWORD)]
user32.IsWindowVisible.argtypes = [HWND]
user32.IsWindow.argtypes = [HWND]
user32.IsIconic.argtypes = [HWND]
user32.GetWindowRect.argtypes = [HWND, ctypes.POINTER(wintypes.RECT)]
user32.SetWindowPos.argtypes = [HWND, HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT]
user32.MoveWindow.argtypes = [HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.BOOL]
user32.SetParent.argtypes = [HWND, HWND]
user32.SetParent.restype = HWND
user32.GetParent.argtypes = [HWND]
user32.GetParent.restype = HWND
user32.GetWindowLongPtrW.argtypes = [HWND, ctypes.c_int]
user32.GetWindowLongPtrW.restype = LONG_PTR
user32.SetWindowLongPtrW.argtypes = [HWND, ctypes.c_int, LONG_PTR]
user32.SetWindowLongPtrW.restype = LONG_PTR
user32.SetLayeredWindowAttributes.argtypes = [HWND, wintypes.COLORREF, wintypes.BYTE, wintypes.DWORD]
user32.GetLayeredWindowAttributes.argtypes = [HWND, ctypes.POINTER(wintypes.COLORREF), ctypes.POINTER(wintypes.BYTE), ctypes.POINTER(wintypes.DWORD)]
user32.SendMessageW.argtypes = [HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.SendMessageW.restype = LONG_PTR
user32.PostMessageW.argtypes = [HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.SendMessageTimeoutW.argtypes = [HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM, wintypes.UINT, wintypes.UINT, ctypes.POINTER(ctypes.c_size_t)]
user32.SetForegroundWindow.argtypes = [HWND]
user32.ShowWindow.argtypes = [HWND, ctypes.c_int]
user32.MonitorFromWindow.argtypes = [HWND, wintypes.DWORD]
user32.MonitorFromWindow.restype = wintypes.HMONITOR
user32.keybd_event.argtypes = [wintypes.BYTE, wintypes.BYTE, wintypes.DWORD, ctypes.c_size_t]
dwmapi.DwmSetWindowAttribute.argtypes = [HWND, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD]


class MONITORINFO(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT),
                ("rcWork", wintypes.RECT), ("dwFlags", wintypes.DWORD)]


user32.GetMonitorInfoW.argtypes = [wintypes.HMONITOR, ctypes.POINTER(MONITORINFO)]

GWL_STYLE, GWL_EXSTYLE = -16, -20
WS_EX_LAYERED, WS_EX_TOOLWINDOW, WS_EX_TOPMOST = 0x80000, 0x80, 0x8
WS_CHILD, WS_POPUP = 0x40000000, 0x80000000
HWND_TOPMOST, HWND_NOTOPMOST = HWND(-1), HWND(-2)
SWP_NOSIZE, SWP_NOMOVE, SWP_NOACTIVATE, SWP_NOZORDER, SWP_SHOWWINDOW, SWP_FRAMECHANGED = 0x1, 0x2, 0x10, 0x4, 0x40, 0x20
LWA_ALPHA = 0x2
WM_APPCOMMAND, WM_SYSCOMMAND, WM_CLOSE = 0x0319, 0x0112, 0x0010
KEYEVENTF_KEYUP = 0x2


# ---------------------------------------------------------------- windows
def rect(hwnd):
    r = wintypes.RECT()
    user32.GetWindowRect(hwnd, ctypes.byref(r))
    return r.left, r.top, r.right, r.bottom


def title(hwnd):
    n = user32.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.GetWindowTextW(hwnd, buf, n + 1)
    return buf.value


def class_name(hwnd):
    buf = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(hwnd, buf, 256)
    return buf.value


def pid_of(hwnd):
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return pid.value


def process_name(hwnd):
    try:
        return psutil.Process(pid_of(hwnd)).name()
    except (psutil.Error, ValueError):
        return ""


def foreground():
    return user32.GetForegroundWindow()


def enum_windows(visible_only=True):
    out = []

    def cb(hwnd, _):
        if (not visible_only or user32.IsWindowVisible(hwnd)) and user32.GetWindowTextLengthW(hwnd):
            out.append(hwnd)
        return True

    user32.EnumWindows(WNDENUMPROC(cb), 0)
    return out


user32.GetWindow.restype = HWND
user32.GetWindow.argtypes = [HWND, wintypes.UINT]
dwmapi.DwmGetWindowAttribute.argtypes = [HWND, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD]
WS_EX_APPWINDOW, WS_EX_NOACTIVATE = 0x40000, 0x08000000
_SKIP_CLASSES = {"Progman", "WorkerW", "Shell_TrayWnd", "Shell_SecondaryTrayWnd", "Windows.UI.Core.CoreWindow",
                 "XamlExplorerHostIslandWindow"}


def is_cloaked(hwnd):
    """Store apps that are suspended/on another virtual desktop are 'cloaked': visible to Windows, not to you."""
    val = ctypes.c_int(0)
    dwmapi.DwmGetWindowAttribute(hwnd, 14, ctypes.byref(val), ctypes.sizeof(val))   # DWMWA_CLOAKED
    return val.value != 0


def app_windows():
    """Windows that belong in a taskbar, using the same rules as Alt+Tab
    (minimised windows included, hidden/cloaked/tool windows left out)."""
    own = os.getpid()
    result = []
    for hwnd in enum_windows():
        if pid_of(hwnd) == own or class_name(hwnd) in _SKIP_CLASSES or is_cloaked(hwnd):
            continue
        ex = user32.GetWindowLongPtrW(hwnd, GWL_EXSTYLE)
        app = bool(ex & WS_EX_APPWINDOW)
        if not app and (ex & WS_EX_TOOLWINDOW or ex & WS_EX_NOACTIVATE):
            continue
        if not app and user32.GetWindow(hwnd, 4):        # GW_OWNER: dialogs belong to their main window
            continue
        if not user32.IsIconic(hwnd):                     # minimised windows are tiny, so only size-check open ones
            l, t, r, b = rect(hwnd)
            if r - l < 50 or b - t < 50:
                continue
        result.append(hwnd)
    return result


def is_topmost(hwnd):
    return bool(user32.GetWindowLongPtrW(hwnd, GWL_EXSTYLE) & WS_EX_TOPMOST)


def set_topmost(hwnd, on):
    user32.SetWindowPos(hwnd, HWND_TOPMOST if on else HWND_NOTOPMOST, 0, 0, 0, 0,
                        SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE)


def get_opacity(hwnd):
    if not user32.GetWindowLongPtrW(hwnd, GWL_EXSTYLE) & WS_EX_LAYERED:
        return 255
    key, alpha, flags = wintypes.COLORREF(), wintypes.BYTE(), wintypes.DWORD()
    if user32.GetLayeredWindowAttributes(hwnd, ctypes.byref(key), ctypes.byref(alpha), ctypes.byref(flags)) and flags.value & LWA_ALPHA:
        return alpha.value
    return 255


def set_opacity(hwnd, alpha):
    alpha = max(20, min(255, int(alpha)))
    ex = user32.GetWindowLongPtrW(hwnd, GWL_EXSTYLE)
    if not ex & WS_EX_LAYERED:
        user32.SetWindowLongPtrW(hwnd, GWL_EXSTYLE, ex | WS_EX_LAYERED)
    user32.SetLayeredWindowAttributes(hwnd, 0, alpha, LWA_ALPHA)


def monitor_rect(hwnd, work=False):
    mon = user32.MonitorFromWindow(hwnd, 2)  # MONITOR_DEFAULTTONEAREST
    mi = MONITORINFO()
    mi.cbSize = ctypes.sizeof(MONITORINFO)
    user32.GetMonitorInfoW(mon, ctypes.byref(mi))
    r = mi.rcWork if work else mi.rcMonitor
    return r.left, r.top, r.right, r.bottom


def center_window(hwnd):
    l, t, r, b = rect(hwnd)
    ml, mt, mr, mb = monitor_rect(hwnd, work=True)
    w, h = r - l, b - t
    user32.SetWindowPos(hwnd, None, ml + (mr - ml - w) // 2, mt + (mb - mt - h) // 2, 0, 0,
                        SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE)


def is_desktop_or_shell(hwnd):
    return class_name(hwnd) in ("Progman", "WorkerW", "Shell_TrayWnd", "Shell_SecondaryTrayWnd", "")


def foreground_is_fullscreen():
    hwnd = foreground()
    if not hwnd or is_desktop_or_shell(hwnd):
        return False
    return rect(hwnd) == monitor_rect(hwnd) or (
        # borderless windows sometimes overshoot the monitor by a few pixels
        all(abs(a - b) <= 8 for a, b in zip(rect(hwnd), monitor_rect(hwnd)))
    )


def dark_title_bar(hwnd):
    val = ctypes.c_int(1)
    dwmapi.DwmSetWindowAttribute(int(hwnd), 20, ctypes.byref(val), ctypes.sizeof(val))


# ---------------------------------------------------------------- input
def press_key(vk, up_too=True):
    user32.keybd_event(vk, 0, 0, 0)
    if up_too:
        user32.keybd_event(vk, 0, KEYEVENTF_KEYUP, 0)


def send_ctrl_v():
    user32.keybd_event(0x11, 0, 0, 0)
    press_key(0x56)
    user32.keybd_event(0x11, 0, KEYEVENTF_KEYUP, 0)


def release_modifiers():
    """Let go of modifiers the user may still be holding from a hotkey."""
    for vk in (0x10, 0x11, 0x12, 0x5B):
        if user32.GetAsyncKeyState(vk) & 0x8000:
            user32.keybd_event(vk, 0, KEYEVENTF_KEYUP, 0)


def focus(hwnd):
    if user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, 9)  # SW_RESTORE
    user32.SetForegroundWindow(hwnd)


# ---------------------------------------------------------------- system
def monitor_off():
    user32.PostMessageW(HWND(0xFFFF), WM_SYSCOMMAND, 0xF170, 2)  # SC_MONITORPOWER, off


def lock_pc():
    user32.LockWorkStation()


class _ExecState:
    ES_CONTINUOUS, ES_SYSTEM_REQUIRED, ES_DISPLAY_REQUIRED = 0x80000000, 0x1, 0x2


def keep_awake(on, display=False):
    flags = _ExecState.ES_CONTINUOUS
    if on:
        flags |= _ExecState.ES_SYSTEM_REQUIRED
        if display:
            flags |= _ExecState.ES_DISPLAY_REQUIRED
    kernel32.SetThreadExecutionState(ctypes.c_uint(flags))
