"""Accounts & profiles.

* Profiles: complete snapshots of your NexusHub setup. The active one IS the live config file.
* Accounts: "local" (no sign-in) or a Google account. Signing in with Google backs your profiles up to
  your own Google Drive (the hidden app-data folder only NexusHub can see) and syncs them between PCs.

Files (all in %APPDATA%\\NexusHub):
  session.json                         which account + profile is active
  profiles\\<owner>\\index.json          profile names for that account
  profiles\\<owner>\\<id>.json           each profile's settings
  accounts\\accounts.json                signed-in Google accounts (name, email, picture)
  accounts\\<sub>.token                  Google refresh token, encrypted with Windows DPAPI
  google_client.json                   your Google OAuth client (from Google Cloud Console)
"""
import base64
import ctypes
import hashlib
import http.server
import json
import os
import re
import secrets
import shutil
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from ctypes import wintypes

from .config import APP_DIR

PROFILES = os.path.join(APP_DIR, "profiles")
ACCOUNTS = os.path.join(APP_DIR, "accounts")
SESSION = os.path.join(APP_DIR, "session.json")
CLIENT = os.path.join(APP_DIR, "google_client.json")
LEGACY = os.path.join(APP_DIR, "config.json")
LOCAL = "local"
SCOPES = "openid email profile https://www.googleapis.com/auth/drive.appdata"
# never uploaded to the cloud: logins and clipboard history stay on this PC
PRIVATE_KEYS = [("plugin.spotify", "api"), ("plugin.clipboard", "items"), ("plugin.browser", None)]


# ====================================================================== small helpers
def _read(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def _write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, path)


def slug(name):
    s = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:32]
    return s or "profile"


# ====================================================================== session & profiles
def session():
    s = _read(SESSION, {})
    return {"owner": s.get("owner", LOCAL), "profile": s.get("profile", "default")}


def set_session(owner, profile):
    _write(SESSION, {"owner": owner, "profile": profile})


def index(owner):
    idx = _read(os.path.join(PROFILES, owner, "index.json"), None)
    if not idx or not idx.get("profiles"):
        idx = {"profiles": [{"id": "default", "name": "Default"}]}
    return idx


def save_index(owner, idx):
    _write(os.path.join(PROFILES, owner, "index.json"), idx)


def profile_path(owner, pid):
    return os.path.join(PROFILES, owner, pid + ".json")


def active_profile_path():
    """Path of the live config. Migrates the old single config.json into the Default profile once."""
    s = session()
    path = profile_path(s["owner"], s["profile"])
    if not os.path.exists(path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if s["owner"] == LOCAL and s["profile"] == "default" and os.path.exists(LEGACY):
            shutil.copy2(LEGACY, path)                 # first run with profiles: keep everything you had
        else:
            _write(path, {})
        idx = index(s["owner"])
        if not any(p["id"] == s["profile"] for p in idx["profiles"]):
            idx["profiles"].append({"id": s["profile"], "name": s["profile"].replace("-", " ").title()})
        save_index(s["owner"], idx)
    return path


def list_profiles(owner=None):
    return index(owner or session()["owner"])["profiles"]


def create_profile(name, copy_from_current=True, owner=None):
    owner = owner or session()["owner"]
    idx = index(owner)
    pid, n = slug(name), 2
    while any(p["id"] == pid for p in idx["profiles"]):
        pid, n = f"{slug(name)}-{n}", n + 1
    data = _read(active_profile_path(), {}) if copy_from_current else {}
    _write(profile_path(owner, pid), data)
    idx["profiles"].append({"id": pid, "name": name.strip()[:30] or pid})
    save_index(owner, idx)
    return pid


def rename_profile(pid, name, owner=None):
    owner = owner or session()["owner"]
    idx = index(owner)
    for p in idx["profiles"]:
        if p["id"] == pid:
            p["name"] = name.strip()[:30] or p["name"]
    save_index(owner, idx)


def delete_profile(pid, owner=None):
    owner = owner or session()["owner"]
    idx = index(owner)
    idx["profiles"] = [p for p in idx["profiles"] if p["id"] != pid]
    idx.setdefault("deleted", []).append(pid)            # so the cloud copy is removed on the next sync
    save_index(owner, idx)
    try:
        os.remove(profile_path(owner, pid))
    except OSError:
        pass


# ====================================================================== Windows DPAPI (encrypt tokens)
class _BLOB(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]


def _blob(data):
    buf = ctypes.create_string_buffer(data, len(data))
    return _BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), buf


def protect(data: bytes) -> bytes:
    inp, _keep = _blob(data)
    out = _BLOB()
    if not ctypes.windll.crypt32.CryptProtectData(ctypes.byref(inp), "NexusHub", None, None, None, 0, ctypes.byref(out)):
        raise OSError("DPAPI protect failed")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(out.pbData)


def unprotect(data: bytes) -> bytes:
    inp, _keep = _blob(data)
    out = _BLOB()
    if not ctypes.windll.crypt32.CryptUnprotectData(ctypes.byref(inp), None, None, None, None, 0, ctypes.byref(out)):
        raise OSError("DPAPI unprotect failed")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(out.pbData)


# ====================================================================== Google
class GoogleError(Exception):
    pass


# The app's built-in Google sign-in key. It ships inside the NexusHub folder, so people who install
# NexusHub can sign in straight away without making their own. (Google treats desktop-app secrets as
# non-confidential: every desktop app ships one.)
BUNDLED_CLIENT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "google_client.json")


def client():
    """Your own key (if you set one on this PC) wins; otherwise the app's built-in one."""
    own = _read(CLIENT, {})
    if own.get("client_id") and own.get("client_secret"):
        return own
    built_in = _read(BUNDLED_CLIENT, {})
    if built_in.get("client_id") and built_in.get("client_secret"):
        return built_in
    return own or built_in


def has_builtin_client():
    b = _read(BUNDLED_CLIENT, {})
    return bool(b.get("client_id") and b.get("client_secret"))


def set_client(client_id, client_secret, bundle=True):
    data = {"client_id": client_id.strip(), "client_secret": client_secret.strip()}
    _write(CLIENT, data)
    if bundle:
        _write(BUNDLED_CLIENT, data)      # becomes the app's built-in sign-in for everyone you share it with


def accounts():
    return _read(os.path.join(ACCOUNTS, "accounts.json"), {})


def account(sub):
    return accounts().get(sub)


def _save_account(sub, info):
    all_ = accounts()
    all_[sub] = info
    _write(os.path.join(ACCOUNTS, "accounts.json"), all_)


def avatar_path(sub):
    return os.path.join(ACCOUNTS, f"{sub}.jpg")


def _post(url, fields):
    req = urllib.request.Request(url, data=urllib.parse.urlencode(fields).encode(),
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            detail = json.loads(e.read()).get("error_description", "")
        except ValueError:
            detail = ""
        raise GoogleError(f"Google said no ({e.code}). {detail}".strip())


def sign_in(timeout=240):
    """Opens Google's sign-in page in your normal browser. Returns the account info dict."""
    c = client()
    if not c.get("client_id"):
        raise GoogleError("Set up your Google client first")
    verifier = secrets.token_urlsafe(64)[:100]
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    state = secrets.token_urlsafe(16)
    result = {}

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            ok = q.get("state", [""])[0] == state and "code" in q
            if ok:
                result["code"] = q["code"][0]
            elif "error" in q or "state" in q:
                result["error"] = q.get("error", ["cancelled"])[0]
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            msg = "Signed in to NexusHub ✔ You can close this tab." if ok else "Sign-in didn't finish. You can close this tab."
            self.wfile.write(f"<html><body style='font-family:Segoe UI;background:#0d0f14;color:#e8ebf2;display:grid;"
                             f"place-items:center;height:95vh'><h2>{msg}</h2></body></html>".encode())

        def log_message(self, *a):
            pass

    server = http.server.HTTPServer(("127.0.0.1", 0), Handler)     # any free port (allowed for Google desktop apps)
    server.timeout = 1
    redirect = f"http://127.0.0.1:{server.server_port}/"
    webbrowser.open("https://accounts.google.com/o/oauth2/v2/auth?" + urllib.parse.urlencode({
        "client_id": c["client_id"], "redirect_uri": redirect, "response_type": "code", "scope": SCOPES,
        "code_challenge": challenge, "code_challenge_method": "S256", "state": state,
        "access_type": "offline", "prompt": "consent select_account"}))
    end = time.time() + timeout
    try:
        while not result and time.time() < end:
            server.handle_request()
    finally:
        server.server_close()
    if "code" not in result:
        err = result.get("error", "timed out")
        if err == "access_denied":
            raise GoogleError("Google blocked the sign-in. Either you pressed Cancel, or the NexusHub Google project "
                              "is still in Testing mode. In Google Cloud open Google Auth Platform → Audience and press "
                              "“Publish app”, then try again.")
        raise GoogleError(f"Sign-in didn't finish ({err})")
    tok = _post("https://oauth2.googleapis.com/token", {
        "code": result["code"], "client_id": c["client_id"], "client_secret": c.get("client_secret", ""),
        "redirect_uri": redirect, "grant_type": "authorization_code", "code_verifier": verifier})
    if not tok.get("refresh_token"):
        raise GoogleError("Google didn't return a long-term login. Try again")
    req = urllib.request.Request("https://openidconnect.googleapis.com/v1/userinfo",
                                 headers={"Authorization": "Bearer " + tok["access_token"]})
    with urllib.request.urlopen(req, timeout=15) as r:
        me = json.loads(r.read())
    sub = me["sub"]
    os.makedirs(ACCOUNTS, exist_ok=True)
    with open(os.path.join(ACCOUNTS, f"{sub}.token"), "wb") as f:
        f.write(protect(json.dumps({"refresh_token": tok["refresh_token"]}).encode()))
    info = {"sub": sub, "email": me.get("email", ""), "name": me.get("name") or me.get("email", ""),
            "picture": me.get("picture", "")}
    _save_account(sub, info)
    if info["picture"]:
        try:
            with urllib.request.urlopen(info["picture"], timeout=10) as r, open(avatar_path(sub), "wb") as f:
                f.write(r.read())
        except OSError:
            pass
    _TOKENS[sub] = (tok["access_token"], time.time() + tok.get("expires_in", 3600) - 60)
    return info


def sign_out(sub):
    try:
        os.remove(os.path.join(ACCOUNTS, f"{sub}.token"))
    except OSError:
        pass
    _TOKENS.pop(sub, None)


def signed_in(sub):
    return os.path.exists(os.path.join(ACCOUNTS, f"{sub}.token"))


_TOKENS = {}
_LOCK = threading.Lock()


def _access_token(sub):
    with _LOCK:
        tok, exp = _TOKENS.get(sub, (None, 0))
        if tok and time.time() < exp:
            return tok
        try:
            with open(os.path.join(ACCOUNTS, f"{sub}.token"), "rb") as f:
                refresh = json.loads(unprotect(f.read()))["refresh_token"]
        except (OSError, ValueError, KeyError):
            raise GoogleError("Please sign in with Google again")
        c = client()
        t = _post("https://oauth2.googleapis.com/token", {
            "client_id": c.get("client_id", ""), "client_secret": c.get("client_secret", ""),
            "refresh_token": refresh, "grant_type": "refresh_token"})
        _TOKENS[sub] = (t["access_token"], time.time() + t.get("expires_in", 3600) - 60)
        return t["access_token"]


def _drive(sub, method, url, body=None, content_type="application/json"):
    req = urllib.request.Request(url, data=body, method=method,
                                 headers={"Authorization": "Bearer " + _access_token(sub), "Content-Type": content_type})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            raw = r.read()
            return json.loads(raw) if raw and r.headers.get_content_type() == "application/json" else raw
    except urllib.error.HTTPError as e:
        if e.code == 403:
            raise GoogleError("Google Drive refused. Is the Drive API enabled in your Google Cloud project?")
        raise GoogleError(f"Google Drive error {e.code}")


def _cloud_files(sub):
    data = _drive(sub, "GET", "https://www.googleapis.com/drive/v3/files?" + urllib.parse.urlencode(
        {"spaces": "appDataFolder", "fields": "files(id,name,modifiedTime)", "pageSize": 200}))
    return {f["name"]: f for f in data.get("files", [])}


def _upload(sub, name, data, file_id=None):
    payload = json.dumps(data).encode()
    if file_id:
        return _drive(sub, "PATCH", f"https://www.googleapis.com/upload/drive/v3/files/{file_id}?uploadType=media&fields=id,modifiedTime",
                      payload)
    boundary = "nexushub" + secrets.token_hex(8)
    meta = json.dumps({"name": name, "parents": ["appDataFolder"]})
    body = (f"--{boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n{meta}\r\n"
            f"--{boundary}\r\nContent-Type: application/json\r\n\r\n").encode() + payload + f"\r\n--{boundary}--".encode()
    return _drive(sub, "POST", "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,modifiedTime",
                  body, f"multipart/related; boundary={boundary}")


def _download(sub, file_id):
    raw = _drive(sub, "GET", f"https://www.googleapis.com/drive/v3/files/{file_id}?alt=media")
    return raw if isinstance(raw, dict) else json.loads(raw)


def _strip_private(data):
    data = json.loads(json.dumps(data))
    for section, key in PRIVATE_KEYS:
        if key is None:
            data.pop(section, None)
        elif isinstance(data.get(section), dict):
            data[section].pop(key, None)
    return data


def _keep_private(new, old):
    for section, key in PRIVATE_KEYS:
        if key is None:
            if section in old:
                new[section] = old[section]
        elif isinstance(old.get(section), dict) and key in old[section]:
            new.setdefault(section, {})[key] = old[section][key]
    return new


def _parse_time(s):
    import datetime
    return datetime.datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()


def sync(sub):
    """Two-way sync of this account's profiles with Google Drive. Newest copy of each profile wins.
    Returns a dict: {'uploaded': n, 'downloaded': [ids], 'active_changed': bool}."""
    state_path = os.path.join(ACCOUNTS, f"{sub}.sync.json")
    state = _read(state_path, {})
    cloud = _cloud_files(sub)
    idx = index(sub)
    up, down = 0, []
    # profiles removed on this PC: remove them from the cloud too
    for pid in idx.pop("deleted", []):
        f = cloud.pop(f"profile-{pid}.json", None)
        if f:
            _drive(sub, "DELETE", f"https://www.googleapis.com/drive/v3/files/{f['id']}")
        state.pop(pid, None)
    local_ids = {p["id"] for p in idx["profiles"]}
    # merge the cloud's list of profile names (profiles created on another PC)
    cidx_file = cloud.get("index.json")
    if cidx_file:
        try:
            cidx = _download(sub, cidx_file["id"])
            for p in cidx.get("profiles", []):
                if p["id"] not in local_ids and f"profile-{p['id']}.json" in cloud:
                    idx["profiles"].append(p)
                    local_ids.add(p["id"])
        except (GoogleError, ValueError):
            pass
    for p in idx["profiles"]:
        pid = p["id"]
        path = profile_path(sub, pid)
        f = cloud.get(f"profile-{pid}.json")
        st = state.get(pid, {})
        local_m = os.path.getmtime(path) if os.path.exists(path) else 0
        if f is None:
            if local_m:
                r = _upload(sub, f"profile-{pid}.json", _strip_private(_read(path, {})))
                state[pid] = {"cloud": r["modifiedTime"], "local": os.path.getmtime(path)}
                up += 1
            continue
        cloud_changed = f["modifiedTime"] != st.get("cloud")
        local_changed = local_m > st.get("local", 0) + 1
        if not local_m or (cloud_changed and (not local_changed or _parse_time(f["modifiedTime"]) > local_m)):
            data = _keep_private(_download(sub, f["id"]), _read(path, {}))
            _write(path, data)
            state[pid] = {"cloud": f["modifiedTime"], "local": os.path.getmtime(path)}
            down.append(pid)
        elif local_changed:
            r = _upload(sub, f["name"], _strip_private(_read(path, {})), f["id"])
            state[pid] = {"cloud": r["modifiedTime"], "local": local_m}
            up += 1
    save_index(sub, idx)
    _upload(sub, "index.json", {"profiles": idx["profiles"]}, cidx_file["id"] if cidx_file else None)
    state["_last"] = time.time()
    _write(state_path, state)
    s = session()
    return {"uploaded": up, "downloaded": down, "active_changed": s["owner"] == sub and s["profile"] in down}


def cloud_has_profiles(sub):
    """True if this Google account already has NexusHub profiles saved (e.g. from another PC)."""
    return any(name.startswith("profile-") for name in _cloud_files(sub))


def adopt_local_profiles(sub):
    """First sign-in on this PC: give the Google account copies of your current local profiles
    (only ones it doesn't already have)."""
    local = index(LOCAL)
    idx = index(sub) if os.path.exists(os.path.join(PROFILES, sub, "index.json")) else {"profiles": []}
    have = {p["id"] for p in idx["profiles"]}
    for p in local["profiles"]:
        src = profile_path(LOCAL, p["id"])
        if p["id"] not in have and os.path.exists(src):
            os.makedirs(os.path.join(PROFILES, sub), exist_ok=True)
            shutil.copy2(src, profile_path(sub, p["id"]))
            idx["profiles"].append(dict(p))
    if not idx["profiles"]:
        idx["profiles"] = [{"id": "default", "name": "Default"}]
    save_index(sub, idx)
