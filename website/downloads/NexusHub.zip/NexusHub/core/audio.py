"""Volume helpers on top of pycaw (Windows Core Audio)."""
try:
    import comtypes
    from comtypes import CLSCTX_ALL
    from pycaw.constants import CLSID_MMDeviceEnumerator
    from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume, IMMDeviceEnumerator
    AVAILABLE = True
except Exception:  # pycaw missing or broken: audio features just hide themselves
    AVAILABLE = False


def _default_endpoint_volume(flow):
    """IAudioEndpointVolume of the default output (flow=0) or input (flow=1) device.

    Uses QueryInterface rather than ctypes.cast: cast makes a second COM pointer
    without AddRef, so both get Released later and the process crashes.
    """
    enum = comtypes.CoCreateInstance(CLSID_MMDeviceEnumerator, IMMDeviceEnumerator, comtypes.CLSCTX_INPROC_SERVER)
    device = enum.GetDefaultAudioEndpoint(flow, 0)   # eConsole role
    return device.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None).QueryInterface(IAudioEndpointVolume)


def peak_meter():
    """IAudioMeterInformation for the default output: GetPeakValue() -> 0..1 loudness right now.
    Reads the level Windows already shows in the volume mixer; no audio is recorded."""
    from pycaw.pycaw import IAudioMeterInformation
    enum = comtypes.CoCreateInstance(CLSID_MMDeviceEnumerator, IMMDeviceEnumerator, comtypes.CLSCTX_INPROC_SERVER)
    device = enum.GetDefaultAudioEndpoint(0, 0)
    return device.Activate(IAudioMeterInformation._iid_, CLSCTX_ALL, None).QueryInterface(IAudioMeterInformation)


def speakers():
    return _default_endpoint_volume(0)


def microphone():
    return _default_endpoint_volume(1)


def sessions():
    """[(display name, process name, ISimpleAudioVolume)] for apps making sound."""
    out = []
    for s in AudioUtilities.GetAllSessions():
        if not s.Process:
            continue
        try:
            name = s.Process.name()
        except Exception:
            continue
        out.append((name.rsplit(".", 1)[0].capitalize(), name.lower(), s.SimpleAudioVolume))
    return out


def _policy_config():
    """IPolicyConfig: the (undocumented, stable since Vista) interface Windows' own
    sound settings use to change the default device."""
    from ctypes import c_int, c_wchar_p
    from comtypes import COMMETHOD, GUID, HRESULT, IUnknown

    class IPolicyConfig(IUnknown):
        _iid_ = GUID("{f8679f50-850a-41cf-9c72-430f290290c8}")
        # only SetDefaultEndpoint is called; the rest just keep the vtable slots in order
        _methods_ = [COMMETHOD([], HRESULT, name) for name in (
            "GetMixFormat", "GetDeviceFormat", "ResetDeviceFormat", "SetDeviceFormat", "GetProcessingPeriod",
            "SetProcessingPeriod", "GetShareMode", "SetShareMode", "GetPropertyValue", "SetPropertyValue")] + [
            COMMETHOD([], HRESULT, "SetDefaultEndpoint", (["in"], c_wchar_p, "device_id"), (["in"], c_int, "role")),
        ]

    return comtypes.CoCreateInstance(comtypes.GUID("{870af99c-171d-4f9e-af0d-e63df40c2bc9}"), IPolicyConfig,
                                     comtypes.CLSCTX_ALL)


def outputs():
    """[(device id, friendly name)] for plugged-in playback devices."""
    out = []
    for d in AudioUtilities.GetAllDevices():
        state = str(getattr(d, "state", ""))
        if d.id and d.id.startswith("{0.0.0") and d.FriendlyName and state.endswith("Active"):
            out.append((d.id, d.FriendlyName))
    return out


def default_output_id():
    enum = comtypes.CoCreateInstance(CLSID_MMDeviceEnumerator, IMMDeviceEnumerator, comtypes.CLSCTX_INPROC_SERVER)
    return enum.GetDefaultAudioEndpoint(0, 0).GetId()


def set_default_output(device_id):
    pc = _policy_config()
    for role in (0, 1, 2):   # console, multimedia, communications
        pc.SetDefaultEndpoint(device_id, role)


def short_name(friendly):
    """'Speakers (Realtek(R) Audio)' -> 'Speakers', 'Headphones (soundcore P30i)' -> 'soundcore P30i'."""
    head, _, rest = friendly.partition(" (")
    brand = rest.rstrip(")")
    if head.lower() in ("headphones", "headset") and "high definition" not in brand.lower():
        return brand
    return head


def app_volume(process_name):
    """The ISimpleAudioVolume for a process (e.g. 'spotify.exe') or None."""
    if not AVAILABLE:
        return None
    for _, proc, vol in sessions():
        if proc == process_name.lower():
            return vol
    return None
