"""Desktop pop-ups for Quick Launch: a magnifying Dock and a radial launcher wheel."""
import math

from PySide6.QtCore import QEasingCurve, QPointF, QPropertyAnimation, QRectF, Qt, QTimer, Property, QEvent
from PySide6.QtGui import QColor, QCursor, QFont, QGuiApplication, QLinearGradient, QPainter, QPen, QRadialGradient
from PySide6.QtWidgets import QMenu, QWidget

from . import ui, win


def _text_font(px, weight=QFont.DemiBold):
    f = QFont(ui.TEXT_FONT)
    f.setPixelSize(px)
    f.setWeight(weight)
    return f


# ====================================================================== Dock
class Dock(QWidget):
    BASE, MAX, GAP, PAD = 46, 74, 10, 12

    def __init__(self, plugin):
        super().__init__(None, Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint | Qt.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setMouseTracking(True)
        self.setAcceptDrops(True)
        self.plugin = plugin
        self.items = []
        self.mouse_x = None
        self.bounce = {}          # item id -> animation phase 0..1
        self._reveal = 1.0        # 0 = tucked away, 1 = fully shown
        self._away_since = None
        self._anim = QPropertyAnimation(self, b"reveal", self)
        self._anim.setDuration(220)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._watch = QTimer(self, interval=90, timeout=self._watch_cursor)
        self._bouncer = QTimer(self, interval=16, timeout=self._step_bounce)
        self.reload()

    # --- animated reveal -------------------------------------------------
    def get_reveal(self):
        return self._reveal

    def set_reveal(self, v):
        self._reveal = v
        self._place()
        if v <= 0.01 and self.isVisible():
            self.hide()

    reveal = Property(float, get_reveal, set_reveal)

    def _slide(self, show):
        target = 1.0 if show else 0.0
        if abs(self._reveal - target) < 0.01 and (self.isVisible() == show):
            return
        if show and not self.isVisible():
            self.show()
        self._anim.stop()
        self._anim.setStartValue(self._reveal)
        self._anim.setEndValue(target)
        self._anim.start()

    # --- layout ---------------------------------------------------------
    def reload(self):
        self.items = self.plugin.setting("items", [])
        self._place()
        self.update()

    def top_edge(self):
        return self.plugin.setting("dock_pos", "bottom") == "top"

    def base_width(self):
        n = max(1, len(self.items))
        return n * self.BASE + (n - 1) * self.GAP + self.PAD * 2

    def _place(self):
        screen = QGuiApplication.primaryScreen()
        geo = screen.availableGeometry()
        w = self.base_width() + (self.MAX - self.BASE) * 3 + 40
        h = self.MAX + self.PAD * 2 + 34            # room for magnified icons + the name label
        x = geo.center().x() - w // 2
        hide_offset = int((1 - self._reveal) * (h + 4))
        if self.top_edge():
            y = geo.top() + 6 - hide_offset
        else:
            y = geo.bottom() - h - 6 + hide_offset
        self.setGeometry(x, y, w, h)

    def start(self):
        self._watch.start()
        if self.plugin.setting("dock_autohide", True):
            self._reveal = 0.0
            self._place()
        else:
            self._reveal = 1.0
            self._place()
            self.show()

    def stop(self):
        self._watch.stop()
        self.hide()

    # --- auto-hide --------------------------------------------------------
    def _watch_cursor(self):
        if not self.plugin.setting("dock_autohide", True):
            if not self.isVisible() and not win.foreground_is_fullscreen():
                self._reveal = 1.0
                self._place()
                self.show()
            return
        pos = QCursor.pos()
        geo = QGuiApplication.primaryScreen().geometry()
        pill = self._pill_rect()
        pill_x0 = self.x() + pill.left()
        pill_x1 = self.x() + pill.right()
        at_edge = (pos.y() <= geo.top() + 2) if self.top_edge() else (pos.y() >= geo.bottom() - 2)
        over = self.isVisible() and self.geometry().adjusted(0, -20, 0, 20).contains(pos)
        if at_edge and pill_x0 - 40 <= pos.x() <= pill_x1 + 40 and not win.foreground_is_fullscreen():
            self._away_since = None
            self._slide(True)
        elif over:
            self._away_since = None
        elif self._reveal > 0:
            import time
            self._away_since = self._away_since or time.monotonic()
            if time.monotonic() - self._away_since > 0.5:
                self._slide(False)

    # --- geometry of icons ----------------------------------------------
    def _pill_rect(self):
        bw = self.base_width()
        h = self.BASE + self.PAD * 2
        x = (self.width() - bw) / 2
        y = (self.height() - h - 6) if not self.top_edge() else 6
        return QRectF(x, y, bw, h)

    def _icon_rects(self):
        """Magnify icons near the mouse (Gaussian falloff), keeping the row centred."""
        pill = self._pill_rect()
        centers = [pill.left() + self.PAD + self.BASE / 2 + i * (self.BASE + self.GAP) for i in range(len(self.items))]
        sizes = []
        for cx in centers:
            if self.mouse_x is None:
                sizes.append(self.BASE)
            else:
                d = (self.mouse_x - cx) / (self.BASE * 1.6)
                sizes.append(self.BASE + (self.MAX - self.BASE) * math.exp(-d * d))
        total = sum(sizes) + self.GAP * (len(sizes) - 1)
        x = self.width() / 2 - total / 2
        rects = []
        for it, s in zip(self.items, sizes):
            b = self.bounce.get(it["id"], 0)
            lift = math.sin(b * math.pi * 3) * 14 * (1 - b)
            if self.top_edge():
                y = pill.top() + self.PAD + lift
            else:
                y = pill.bottom() - self.PAD - s - lift
            rects.append(QRectF(x, y, s, s))
            x += s + self.GAP
        return rects

    def _index_at(self, pt):
        for i, r in enumerate(self._icon_rects()):
            if r.adjusted(-self.GAP / 2, -10, self.GAP / 2, 10).contains(pt):
                return i
        return None

    # --- paint ------------------------------------------------------------
    def paintEvent(self, _):
        if not self.items:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        pill = self._pill_rect()
        g = QLinearGradient(pill.topLeft(), pill.bottomLeft())
        g.setColorAt(0, QColor(30, 33, 46, 225))
        g.setColorAt(1, QColor(16, 18, 26, 235))
        p.setBrush(g)
        p.setPen(QPen(QColor(255, 255, 255, 38), 1))
        p.drawRoundedRect(pill, 20, 20)
        rects = self._icon_rects()
        hover = self._index_at(QPointF(self.mouse_x, pill.center().y())) if self.mouse_x is not None else None
        for i, (it, r) in enumerate(zip(self.items, rects)):
            pm = self.plugin.item_pixmap(it, int(self.MAX * 1.5))
            p.drawPixmap(r.toRect(), pm)
            if i == hover:
                # name label
                p.setFont(_text_font(12))
                tw = p.fontMetrics().horizontalAdvance(it["name"]) + 20
                ly = (r.bottom() + 8) if self.top_edge() else (r.top() - 30)
                lab = QRectF(r.center().x() - tw / 2, ly, tw, 24)
                p.setPen(Qt.NoPen)
                p.setBrush(QColor(10, 12, 18, 230))
                p.drawRoundedRect(lab, 8, 8)
                p.setPen(QColor("white"))
                p.drawText(lab, Qt.AlignCenter, it["name"])
        # little running dots under apps we launched recently
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(ui.ACCENT2))
        for it, r in zip(self.items, rects):
            if it["id"] in self.plugin.recent:
                y = (r.bottom() + 4) if self.top_edge() else (pill.bottom() - 5)
                p.drawEllipse(QPointF(r.center().x(), y), 2.2, 2.2)

    # --- mouse -------------------------------------------------------------
    def mouseMoveEvent(self, e):
        self.mouse_x = e.position().x()
        self.update()

    def leaveEvent(self, e):
        self.mouse_x = None
        self.update()

    def mouseReleaseEvent(self, e):
        i = self._index_at(e.position())
        if e.button() == Qt.LeftButton and i is not None:
            it = self.items[i]
            self.bounce[it["id"]] = 0.0
            self._bouncer.start()
            self.plugin.launch(it, quiet=True)
        elif e.button() == Qt.RightButton:
            m = QMenu(self)
            if i is not None:
                it = self.items[i]
                m.addAction(ui.glyph_icon(""), f"Open {it['name']}", lambda: self.plugin.launch(it))
                m.addAction(ui.glyph_icon(""), "Remove from dock", lambda: self.plugin.remove_item(it))
                m.addSeparator()
            m.addAction(ui.glyph_icon(""), "Quick Launch settings", self.plugin.open_settings)
            m.addAction(ui.glyph_icon(""), "Turn off the dock", lambda: self.plugin.set_dock(False))
            m.exec(e.globalPosition().toPoint())

    def _step_bounce(self):
        done = []
        for k in self.bounce:
            self.bounce[k] += 0.035
            if self.bounce[k] >= 1:
                done.append(k)
        for k in done:
            del self.bounce[k]
        if not self.bounce:
            self._bouncer.stop()
        self.update()

    # --- drag & drop to add -------------------------------------------------
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()
            self._slide(True)

    def dropEvent(self, e):
        for url in e.mimeData().urls():
            self.plugin.add_from_url(url)


# ====================================================================== Radial wheel
class Wheel(QWidget):
    SIZE = 460

    def __init__(self, plugin):
        super().__init__(None, Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedSize(self.SIZE, self.SIZE)
        self.setMouseTracking(True)
        self.plugin = plugin
        self.items = []
        self.sel = None
        self._t = 0.0
        self._open = QPropertyAnimation(self, b"progress", self)
        self._open.setDuration(230)
        self._open.setEasingCurve(QEasingCurve.OutBack)

    def get_progress(self):
        return self._t

    def set_progress(self, v):
        self._t = v
        self.update()

    progress = Property(float, get_progress, set_progress)

    def popup(self):
        self.items = self.plugin.setting("items", [])[:12]
        if not self.items:
            self.plugin.notify("Add apps in Quick Launch first", self.plugin.icon)
            return
        pos = QCursor.pos()
        geo = (QGuiApplication.screenAt(pos) or QGuiApplication.primaryScreen()).availableGeometry()
        x = min(max(pos.x() - self.SIZE // 2, geo.left()), geo.right() - self.SIZE)
        y = min(max(pos.y() - self.SIZE // 2, geo.top()), geo.bottom() - self.SIZE)
        self.move(x, y)
        self.sel = None
        self.show()
        self.raise_()
        self.activateWindow()
        win.focus(int(self.winId()))
        self._open.stop()
        self._open.setStartValue(0.0)
        self._open.setEndValue(1.0)
        self._open.start()

    def _positions(self):
        c = QPointF(self.SIZE / 2, self.SIZE / 2)
        n = len(self.items)
        radius = 150 * (0.55 + 0.45 * self._t)
        out = []
        for i in range(n):
            a = -math.pi / 2 + 2 * math.pi * i / n
            out.append(QPointF(c.x() + math.cos(a) * radius, c.y() + math.sin(a) * radius))
        return c, out

    def mouseMoveEvent(self, e):
        c, pts = self._positions()
        d = e.position() - c
        if math.hypot(d.x(), d.y()) < 45:
            self.sel = None
        else:
            ang = math.atan2(d.y(), d.x())
            n = len(self.items)
            idx = round(((ang + math.pi / 2) % (2 * math.pi)) / (2 * math.pi / n)) % n
            self.sel = idx
        self.update()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self.sel is not None:
            self._run(self.sel)
        elif e.button() in (Qt.LeftButton, Qt.RightButton):
            self.hide()

    def keyPressEvent(self, e):
        k = e.key()
        if k == Qt.Key_Escape:
            self.hide()
        elif Qt.Key_1 <= k <= Qt.Key_9 and k - Qt.Key_1 < len(self.items):
            self._run(k - Qt.Key_1)
        elif k in (Qt.Key_Right, Qt.Key_Down, Qt.Key_Tab):
            self.sel = 0 if self.sel is None else (self.sel + 1) % len(self.items)
            self.update()
        elif k in (Qt.Key_Left, Qt.Key_Up):
            self.sel = 0 if self.sel is None else (self.sel - 1) % len(self.items)
            self.update()
        elif k in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space) and self.sel is not None:
            self._run(self.sel)

    def changeEvent(self, e):
        if e.type() == QEvent.ActivationChange and not self.isActiveWindow() and self.isVisible():
            self.hide()
        super().changeEvent(e)

    def _run(self, i):
        it = self.items[i]
        self.hide()
        QTimer.singleShot(60, lambda: self.plugin.launch(it))

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.setOpacity(min(1.0, self._t * 1.4))
        c, pts = self._positions()
        # glassy disc
        rad = 205 * (0.6 + 0.4 * self._t)
        g = QRadialGradient(c, rad)
        g.setColorAt(0, QColor(22, 24, 36, 235))
        g.setColorAt(0.8, QColor(14, 16, 24, 225))
        g.setColorAt(1, QColor(14, 16, 24, 0))
        p.setPen(Qt.NoPen)
        p.setBrush(g)
        p.drawEllipse(c, rad, rad)
        ring = QColor(ui.ACCENT)
        ring.setAlpha(90)
        p.setPen(QPen(ring, 1.5))
        p.setBrush(Qt.NoBrush)
        p.drawEllipse(c, 150 * (0.55 + 0.45 * self._t), 150 * (0.55 + 0.45 * self._t))
        # selection wedge
        if self.sel is not None:
            sp = pts[self.sel]
            glow = QRadialGradient(sp, 52)
            a = QColor(ui.ACCENT)
            a.setAlpha(160)
            glow.setColorAt(0, a)
            a.setAlpha(0)
            glow.setColorAt(1, a)
            p.setPen(Qt.NoPen)
            p.setBrush(glow)
            p.drawEllipse(sp, 52, 52)
            p.setPen(QPen(QColor(ui.ACCENT2), 3, Qt.SolidLine, Qt.RoundCap))
            d = sp - c
            ln = math.hypot(d.x(), d.y()) or 1
            p.drawLine(c + d * (38 / ln), c + d * (95 / ln))
        for i, (it, pt) in enumerate(zip(self.items, pts)):
            s = 60 if i == self.sel else 50
            p.setPen(QPen(QColor(255, 255, 255, 40), 1))
            p.setBrush(QColor(255, 255, 255, 30 if i == self.sel else 16))
            p.drawEllipse(pt, s / 2 + 8, s / 2 + 8)
            pm = self.plugin.item_pixmap(it, 96)
            p.drawPixmap(QRectF(pt.x() - s / 2, pt.y() - s / 2, s, s).toRect(), pm)
            if i < 9:
                p.setFont(_text_font(10))
                p.setPen(QColor(ui.MUTED))
                p.drawText(QRectF(pt.x() + s / 2 - 2, pt.y() - s / 2 - 8, 16, 16), Qt.AlignCenter, str(i + 1))
        # centre label
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(8, 9, 14, 240))
        p.drawEllipse(c, 40, 40)
        label = self.items[self.sel]["name"] if self.sel is not None else "Launch"
        p.setFont(_text_font(12 if len(label) < 12 else 10))
        p.setPen(QColor("white"))
        p.drawText(QRectF(c.x() - 38, c.y() - 20, 76, 40), Qt.AlignCenter | Qt.TextWordWrap, label)
