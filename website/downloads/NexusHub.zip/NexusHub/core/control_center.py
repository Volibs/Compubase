"""Control Center: Wi-Fi, a per-app sound mixer and system toggles in one glass panel."""
import os
import threading

import psutil
from PySide6.QtCore import QEvent, QObject, QRectF, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QLinearGradient, QPainter, QPen
from PySide6.QtWidgets import (QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QMenu, QPushButton, QScrollArea,
                               QSlider, QStackedWidget, QVBoxLayout, QWidget)

from . import audio, icons, ui, wifi, win

def signal_glyph(pct):
    return ""


def signal_color(pct):
    """Strength shown by colour: bright for strong, dim for weak."""
    return ui.ACCENT2 if pct >= 60 else (ui.TEXT if pct >= 30 else ui.MUTED)


class _Bridge(QObject):
    """Delivers results from background threads (netsh can take a moment) back to the UI thread."""
    wifi_done = Signal(object, object)       # status, networks
    connect_done = Signal(bool, str)


def _pill_button(text, glyph=None, on=False, parent=None):
    b = QPushButton(text, parent)
    if glyph:
        b.setIcon(ui.glyph_icon(glyph, "white"))
        b.setIconSize(QSize(15, 15))
    b.setCursor(Qt.PointingHandCursor)
    b.setStyleSheet(
        "QPushButton { border: none; border-radius: 12px; padding: 8px 12px; font-weight: 600; text-align: left;"
        + (f" background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 {ui.ACCENT}, stop:1 {ui.ACCENT2}); color: white; }}"
           if on else " background: rgba(255,255,255,0.07); } QPushButton:hover { background: rgba(255,255,255,0.13); }"))
    return b


class ClickFrame(QFrame):
    def __init__(self, on_click):
        super().__init__()
        self.on_click = on_click

    def mouseReleaseEvent(self, e):
        self.on_click(e)


def _clear(layout):
    while layout.count():
        item = layout.takeAt(0)
        w = item.widget()
        if w:
            w.deleteLater()
        elif item.layout():
            _clear(item.layout())


class ControlCenter(QWidget):
    W, H = 430, 600

    def __init__(self, hub, anchor_fn):
        super().__init__(None, Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint)
        self.hub = hub
        self.anchor_fn = anchor_fn          # returns (x_right, y_edge, grow_up)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedSize(self.W, self.H)
        self.bridge = _Bridge()
        self.bridge.wifi_done.connect(self._show_wifi)
        self.bridge.connect_done.connect(self._connected)
        self._busy = False
        self._expanded_ssid = None
        self._mixer_rows = {}

        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 16, 18, 16)
        lay.setSpacing(12)
        tabs = QHBoxLayout()
        tabs.setSpacing(6)
        self.tab_btns = []
        for i, (glyph, text) in enumerate((("", "Wi-Fi"), ("", "Sound"), ("", "System"))):
            b = QPushButton(f"  {text}")
            b.setIcon(ui.glyph_icon(glyph, "white"))
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.setStyleSheet(
                "QPushButton { border: none; border-radius: 12px; padding: 9px; font-weight: 600; background: rgba(255,255,255,0.06); }"
                f"QPushButton:checked {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 {ui.ACCENT}, stop:1 {ui.ACCENT2}); color: white; }}")
            b.clicked.connect(lambda _=False, i=i: self.show_tab(i))
            tabs.addWidget(b)
            self.tab_btns.append(b)
        lay.addLayout(tabs)
        self.pages = QStackedWidget()
        self.pages.addWidget(self._wifi_page())
        self.pages.addWidget(self._sound_page())
        self.pages.addWidget(self._system_page())
        lay.addWidget(self.pages, 1)
        self._mixer_timer = QTimer(self, interval=2000, timeout=self._refresh_mixer)

    # ------------------------------------------------------------ window behaviour
    def open(self, tab=0):
        x_right, y_edge, grow_up = self.anchor_fn()
        geo = self.screen().geometry() if self.screen() else None
        x = max(8, x_right - self.W)
        y = y_edge - self.H - 10 if grow_up else y_edge + 10
        self.move(int(x), int(y))
        self.show()
        self.raise_()
        self.activateWindow()
        win.focus(int(self.winId()))
        self.show_tab(tab)

    def toggle(self, tab=0):
        if self.isVisible() and self.pages.currentIndex() == tab:
            self.hide()
        else:
            self.open(tab)

    def show_tab(self, i):
        for j, b in enumerate(self.tab_btns):
            b.setChecked(i == j)
        self.pages.setCurrentIndex(i)
        self._mixer_timer.stop()
        if i == 0:
            self.refresh_wifi(scan=True)
        elif i == 1:
            self._refresh_sound()
            self._mixer_timer.start()
        else:
            self._fill_system()

    def changeEvent(self, e):
        if e.type() == QEvent.ActivationChange and not self.isActiveWindow() and self.isVisible():
            QTimer.singleShot(0, self._maybe_hide)
        super().changeEvent(e)

    def _maybe_hide(self):
        if not self.isActiveWindow() and not any(w.isVisible() for w in self.findChildren(QMenu)):
            self.hide()

    def hideEvent(self, e):
        self._mixer_timer.stop()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.hide()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        g = QLinearGradient(r.topLeft(), r.bottomLeft())
        g.setColorAt(0, QColor(28, 31, 44, 248))
        g.setColorAt(1, QColor(14, 15, 22, 248))
        p.setBrush(g)
        edge = QLinearGradient(r.topLeft(), r.topRight())
        a1, a2 = QColor(ui.ACCENT), QColor(ui.ACCENT2)
        a1.setAlpha(140)
        a2.setAlpha(140)
        edge.setColorAt(0, a1)
        edge.setColorAt(1, a2)
        p.setPen(QPen(edge, 1.3))
        p.drawRoundedRect(r, 22, 22)

    # ------------------------------------------------------------ Wi-Fi
    def _wifi_page(self):
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(10)
        self.wifi_head = QFrame(objectName="wifihead")
        self.wifi_head.setStyleSheet("#wifihead { background: rgba(255,255,255,0.05); border-radius: 16px; }")
        hl = QHBoxLayout(self.wifi_head)
        hl.setContentsMargins(14, 12, 14, 12)
        self.wifi_icon = ui.glyph_label("", 26, ui.ACCENT2)
        self.wifi_icon.setFixedWidth(40)
        hl.addWidget(self.wifi_icon)
        col = QVBoxLayout()
        col.setSpacing(0)
        self.wifi_title = ui.label("Checking…", "h2")
        self.wifi_sub = ui.label("", "muted")
        col.addWidget(self.wifi_title)
        col.addWidget(self.wifi_sub)
        hl.addLayout(col, 1)
        self.wifi_disc = _pill_button("Disconnect")
        self.wifi_disc.clicked.connect(self._disconnect)
        hl.addWidget(self.wifi_disc)
        lay.addWidget(self.wifi_head)

        head = QHBoxLayout()
        head.addWidget(ui.label("Networks nearby", "h2"))
        head.addStretch()
        self.wifi_refresh = ui.button("", "ghost", "", lambda: self.refresh_wifi(scan=True))
        self.wifi_refresh.setToolTip("Scan again")
        head.addWidget(self.wifi_refresh)
        lay.addLayout(head)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        body = QWidget()
        self.net_box = QVBoxLayout(body)
        self.net_box.setContentsMargins(0, 0, 4, 0)
        self.net_box.setSpacing(6)
        self.net_box.addStretch()
        scroll.setWidget(body)
        lay.addWidget(scroll, 1)
        lay.addWidget(ui.button("More Wi-Fi settings", "ghost", "", lambda: (self.hide(), os.startfile("ms-settings:network-wifi"))))
        return page

    def refresh_wifi(self, scan=False):
        if self._busy:
            return
        self._busy = True
        self.wifi_refresh.setEnabled(False)

        def read():
            try:
                return wifi.status(), wifi.networks()
            except Exception:
                return {}, []

        def work():
            # everything runs off the UI thread: first what Windows already knows, then a fresh scan
            st, nets = read()
            if scan:
                self.bridge.wifi_done.emit(st, nets + [{"_partial": True}])
                wifi.scan()
                import time
                time.sleep(3.5)       # give the adapter time to hear every router
                st, nets = read()
            self.bridge.wifi_done.emit(st, nets)
        threading.Thread(target=work, daemon=True).start()

    def _show_wifi(self, st, nets):
        keep_busy = bool(nets) and nets[-1].get("_partial")
        if keep_busy:
            nets = nets[:-1]
        if not keep_busy:
            self._busy = False
            self.wifi_refresh.setEnabled(True)
        if not st:
            self.wifi_title.setText("No Wi-Fi adapter")
            self.wifi_sub.setText("You're probably on a cable")
            self.wifi_disc.hide()
        elif st.get("state") == "connected":
            self.wifi_icon.setText(signal_glyph(st.get("signal", 0)))
            self.wifi_title.setText(st.get("ssid", ""))
            self.wifi_sub.setText(f"{st.get('signal', 0)}% signal · {st.get('rate', '?')} Mbps · {st.get('band', '')}")
            self.wifi_sub.setToolTip(f"Connected · {st.get('band', '')}")
            self.wifi_disc.show()
        else:
            self.wifi_icon.setText("")
            self.wifi_title.setText("Not connected")
            self.wifi_sub.setText(st.get("state", "").capitalize())
            self.wifi_disc.hide()
        _clear(self.net_box)
        for n in nets:
            self.net_box.addWidget(self._net_row(n))
        if not nets:
            self.net_box.addWidget(ui.label("No networks found yet…", "muted"))
        self.net_box.addStretch()

    def _net_row(self, n):
        row = ClickFrame(lambda e, n=n: self._net_clicked(e, n))
        row.setObjectName("netrow")      # style only the row itself, not the labels inside it
        row.setStyleSheet("#netrow { background: rgba(255,255,255,0.045); border-radius: 12px; }"
                          "#netrow:hover { background: rgba(255,255,255,0.09); }")
        v = QVBoxLayout(row)
        v.setContentsMargins(12, 8, 12, 8)
        top = QHBoxLayout()
        ic = ui.glyph_label(signal_glyph(n["signal"]), 17, signal_color(n["signal"]))
        ic.setFixedWidth(26)
        top.addWidget(ic)
        name = ui.label(n["ssid"], "h2" if n["connected"] else None)
        top.addWidget(name, 1)
        badge = "Connected" if n["connected"] else ("Saved" if n["saved"] else "")
        if badge:
            top.addWidget(ui.label(badge, "pill"))
        if n["secure"]:
            top.addWidget(ui.glyph_label("", 12, ui.MUTED))
        top.addWidget(ui.label(f"{n['signal']}%", "muted"))
        v.addLayout(top)
        row.setCursor(Qt.PointingHandCursor)
        if n["ssid"] == self._expanded_ssid and not n["connected"]:
            pw = QLineEdit(placeholderText="Password")
            pw.setEchoMode(QLineEdit.Password)
            go = _pill_button("Connect", on=True)
            go.clicked.connect(lambda: self._connect(n, pw.text()))
            pw.returnPressed.connect(lambda: self._connect(n, pw.text()))
            v.addLayout(ui.hrow(pw, go))
            QTimer.singleShot(50, pw.setFocus)
        return row

    def _net_clicked(self, e, n):
        if e.button() == Qt.RightButton and n["saved"]:
            m = QMenu(self)
            m.addAction(ui.glyph_icon(""), f"Forget {n['ssid']}", lambda: (wifi.forget(n["ssid"]), self.refresh_wifi()))
            m.exec(e.globalPosition().toPoint())
        elif e.button() == Qt.LeftButton and not n["connected"]:
            if n["saved"] or not n["secure"]:
                self._connect(n, None)
            elif self._expanded_ssid != n["ssid"]:
                self._expanded_ssid = n["ssid"]       # open the password box under this network
                self.refresh_wifi()

    def _connect(self, n, password):
        self.wifi_title.setText(f"Connecting to {n['ssid']}…")
        self.wifi_sub.setText("")

        def work():
            ok, msg = wifi.connect(n["ssid"], password if password else None, n["auth"])
            import time
            time.sleep(3)
            self.bridge.connect_done.emit(ok, msg)
        threading.Thread(target=work, daemon=True).start()

    def _connected(self, ok, msg):
        self._expanded_ssid = None
        st = wifi.status()
        if st.get("state") == "connected":
            self.hub.osd.show_message(f"Connected to {st.get('ssid')}", "")
        elif not ok:
            self.hub.osd.show_message("Couldn't connect", "", sub=msg[:60])
        self.refresh_wifi()

    def _disconnect(self):
        wifi.disconnect()
        self.hub.osd.show_message("Wi-Fi disconnected", "")
        QTimer.singleShot(1200, self.refresh_wifi)

    # ------------------------------------------------------------ Sound
    def _sound_page(self):
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(10)
        self.master_mute = ui.button("", "ghost", "", self._toggle_master_mute)
        self.master = QSlider(Qt.Horizontal)
        self.master.setRange(0, 100)
        self.master.valueChanged.connect(self._set_master)
        self.master_pct = ui.label("", "h2")
        self.master_pct.setFixedWidth(46)
        lay.addWidget(ui.label("Volume", "h2"))
        lay.addLayout(ui.hrow(self.master_mute, self.master, self.master_pct))
        self.out_box = QVBoxLayout()
        self.out_box.setSpacing(4)
        lay.addLayout(self.out_box)
        lay.addWidget(ui.label("Microphone", "h2"))
        self.mic_mute = ui.button("", "ghost", "", self._toggle_mic)
        self.mic = QSlider(Qt.Horizontal)
        self.mic.setRange(0, 100)
        self.mic.valueChanged.connect(self._set_mic)
        lay.addLayout(ui.hrow(self.mic_mute, self.mic))
        lay.addWidget(ui.label("Apps", "h2"))
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        body = QWidget()
        self.mix_box = QVBoxLayout(body)
        self.mix_box.setContentsMargins(0, 0, 4, 0)
        self.mix_box.setSpacing(8)
        self.mix_box.addStretch()
        scroll.setWidget(body)
        lay.addWidget(scroll, 1)
        return page

    def _refresh_sound(self):
        try:
            spk = audio.speakers()
            v, muted = round(spk.GetMasterVolumeLevelScalar() * 100), spk.GetMute()
        except Exception:
            v, muted = 0, False
        if not self.master.isSliderDown():
            self.master.blockSignals(True)
            self.master.setValue(v)
            self.master.blockSignals(False)
        self.master_pct.setText(f"{v}%")
        self.master_mute.setIcon(ui.glyph_icon("" if muted else "", ui.BAD if muted else ui.TEXT))
        try:
            mic = audio.microphone()
            mv, mm = round(mic.GetMasterVolumeLevelScalar() * 100), mic.GetMute()
            self.mic.setEnabled(True)
        except Exception:
            mv, mm = 0, True
            self.mic.setEnabled(False)
        if not self.mic.isSliderDown():
            self.mic.blockSignals(True)
            self.mic.setValue(mv)
            self.mic.blockSignals(False)
        self.mic_mute.setIcon(ui.glyph_icon("" if mm else "", ui.BAD if mm else ui.GOOD))
        _clear(self.out_box)
        try:
            outs, cur = audio.outputs(), audio.default_output_id()
        except Exception:
            outs, cur = [], None
        for dev_id, name in outs:
            b = _pill_button(("  ✓  " if dev_id == cur else "      ") + audio.short_name(name), "", on=dev_id == cur)
            b.clicked.connect(lambda _=False, i=dev_id: (audio.set_default_output(i), self._refresh_sound()))
            self.out_box.addWidget(b)
        self._refresh_mixer(rebuild=True)

    def _refresh_mixer(self, rebuild=False):
        try:
            sessions = audio.sessions()
        except Exception:
            sessions = []
        seen = {}
        for name, proc, vol in sessions:
            seen.setdefault(proc, (name, vol))
        if rebuild or set(seen) != set(self._mixer_rows):
            _clear(self.mix_box)
            self._mixer_rows = {}
            for proc, (name, vol) in seen.items():
                row = {"vol": vol}
                ic = QLabel()
                ic.setFixedSize(26, 26)
                pm = self._proc_icon(proc)
                if pm is not None:
                    ic.setPixmap(pm.scaled(24, 24, Qt.KeepAspectRatio, Qt.SmoothTransformation))
                lbl = ui.label(name[:18])
                lbl.setFixedWidth(110)
                s = QSlider(Qt.Horizontal)
                s.setRange(0, 100)
                s.valueChanged.connect(lambda v, row=row: row["vol"].SetMasterVolume(v / 100, None))
                m = ui.button("", "ghost", "")
                m.setFixedWidth(34)
                m.clicked.connect(lambda _=False, row=row: (row["vol"].SetMute(int(not row["vol"].GetMute()), None),
                                                            self._refresh_mixer()))
                w = QWidget()
                w.setLayout(ui.hrow(ic, lbl, s, m))
                self.mix_box.addWidget(w)
                row.update(slider=s, mute=m)
                self._mixer_rows[proc] = row
            if not seen:
                self.mix_box.addWidget(ui.label("No apps are playing sound right now.", "muted"))
            self.mix_box.addStretch()
        for proc, (name, vol) in seen.items():
            row = self._mixer_rows.get(proc)
            if not row:
                continue
            row["vol"] = vol
            if not row["slider"].isSliderDown():
                row["slider"].blockSignals(True)
                row["slider"].setValue(round(vol.GetMasterVolume() * 100))
                row["slider"].blockSignals(False)
            muted = bool(vol.GetMute())
            row["mute"].setIcon(ui.glyph_icon("" if muted else "", ui.BAD if muted else ui.TEXT))

    def _proc_icon(self, proc_name):
        for p in psutil.process_iter(["name", "exe"]):
            if (p.info["name"] or "").lower() == proc_name and p.info["exe"]:
                return icons.extract(p.info["exe"], 0, 48)
        return None

    def _set_master(self, v):
        try:
            audio.speakers().SetMasterVolumeLevelScalar(v / 100, None)
        except Exception:
            pass
        self.master_pct.setText(f"{v}%")

    def _toggle_master_mute(self):
        try:
            spk = audio.speakers()
            spk.SetMute(int(not spk.GetMute()), None)
        except Exception:
            pass
        self._refresh_sound()

    def _set_mic(self, v):
        try:
            audio.microphone().SetMasterVolumeLevelScalar(v / 100, None)
        except Exception:
            pass

    def _toggle_mic(self):
        try:
            mic = audio.microphone()
            mic.SetMute(int(not mic.GetMute()), None)
        except Exception:
            pass
        self._refresh_sound()

    # ------------------------------------------------------------ System
    def _system_page(self):
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(10)
        self.sys_grid = QGridLayout()
        self.sys_grid.setSpacing(8)
        lay.addLayout(self.sys_grid)
        lay.addWidget(ui.label("Shortcuts", "h2"))
        grid = QGridLayout()
        grid.setSpacing(8)
        links = [("", "Bluetooth", lambda: os.startfile("ms-settings:bluetooth")),
                 ("", "Display", lambda: os.startfile("ms-settings:display")),
                 ("", "Notifications", lambda: os.startfile("ms-settings:notifications")),
                 ("", "Tray icons", self._tray_icons),
                 ("", "Screen off", lambda: QTimer.singleShot(500, win.monitor_off)),
                 ("", "Lock", win.lock_pc)]
        for i, (glyph, text, fn) in enumerate(links):
            b = _pill_button(f"  {text}", glyph)
            b.clicked.connect(lambda _=False, fn=fn: (self.hide(), fn()))
            grid.addWidget(b, i // 3, i % 3)
        lay.addLayout(grid)
        self.sys_info = ui.label("", "muted")
        lay.addWidget(self.sys_info)
        lay.addStretch()
        return page

    def _tray_icons(self):
        tb = self.hub.by_id.get("taskbar")
        if tb and tb.dock:
            tb.dock.peek_windows_taskbar()

    def _fill_system(self):
        _clear(self.sys_grid)
        hub = self.hub
        tiles = []

        def add(pid, text, glyph, state_fn, toggle_fn):
            p = hub.by_id.get(pid)
            if p and p.enabled:
                tiles.append((text, glyph, state_fn(p), lambda p=p: toggle_fn(p)))
        add("keepawake", "Keep awake", "", lambda p: p.active, lambda p: p.on_hotkey("toggle"))
        add("display", "Night filter", "", lambda p: bool(p.setting("night", False)), lambda p: p.on_hotkey("night"))
        disp = hub.by_id.get("display")
        if disp and disp.enabled:
            from importlib import import_module
            dark = type(disp).on_enable.__globals__["is_dark"]()
            tiles.append(("Dark mode", "", dark, lambda: disp.on_hotkey("theme")))
        add("gamemode", "Game mode", "", lambda p: p.active, lambda p: p.on_hotkey("toggle"))
        add("widgets", "Widgets", "", lambda p: bool(p.shown), lambda p: p.on_hotkey("toggle"))
        add("crosshair", "Crosshair", "", lambda p: p.overlay is not None, lambda p: p.on_hotkey("toggle"))
        add("sysmonitor", "Stats overlay", "", lambda p: p.overlay is not None, lambda p: p.on_hotkey("overlay"))
        add("wallpaper", "Live wallpaper", "", lambda p: bool(p.surfaces), lambda p: p.on_hotkey("toggle"))
        add("focus", "Focus timer", "", lambda p: p.running, lambda p: p.on_hotkey("toggle"))
        for i, (text, glyph, on, fn) in enumerate(tiles):
            b = _pill_button(f"  {text}", glyph, on=on)
            b.setMinimumHeight(52)
            b.clicked.connect(lambda _=False, fn=fn: (fn(), QTimer.singleShot(250, self._fill_system)))
            self.sys_grid.addWidget(b, i // 2, i % 2)
        up = int(psutil.boot_time())
        import time
        secs = int(time.time()) - up
        bat = psutil.sensors_battery() if hasattr(psutil, "sensors_battery") else None
        info = f"PC on for {secs // 86400}d {secs % 86400 // 3600}h {secs % 3600 // 60}m"
        if bat:
            info += f"  ·  Battery {bat.percent:.0f}%" + (" (charging)" if bat.power_plugged else "")
        self.sys_info.setText(info)
