"""System-wide hotkeys using the Win32 RegisterHotKey API.

Hotkeys are owned by a dedicated thread running its own message loop, so they
work no matter which window is focused and never need admin rights or a
keyboard hook.  Combos are plain strings such as "ctrl+alt+space".
"""
import ctypes
import queue
import threading
from ctypes import wintypes

from PySide6.QtCore import QObject, Signal

user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

user32.RegisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int, wintypes.UINT, wintypes.UINT]
user32.UnregisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int]
user32.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT]
user32.PeekMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT, wintypes.UINT]
user32.PostThreadMessageW.argtypes = [wintypes.DWORD, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]

MOD_ALT, MOD_CONTROL, MOD_SHIFT, MOD_WIN, MOD_NOREPEAT = 0x1, 0x2, 0x4, 0x8, 0x4000
WM_HOTKEY, WM_APP, WM_QUIT = 0x0312, 0x8000, 0x0012

MODS = {"ctrl": MOD_CONTROL, "alt": MOD_ALT, "shift": MOD_SHIFT, "win": MOD_WIN}

VK_NAMES = {
    0x08: "backspace", 0x09: "tab", 0x0D: "enter", 0x13: "pause", 0x14: "capslock",
    0x1B: "esc", 0x20: "space", 0x21: "pageup", 0x22: "pagedown", 0x23: "end",
    0x24: "home", 0x25: "left", 0x26: "up", 0x27: "right", 0x28: "down",
    0x2C: "printscreen", 0x2D: "insert", 0x2E: "delete",
    0x60: "num0", 0x61: "num1", 0x62: "num2", 0x63: "num3", 0x64: "num4",
    0x65: "num5", 0x66: "num6", 0x67: "num7", 0x68: "num8", 0x69: "num9",
    0x6A: "num*", 0x6B: "num+", 0x6D: "num-", 0x6E: "num.", 0x6F: "num/",
    0x91: "scrolllock",
    0xAD: "volumemute", 0xAE: "volumedown", 0xAF: "volumeup",
    0xB0: "medianext", 0xB1: "mediaprev", 0xB2: "mediastop", 0xB3: "mediaplay",
    0xBA: ";", 0xBB: "=", 0xBC: ",", 0xBD: "-", 0xBE: ".", 0xBF: "/", 0xC0: "`",
    0xDB: "[", 0xDC: "\\", 0xDD: "]", 0xDE: "'",
}
for _i in range(26):
    VK_NAMES[0x41 + _i] = chr(ord("a") + _i)
for _i in range(10):
    VK_NAMES[0x30 + _i] = str(_i)
for _i in range(24):
    VK_NAMES[0x70 + _i] = f"f{_i + 1}"
NAME_VK = {v: k for k, v in VK_NAMES.items()}

MODIFIER_VKS = {0x10, 0x11, 0x12, 0x5B, 0x5C, 0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5}


def parse(combo):
    """'ctrl+alt+p' -> (mods, vk) or None."""
    if not combo:
        return None
    mods, vk = 0, None
    for part in combo.lower().replace(" ", "").split("+"):
        if not part:
            continue
        if part in MODS:
            mods |= MODS[part]
        elif part in NAME_VK:
            vk = NAME_VK[part]
        elif part.startswith("vk") and part[2:].isdigit():
            vk = int(part[2:])
        else:
            return None
    return (mods, vk) if vk is not None else None


def format_combo(mods, vk):
    parts = [name for name, bit in MODS.items() if mods & bit]
    parts.append(VK_NAMES.get(vk, f"vk{vk}"))
    return "+".join(parts)


def pretty(combo):
    """'ctrl+alt+space' -> 'Ctrl + Alt + Space' for display."""
    if not combo:
        return "Not set"
    return " + ".join(p if len(p) == 1 and not p.isalpha() else p.capitalize() for p in combo.split("+"))


class HotkeyManager(QObject):
    triggered = Signal(str)

    def __init__(self):
        super().__init__()
        self._ops = queue.Queue()
        self._ids = {}       # hotkey id -> key name
        self._by_key = {}    # key name -> hotkey id
        self._next_id = 1
        self._tid = None
        ready = threading.Event()
        self._thread = threading.Thread(target=self._run, args=(ready,), daemon=True, name="hotkeys")
        self._thread.start()
        ready.wait(2)

    # -- public API (call from the GUI thread) --
    def register(self, key, combo):
        """Bind `key` (e.g. 'spotify.next') to `combo`. Returns True on success."""
        parsed = parse(combo)
        self.unregister(key)
        if not parsed:
            return False
        return self._call("reg", key, parsed)

    def probe(self, combo):
        """True if Windows would let us have `combo` right now (i.e. no other program owns it)."""
        ok = self.register("__probe__", combo)
        self.unregister("__probe__")
        return ok

    def unregister(self, key):
        if key in self._by_key:
            self._call("unreg", key, None)

    def shutdown(self):
        if self._tid:
            user32.PostThreadMessageW(self._tid, WM_QUIT, 0, 0)

    # -- internals --
    def _call(self, op, key, arg):
        done = threading.Event()
        box = {}
        self._ops.put((op, key, arg, done, box))
        user32.PostThreadMessageW(self._tid, WM_APP, 0, 0)
        done.wait(2)
        return box.get("ok", False)

    def _run(self, ready):
        self._tid = kernel32.GetCurrentThreadId()
        msg = wintypes.MSG()
        user32.PeekMessageW(ctypes.byref(msg), None, 0, 0, 0)  # create the queue
        ready.set()
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            if msg.message == WM_HOTKEY:
                key = self._ids.get(msg.wParam)
                if key:
                    self.triggered.emit(key)
            elif msg.message == WM_APP:
                self._drain()
        for hid in list(self._ids):
            user32.UnregisterHotKey(None, hid)

    def _drain(self):
        while True:
            try:
                op, key, arg, done, box = self._ops.get_nowait()
            except queue.Empty:
                return
            if op == "reg":
                mods, vk = arg
                hid = self._next_id
                self._next_id += 1
                if user32.RegisterHotKey(None, hid, mods | MOD_NOREPEAT, vk):
                    self._ids[hid] = key
                    self._by_key[key] = hid
                    box["ok"] = True
            elif op == "unreg":
                hid = self._by_key.pop(key, None)
                if hid is not None:
                    user32.UnregisterHotKey(None, hid)
                    self._ids.pop(hid, None)
                box["ok"] = True
            done.set()
