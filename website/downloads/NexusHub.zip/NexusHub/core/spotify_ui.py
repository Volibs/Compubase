"""Drive the Spotify desktop app through Windows UI Automation (the screen-reader API).

Used when the Web API isn't connected: we open an album/playlist page, switch shuffle on
and press the page's big Play button, just like a person would.
"""
import comtypes
import comtypes.client

_uia = None


def _lib():
    global _uia
    if _uia is None:
        comtypes.client.GetModule("UIAutomationCore.dll")
        from comtypes.gen import UIAutomationClient as UIA
        client = comtypes.CoCreateInstance(UIA.CUIAutomation._reg_clsid_, interface=UIA.IUIAutomation,
                                           clsctx=comtypes.CLSCTX_INPROC_SERVER)
        _uia = (UIA, client)
    return _uia


def buttons(hwnd):
    """[(name, element)] for every button in the Spotify window, in on-screen order."""
    UIA, client = _lib()
    root = client.ElementFromHandle(hwnd)
    cond = client.CreatePropertyCondition(UIA.UIA_ControlTypePropertyId, UIA.UIA_ButtonControlTypeId)
    found = root.FindAll(UIA.TreeScope_Descendants, cond)
    return [(found.GetElement(i).CurrentName or "", found.GetElement(i)) for i in range(found.Length)]


def invoke(el):
    """Press a button. Returns False if Spotify re-drew it in the meantime (stale element)."""
    UIA, _ = _lib()
    for pattern_id, iface, method in ((UIA.UIA_InvokePatternId, UIA.IUIAutomationInvokePattern, "Invoke"),
                                      (UIA.UIA_LegacyIAccessiblePatternId, UIA.IUIAutomationLegacyIAccessiblePattern,
                                       "DoDefaultAction")):
        try:
            pat = el.GetCurrentPattern(pattern_id)
            if pat:
                getattr(pat.QueryInterface(iface), method)()
                return True
        except (ValueError, OSError, comtypes.COMError):
            continue
    return False


def _volume_slider(hwnd):
    UIA, client = _lib()
    root = client.ElementFromHandle(hwnd)
    cond = client.CreatePropertyCondition(UIA.UIA_ControlTypePropertyId, UIA.UIA_SliderControlTypeId)
    found = root.FindAll(UIA.TreeScope_Descendants, cond)
    for i in range(found.Length):
        el = found.GetElement(i)
        if el.CurrentName == "Change volume":
            rv = el.GetCurrentPattern(UIA.UIA_RangeValuePatternId).QueryInterface(UIA.IUIAutomationRangeValuePattern)
            return el, rv
    return None, None


def get_volume(hwnd):
    """Spotify's own volume (0..1), as shown on its slider, or None."""
    try:
        _, rv = _volume_slider(hwnd)
        return rv.CurrentValue if rv else None
    except Exception:
        return None


def step_volume(hwnd, steps):
    """Move Spotify's own volume slider by `steps` notches (10% each). Returns the new value (0..1) or None.

    Spotify ignores a direct 'set value', but its slider reacts to arrow keys, which we post straight
    to Spotify's window: your keyboard focus stays where it is.
    """
    from . import win
    from ctypes import wintypes
    el, rv = _volume_slider(hwnd)
    if el is None:
        return None
    win.user32.FindWindowExW.restype = wintypes.HWND
    render = win.user32.FindWindowExW(hwnd, None, "Chrome_RenderWidgetHostHWND", None)
    if not render:
        return None
    prev = win.foreground()
    el.SetFocus()
    vk, scan = (0x26, 0x48) if steps > 0 else (0x28, 0x50)       # up / down arrow
    for _ in range(abs(int(steps))):
        win.user32.PostMessageW(render, 0x100, vk, 0x00000001 | (scan << 16))
        win.user32.PostMessageW(render, 0x101, vk, 0xC0000001 | (scan << 16))
    if prev and win.foreground() != prev:
        win.focus(prev)                                          # never leave focus on Spotify
    import time
    time.sleep(0.12 + 0.03 * abs(int(steps)))                    # let Spotify apply it
    return rv.CurrentValue


def set_volume(hwnd, value):
    """Set Spotify's own volume to the nearest 10%."""
    cur = get_volume(hwnd)
    if cur is None:
        return None
    steps = round(value * 10) - round(cur * 10)
    return step_volume(hwnd, steps) if steps else cur


def toggle_mute(hwnd):
    """Press Spotify's own mute button. Returns True if now muted, None if not found."""
    for name, el in buttons(hwnd):
        if name in ("Mute", "Unmute"):
            invoke(el)
            return name == "Mute"
    return None


def _norm(s):
    return "".join(ch for ch in s.casefold() if ch.isalnum())


def page_controls(hwnd, title):
    """Find the open page's (play, shuffle_enable, already_shuffled) buttons.

    The page's controls sit next to 'Enable/Disable Shuffle for <title>' and 'More options for <title>';
    the player bar has its own set for the current song, so we match on the title (or take the last set).
    """
    btns = buttons(hwnd)
    want = _norm(title)
    anchors = []
    for i, (name, _) in enumerate(btns):
        for prefix in ("Enable Shuffle for ", "Disable Shuffle for ", "More options for "):
            if name.startswith(prefix):
                anchors.append((i, prefix, name[len(prefix):]))
    if not anchors:
        return None
    matching = [a for a in anchors if want and (_norm(a[2]).startswith(want[:20]) or want.startswith(_norm(a[2])[:20]))]
    anchor = (matching or anchors)[-1]
    idx, subject = anchor[0], anchor[2]
    shuffle_on = shuffle_off = None
    for i, (name, el) in enumerate(btns):
        if name == f"Enable Shuffle for {subject}":
            shuffle_off = el
        elif name == f"Disable Shuffle for {subject}":
            shuffle_on = el
    play = None
    for i in range(idx, max(-1, idx - 8), -1):   # the big Play button comes just before the anchor
        name = btns[i][0]
        if name in ("Play", "Pause") or name in (f"Play {subject}", f"Pause {subject}"):
            play = btns[i]
            break
    return {"play": play, "shuffle_off": shuffle_off, "shuffle_on": shuffle_on, "subject": subject}
