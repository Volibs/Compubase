"""Shared look & feel: theme, icons and reusable widgets."""
from collections import deque

from PySide6.QtCore import (Property, QEasingCurve, QPointF, QPropertyAnimation, QRectF, QSize, Qt,
                            QTimer, Signal)
from PySide6.QtGui import (QColor, QCursor, QFont, QGuiApplication, QIcon, QLinearGradient, QPainter,
                           QPainterPath, QPen, QPixmap)
from PySide6.QtWidgets import (QAbstractButton, QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton,
                               QVBoxLayout, QWidget)

from . import hotkeys

BG = "#0d0f14"
SIDEBAR = "#10131a"
SURFACE = "#161a23"
SURFACE2 = "#1d2230"
BORDER = "#252b3a"
TEXT = "#e8ebf2"
MUTED = "#8a93a6"
ACCENT = "#7c6cff"
ACCENT2 = "#22d3ee"
GOOD = "#34d399"
WARN = "#fbbf24"
BAD = "#f87171"

ICON_FONT = "Segoe Fluent Icons"
TEXT_FONT = "Segoe UI Variable Text"


def icon_font(size=16):
    f = QFont(ICON_FONT)
    if not f.exactMatch():
        f = QFont("Segoe MDL2 Assets")
    f.setPixelSize(size)
    return f


def glyph_label(glyph, size=18, color=TEXT):
    lbl = QLabel(glyph)
    f = icon_font(size)
    lbl.setFont(f)
    # the global "* { font-family }" rule would otherwise override the icon font
    lbl.setStyleSheet(f'color:{color}; background:transparent; font-family:"{f.family()}"; font-size:{size}px;')
    lbl.setAlignment(Qt.AlignCenter)
    return lbl


def glyph_icon(glyph, color=TEXT, size=32):
    pm = QPixmap(size, size)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    p.setFont(icon_font(int(size * 0.8)))
    p.setPen(QColor(color))
    p.drawText(pm.rect(), Qt.AlignCenter, glyph)
    p.end()
    return QIcon(pm)


def app_icon(size=64):
    """The NexusHub logo, drawn in code so there are no image files to lose."""
    pm = QPixmap(size, size)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    g = QLinearGradient(0, 0, size, size)
    g.setColorAt(0, QColor(ACCENT))
    g.setColorAt(1, QColor(ACCENT2))
    p.setBrush(g)
    p.setPen(Qt.NoPen)
    p.drawRoundedRect(QRectF(0, 0, size, size), size * 0.26, size * 0.26)
    f = QFont("Segoe UI", -1, QFont.Black)
    f.setPixelSize(int(size * 0.62))
    p.setFont(f)
    p.setPen(QColor("white"))
    p.drawText(pm.rect().adjusted(0, -int(size * 0.03), 0, 0), Qt.AlignCenter, "N")
    p.end()
    return QIcon(pm)


THEMES = {
    "Nexus Violet": ("#7c6cff", "#22d3ee"),
    "Ocean": ("#3b82f6", "#2dd4bf"),
    "Sunset": ("#f97316", "#ec4899"),
    "Emerald": ("#10b981", "#a3e635"),
    "Crimson": ("#ef4444", "#f59e0b"),
    "Sakura": ("#ec4899", "#c4b5fd"),
    "Gold": ("#eab308", "#fb923c"),
    "Mono": ("#a1a1aa", "#e4e4e7"),
}


def rgba(hex_color, alpha):
    """'#7c6cff', 0.3 -> 'rgba(124,108,255,0.3)' for stylesheets."""
    c = QColor(hex_color)
    return f"rgba({c.red()},{c.green()},{c.blue()},{alpha})"


def apply_theme(name, custom=None):
    """Set the accent colours (call before building windows). `custom` = (accent, accent2)."""
    global ACCENT, ACCENT2, STYLESHEET
    ACCENT, ACCENT2 = custom or THEMES.get(name, THEMES["Nexus Violet"])
    STYLESHEET = build_stylesheet()


def build_stylesheet():
    return f"""
* {{ font-family: "{TEXT_FONT}", "Segoe UI"; font-size: 13px; color: {TEXT}; }}
QMainWindow, QDialog, #root {{ background: {BG}; }}
QWidget#page {{ background: {BG}; }}
QScrollArea, QScrollArea > QWidget > QWidget {{ background: transparent; border: none; }}
QToolTip {{ background: {SURFACE2}; color: {TEXT}; border: 1px solid {BORDER}; padding: 6px; border-radius: 6px; }}

#sidebar {{ background: {SIDEBAR}; border-right: 1px solid {BORDER}; }}
#brand {{ font-size: 17px; font-weight: 700; }}
#navButton {{ text-align: left; padding: 9px 12px; border: none; border-radius: 8px; background: transparent; color: {MUTED}; }}
#navButton:hover {{ background: {SURFACE}; color: {TEXT}; }}
#navButton:checked {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 {rgba(ACCENT, 0.28)}, stop:1 {rgba(ACCENT, 0.02)});
    color: white; font-weight: 600; border-left: 3px solid {ACCENT}; padding-left: 9px; }}

#card {{ background: {SURFACE}; border: 1px solid {BORDER}; border-radius: 14px; }}
#card:hover[hoverable="true"] {{ border-color: {rgba(ACCENT, 0.55)}; background: #181c27; }}
#h1 {{ font-size: 24px; font-weight: 700; }}
#h2 {{ font-size: 15px; font-weight: 600; }}
#muted {{ color: {MUTED}; }}
#big {{ font-size: 28px; font-weight: 700; }}
#pill {{ background: {SURFACE2}; border-radius: 10px; padding: 3px 9px; color: {MUTED}; font-size: 11px; }}

QPushButton {{ background: {SURFACE2}; border: 1px solid {BORDER}; border-radius: 9px; padding: 8px 14px; }}
QPushButton:hover {{ background: #262c3d; border-color: #343c52; }}
QPushButton:pressed {{ background: #1a1f2b; }}
QPushButton:disabled {{ color: #555c6e; }}
QPushButton[kind="primary"] {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 {ACCENT}, stop:1 {ACCENT2});
    border: none; color: white; font-weight: 600; }}
QPushButton[kind="primary"]:hover {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 {ACCENT2}, stop:1 {ACCENT}); }}
QPushButton[kind="primary"]:pressed {{ background: {ACCENT}; }}
QPushButton[kind="danger"] {{ background: #3a1d24; border: 1px solid #5a2833; color: #ffb4b4; }}
QPushButton[kind="danger"]:hover {{ background: #4a232c; }}
QPushButton[kind="ghost"] {{ background: transparent; border: none; color: {MUTED}; }}
QPushButton[kind="ghost"]:hover {{ color: {TEXT}; background: {SURFACE2}; }}

QLineEdit, QComboBox, QSpinBox {{ background: {SURFACE2}; border: 1px solid {BORDER}; border-radius: 8px; padding: 7px 10px; selection-background-color: {ACCENT}; }}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus {{ border-color: {ACCENT}; }}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox QAbstractItemView {{ background: {SURFACE2}; border: 1px solid {BORDER}; selection-background-color: {ACCENT}; outline: none; padding: 4px; }}

QSlider::groove:horizontal {{ height: 6px; background: {SURFACE2}; border-radius: 3px; }}
QSlider::sub-page:horizontal {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 {ACCENT}, stop:1 {ACCENT2}); border-radius: 3px; }}
QSlider::handle:horizontal {{ background: white; width: 16px; height: 16px; margin: -5px 0; border-radius: 8px; }}

QListWidget, QTableWidget, QTreeWidget {{ background: {SURFACE}; border: 1px solid {BORDER}; border-radius: 10px; outline: none; padding: 4px; }}
QListWidget::item, QTreeWidget::item {{ padding: 7px; border-radius: 6px; }}
QListWidget::item:selected, QTreeWidget::item:selected, QTableWidget::item:selected {{ background: {SURFACE2}; color: {TEXT}; }}
QListWidget::item:hover, QTreeWidget::item:hover {{ background: #1a1f2a; }}
QHeaderView::section {{ background: {SURFACE}; color: {MUTED}; border: none; padding: 6px; }}
QTableWidget {{ gridline-color: transparent; }}

QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: #2b3243; border-radius: 4px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: #3a4358; }}
QScrollBar::add-line, QScrollBar::sub-line, QScrollBar::add-page, QScrollBar::sub-page {{ background: none; height: 0; }}
QScrollBar:horizontal {{ height: 0; }}
QCheckBox::indicator {{ width: 16px; height: 16px; border-radius: 4px; border: 1px solid {BORDER}; background: {SURFACE2}; }}
QCheckBox::indicator:checked {{ background: {ACCENT}; border-color: {ACCENT}; }}
QMenu {{ background: {SURFACE}; border: 1px solid {BORDER}; border-radius: 10px; padding: 6px; }}
QMenu::item {{ padding: 7px 26px 7px 12px; border-radius: 6px; }}
QMenu::item:selected {{ background: {SURFACE2}; }}
QMenu::separator {{ height: 1px; background: {BORDER}; margin: 5px 8px; }}
QProgressBar {{ background: {SURFACE2}; border: none; border-radius: 4px; height: 8px; text-align: center; color: transparent; }}
QProgressBar::chunk {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 {ACCENT}, stop:1 {ACCENT2}); border-radius: 4px; }}
QMessageBox {{ background: {SURFACE}; }}
"""


STYLESHEET = build_stylesheet()


def label(text, kind=None, wrap=False):
    lbl = QLabel(text)
    if kind:
        lbl.setObjectName(kind)
    lbl.setWordWrap(wrap)
    return lbl


def button(text, kind=None, glyph=None, on_click=None):
    b = QPushButton(text)
    if kind:
        b.setProperty("kind", kind)
    if glyph:
        b.setIcon(glyph_icon(glyph, "white" if kind == "primary" else TEXT))
        b.setIconSize(QSize(15, 15))
    b.setCursor(Qt.PointingHandCursor)
    if on_click:
        b.clicked.connect(on_click)
    return b


class Card(QFrame):
    def __init__(self, title=None, glyph=None, parent=None):
        super().__init__(parent)
        self.setObjectName("card")
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(18, 16, 18, 16)
        self.lay.setSpacing(10)
        if title:
            row = QHBoxLayout()
            row.setSpacing(8)
            if glyph:
                row.addWidget(glyph_label(glyph, 15, ACCENT2))
            row.addWidget(label(title, "h2"))
            row.addStretch()
            self.header = row
            self.lay.addLayout(row)

    def add(self, w):
        if isinstance(w, QWidget):
            self.lay.addWidget(w)
        else:
            self.lay.addLayout(w)
        return w


def hrow(*items, spacing=8, stretch_at=None):
    row = QHBoxLayout()
    row.setSpacing(spacing)
    row.setContentsMargins(0, 0, 0, 0)
    for i, it in enumerate(items):
        if i == stretch_at:
            row.addStretch()
        if it is None:
            row.addStretch()
        elif isinstance(it, QWidget):
            row.addWidget(it)
        else:
            row.addLayout(it)
    return row


class ToggleSwitch(QAbstractButton):
    def __init__(self, checked=False, parent=None):
        super().__init__(parent)
        self.setCheckable(True)
        self.setChecked(checked)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedSize(42, 24)
        self._pos = 1.0 if checked else 0.0
        self._anim = QPropertyAnimation(self, b"knob", self)
        self._anim.setDuration(160)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self.toggled.connect(self._animate)

    def _animate(self, on):
        self._anim.stop()
        self._anim.setEndValue(1.0 if on else 0.0)
        self._anim.start()

    def setChecked(self, on):
        super().setChecked(on)
        self._pos = 1.0 if on else 0.0
        self.update()

    def get_knob(self):
        return self._pos

    def set_knob(self, v):
        self._pos = v
        self.update()

    knob = Property(float, get_knob, set_knob)

    def sizeHint(self):
        return QSize(42, 24)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        off, on = QColor("#2a3040"), QColor(ACCENT)
        c = QColor(
            int(off.red() + (on.red() - off.red()) * self._pos),
            int(off.green() + (on.green() - off.green()) * self._pos),
            int(off.blue() + (on.blue() - off.blue()) * self._pos))
        p.setBrush(c)
        p.setPen(Qt.NoPen)
        p.drawRoundedRect(QRectF(0, 0, 42, 24), 12, 12)
        p.setBrush(QColor("white"))
        p.drawEllipse(QPointF(12 + self._pos * 18, 12), 8, 8)


class HotkeyEdit(QLineEdit):
    """Click, then press a key combo. Backspace clears, Esc cancels."""
    changed = Signal(str)

    def __init__(self, combo="", parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedWidth(200)
        self.combo = combo
        self.reviewer = None      # optional callable(combo) -> bool, asked before a new combo is accepted
        self._show()

    def set_combo(self, combo):
        self.combo = combo
        self._show()

    def _show(self):
        self.setText(hotkeys.pretty(self.combo))

    def focusInEvent(self, e):
        super().focusInEvent(e)
        self.setText("Press a key combo…")

    def focusOutEvent(self, e):
        super().focusOutEvent(e)
        self._show()

    def keyPressEvent(self, e):
        vk = e.nativeVirtualKey()
        if e.key() == Qt.Key_Escape:
            self.clearFocus()
            return
        if e.key() in (Qt.Key_Backspace, Qt.Key_Delete) and not e.modifiers():
            self.combo = ""
            self.changed.emit("")
            self.clearFocus()
            return
        mods = 0
        m = e.modifiers()
        if m & Qt.ControlModifier:
            mods |= hotkeys.MOD_CONTROL
        if m & Qt.AltModifier:
            mods |= hotkeys.MOD_ALT
        if m & Qt.ShiftModifier:
            mods |= hotkeys.MOD_SHIFT
        if m & Qt.MetaModifier:
            mods |= hotkeys.MOD_WIN
        if vk in hotkeys.MODIFIER_VKS or not vk:
            return
        combo = hotkeys.format_combo(mods, vk)
        self.clearFocus()
        # let the owner check for clashes first (other NexusHub actions, other programs)
        if self.reviewer is not None and not self.reviewer(combo):
            self._show()
            return
        self.combo = combo
        self._show()
        self.changed.emit(self.combo)


class OSD(QWidget):
    """The little pop-up that confirms hotkey actions, drawn over everything."""

    def __init__(self):
        super().__init__(None, Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint
                         | Qt.WindowTransparentForInput | Qt.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self._text, self._glyph, self._sub = "", "", ""
        self._value = None
        self._hide = QTimer(self, singleShot=True, timeout=self._fade_out)
        self._fade = QPropertyAnimation(self, b"windowOpacity", self)
        self._fade.setDuration(180)
        self._fade.finished.connect(self._after_fade)

    def show_message(self, text, glyph="", value=None, sub="", color=None):
        """`value` (0..1) draws a progress bar, handy for volume/opacity.
        `color` fills the bubble with that colour instead of a glyph (colour picker)."""
        self._text, self._glyph, self._value, self._sub = text, glyph, value, sub
        self._color = color
        fm_w = self.fontMetrics().horizontalAdvance(text) * 1.25
        w = int(max(260, min(560, fm_w + 110)))
        h = 76 if value is None and not sub else 92
        screen = QGuiApplication.screenAt(QCursor.pos()) or QGuiApplication.primaryScreen()
        geo = screen.availableGeometry()
        self.setGeometry(geo.center().x() - w // 2, geo.bottom() - h - 70, w, h)
        self._fade.stop()
        if not self.isVisible():
            self.setWindowOpacity(0.0)
            self.show()
        self._fade.setStartValue(self.windowOpacity())
        self._fade.setEndValue(1.0)
        self._fade.start()
        self.raise_()
        self.update()
        self._hide.start(1600)

    def _fade_out(self):
        self._fade.stop()
        self._fade.setStartValue(self.windowOpacity())
        self._fade.setEndValue(0.0)
        self._fade.start()

    def _after_fade(self):
        if self.windowOpacity() <= 0.01:
            self.hide()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setBrush(QColor(18, 21, 30, 238))
        p.setPen(QPen(QColor(255, 255, 255, 28), 1))
        p.drawRoundedRect(r, 18, 18)
        # glyph bubble
        g = QLinearGradient(0, 0, 60, 60)
        g.setColorAt(0, QColor(ACCENT))
        g.setColorAt(1, QColor(ACCENT2))
        cy = r.center().y()
        if getattr(self, "_color", None):
            p.setPen(QPen(QColor(255, 255, 255, 90), 2))
            p.setBrush(QColor(self._color))
            p.drawEllipse(QPointF(44, cy), 22, 22)
        else:
            p.setPen(Qt.NoPen)
            p.setBrush(g)
            p.drawEllipse(QPointF(44, cy), 22, 22)
            p.setPen(QColor("white"))
            p.setFont(icon_font(20))
            p.drawText(QRectF(22, cy - 22, 44, 44), Qt.AlignCenter, self._glyph)
        # text
        f = QFont(TEXT_FONT)
        f.setPixelSize(15)
        f.setWeight(QFont.DemiBold)
        p.setFont(f)
        p.setPen(QColor(TEXT))
        has_extra = self._value is not None or self._sub
        if has_extra:
            text_rect = QRectF(80, cy - 26, r.width() - 96, 24)
        else:
            text_rect = QRectF(80, 0, r.width() - 96, r.height())
        p.drawText(text_rect, Qt.AlignVCenter | Qt.AlignLeft,
                   p.fontMetrics().elidedText(self._text, Qt.ElideRight, int(text_rect.width())))
        if self._value is not None:
            bar = QRectF(80, cy + 6, r.width() - 110, 7)
            p.setBrush(QColor(255, 255, 255, 30))
            p.drawRoundedRect(bar, 3.5, 3.5)
            fill = QRectF(bar.x(), bar.y(), bar.width() * max(0.0, min(1.0, self._value)), bar.height())
            gg = QLinearGradient(bar.topLeft(), bar.topRight())
            gg.setColorAt(0, QColor(ACCENT))
            gg.setColorAt(1, QColor(ACCENT2))
            p.setBrush(gg)
            p.drawRoundedRect(fill, 3.5, 3.5)
        elif self._sub:
            f.setPixelSize(12)
            f.setWeight(QFont.Normal)
            p.setFont(f)
            p.setPen(QColor(MUTED))
            p.drawText(QRectF(80, cy + 2, r.width() - 96, 22), Qt.AlignLeft | Qt.AlignTop,
                       p.fontMetrics().elidedText(self._sub, Qt.ElideRight, int(r.width() - 96)))


class LineGraph(QWidget):
    """A smooth live graph for monitors (CPU, network…)."""

    def __init__(self, color=ACCENT2, points=60, max_value=None, parent=None):
        super().__init__(parent)
        self.color = QColor(color)
        self.values = deque([0.0] * points, maxlen=points)
        self.max_value = max_value
        self.setMinimumHeight(70)

    def push(self, v):
        self.values.append(float(v))
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        top = self.max_value or max(max(self.values) * 1.2, 1e-6)
        n = len(self.values)
        step = w / max(1, n - 1)
        path = QPainterPath()
        for i, v in enumerate(self.values):
            pt = QPointF(i * step, h - 2 - (h - 6) * min(v / top, 1.0))
            path.moveTo(pt) if i == 0 else path.lineTo(pt)
        fill = QPainterPath(path)
        fill.lineTo(w, h)
        fill.lineTo(0, h)
        fill.closeSubpath()
        g = QLinearGradient(0, 0, 0, h)
        c1 = QColor(self.color)
        c1.setAlpha(90)
        c2 = QColor(self.color)
        c2.setAlpha(0)
        g.setColorAt(0, c1)
        g.setColorAt(1, c2)
        p.fillPath(fill, g)
        p.setPen(QPen(self.color, 2))
        p.drawPath(path)


def human_bytes(n, per_sec=False):
    suffix = "/s" if per_sec else ""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024 or unit == "TB":
            return f"{n:.0f} {unit}{suffix}" if unit == "B" else f"{n:.1f} {unit}{suffix}"
        n /= 1024
