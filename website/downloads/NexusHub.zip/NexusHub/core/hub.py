"""The hub: loads plugins, owns hotkeys/tray/config, and draws the main window."""
import ctypes
import datetime
import gc
import importlib.util
import inspect
import logging
import os
import sys
import traceback
import winreg

from PySide6.QtCore import QEasingCurve, QObject, QPointF, QPropertyAnimation, QRectF, QSize, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QAction, QColor, QDesktopServices, QFont, QPainter, QPainterPath, QPen, QRadialGradient
from PySide6.QtWidgets import (QApplication, QButtonGroup, QColorDialog, QComboBox, QFrame, QGraphicsOpacityEffect,
                               QGridLayout, QHBoxLayout, QLabel, QLineEdit,
                               QMainWindow, QMenu, QPushButton, QScrollArea, QStackedWidget,
                               QSystemTrayIcon, QVBoxLayout, QWidget)

from . import ui, win
from .config import APP_DIR, Config
from .hotkeys import HotkeyManager
from .plugin import Plugin

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PLUGIN_DIR = os.path.join(ROOT, "plugins")
LOG_PATH = os.path.join(APP_DIR, "nexushub.log")
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"

log = logging.getLogger("nexushub")


def load_plugins(hub):
    plugins, errors = [], []
    sys.path.insert(0, ROOT)
    for fname in sorted(os.listdir(PLUGIN_DIR)):
        if not fname.endswith(".py") or fname.startswith("_"):
            continue
        path = os.path.join(PLUGIN_DIR, fname)
        try:
            spec = importlib.util.spec_from_file_location("nexus_plugins." + fname[:-3], path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            for _, cls in inspect.getmembers(mod, inspect.isclass):
                if issubclass(cls, Plugin) and cls is not Plugin and cls.id and cls.__module__ == mod.__name__:
                    plugins.append(cls(hub))
        except Exception:
            log.exception("Failed to load plugin %s", fname)
            errors.append((fname, traceback.format_exc(limit=3)))
    plugins.sort(key=lambda p: (p.order, p.name))
    return plugins, errors


class Hub(QObject):
    changed = Signal()      # a plugin was enabled/disabled or rebound
    tick = Signal()         # every ~1.5s, for status text refreshes

    def __init__(self, app, start_hidden=False):
        super().__init__()
        gc.disable()   # see the note next to self._gc below
        self.app = app
        self.config = Config()
        # held for as long as this copy lives; guardians check it to see if NexusHub is running
        kernel32 = ctypes.windll.kernel32
        kernel32.CreateMutexW.restype = ctypes.c_void_p
        self._mutex = kernel32.CreateMutexW(None, False, "NexusHub-running-" + os.environ.get("USERNAME", "user"))
        self._start_guardian()
        self.osd = ui.OSD()
        self.hotkeys = HotkeyManager()
        self.hotkeys.triggered.connect(self._on_hotkey)
        self.hotkey_ok = {}
        from .account_page import AccountSync
        self.account_sync = AccountSync(self)
        self.plugins, self.load_errors = load_plugins(self)
        self.by_id = {p.id: p for p in self.plugins}

        for p in self.plugins:
            if self.is_enabled(p):
                self._start(p)

        self.window = MainWindow(self)
        self._build_tray()
        self._ticker = QTimer(self, interval=1500, timeout=self.tick.emit)
        self._ticker.start()
        # Audio uses COM objects that must be freed on this (GUI) thread. Python's automatic
        # garbage collector can run on any thread (e.g. the hotkey thread) and crash when it
        # frees one, so we switch it off and collect here on a timer instead.
        self._gc = QTimer(self, interval=3000, timeout=gc.collect)
        self._gc.start()
        if not start_hidden:
            self.show_window()
        else:
            bar = self.by_id.get("nexusbar")
            hint = f"{ui.hotkeys.pretty(self.combo_for(bar, 'open'))} opens the Nexus Bar" if bar and bar.enabled else ""
            n = sum(1 for p in self.plugins if p.enabled)
            QTimer.singleShot(3000, lambda: self.osd.show_message(f"NexusHub is ready · {n} modules", "", sub=hint))

    # ------------------------------------------------------------ guardian / links
    def _start_guardian(self):
        """Launch the watchdog that restores the Windows taskbar and revives NexusHub if it dies."""
        import subprocess
        exe = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
        try:
            subprocess.Popen([exe if os.path.exists(exe) else sys.executable,
                              os.path.join(ROOT, "core", "guardian.py"), str(os.getpid())],
                             creationflags=0x00000008 | 0x00000200, close_fds=True)
        except OSError:
            log.exception("Couldn't start the guardian")

    def _mark_clean_exit(self):
        try:
            with open(os.path.join(APP_DIR, f"clean_exit_{os.getpid()}"), "w") as f:   # read by this copy's guardian
                f.write("1")
        except OSError:
            pass

    def open_url(self, url):
        """Open a link in the built-in browser (if it's on), otherwise in your normal browser."""
        br = self.by_id.get("browser")
        if br and br.enabled and br.setting("handle_links", True):
            br.open_tab(url, show=True)
        else:
            os.startfile(url)

    def ask_quit(self):
        from PySide6.QtWidgets import QMessageBox
        if QMessageBox.question(self.window, "Quit NexusHub",
                                "Quit NexusHub completely?\n\nHotkeys, your taskbar, wallpapers and widgets will stop "
                                "until you open it again.") == QMessageBox.Yes:
            self.quit()

    # ------------------------------------------------------------ appearance
    def look(self):
        return self.config.section("appearance")

    def set_look(self, key, value):
        self.look()[key] = value
        self.config.save()

    def restart(self):
        """Start a fresh copy of NexusHub, then close this one (used after theme changes)."""
        from PySide6.QtCore import QProcess
        self._mark_clean_exit()
        QProcess.startDetached(sys.executable, [os.path.join(ROOT, "main.py"), "--restart"])
        self.quit()

    # ------------------------------------------------------------ plugins
    def is_enabled(self, p):
        return self.config.section("enabled").get(p.id, p.default_enabled)

    def set_enabled(self, p, on):
        self.config.section("enabled")[p.id] = on
        self.config.save()
        if on and not p.enabled:
            self._start(p)
        elif not on and p.enabled:
            self._stop(p)
        self.changed.emit()

    def _start(self, p):
        try:
            p.on_enable()
            p.enabled = True
        except Exception:
            log.exception("Enable failed: %s", p.id)
            self.osd.show_message(f"{p.name} failed to start", "", sub="See the log in Settings")
            return
        self._bind(p)

    def _stop(self, p):
        for action in p.hotkeys:
            self.hotkeys.unregister(f"{p.id}.{action}")
            self.hotkey_ok.pop(f"{p.id}.{action}", None)
        try:
            p.on_disable()
        except Exception:
            log.exception("Disable failed: %s", p.id)
        p.enabled = False

    # ------------------------------------------------------------ hotkeys
    def combo_for(self, p, action):
        return self.config.section("hotkeys").get(f"{p.id}.{action}", p.hotkeys[action][1])

    def set_combo(self, p, action, combo):
        self.config.section("hotkeys")[f"{p.id}.{action}"] = combo
        self.config.save()
        if p.enabled:
            self._bind(p)
        self.changed.emit()

    def review_combo(self, p, action, combo, parent=None):
        """Called before a hotkey is saved. Warns about clashes; returns True to go ahead."""
        from PySide6.QtWidgets import QMessageBox
        if not combo or combo == self.combo_for(p, action):
            return True
        nice = ui.hotkeys.pretty(combo)
        for q in self.plugins:
            for a, (label, _) in list(q.hotkeys.items()):
                if (q is p and a == action) or self.combo_for(q, a) != combo:
                    continue
                answer = QMessageBox.question(
                    parent, "Hotkey already used",
                    f"{nice} is already used by {q.name} → “{label}”.\n\n"
                    f"Use it here instead? It will be removed from {q.name}.")
                if answer != QMessageBox.Yes:
                    return False
                self.set_combo(q, a, "")
                self.osd.show_message(f"Moved {nice}", "", sub=f"Removed from {q.name} → {label}")
                return True
        if not self.hotkeys.probe(combo):
            QMessageBox.warning(parent, "Hotkey taken",
                                f"{nice} is already used by another program on your PC (or by Windows itself), "
                                f"so it wouldn't work here.\n\nTry a different combination.")
            return False
        return True

    def _bind(self, p):
        for action in list(p.hotkeys):
            self.bind_action(p, action)

    def bind_action(self, p, action):
        """(Re)register one hotkey. Returns True/False, or None when no combo is set."""
        key = f"{p.id}.{action}"
        combo = self.combo_for(p, action)
        if combo:
            self.hotkey_ok[key] = self.hotkeys.register(key, combo)
            return self.hotkey_ok[key]
        self.unbind_action(p, action)
        return None

    def unbind_action(self, p, action):
        key = f"{p.id}.{action}"
        self.hotkeys.unregister(key)
        self.hotkey_ok.pop(key, None)

    def _on_hotkey(self, key):
        pid, _, action = key.partition(".")
        p = self.by_id.get(pid)
        if p and p.enabled:
            try:
                p.on_hotkey(action)
            except Exception:
                log.exception("Hotkey %s failed", key)

    # ------------------------------------------------------------ window & tray
    def show_window(self):
        self.window.showNormal()
        self.window.raise_()
        self.window.activateWindow()

    def _build_tray(self):
        self.tray = QSystemTrayIcon(ui.app_icon(), self)
        self.tray.setToolTip("NexusHub")
        self.menu = QMenu()
        self.menu.aboutToShow.connect(self._fill_tray_menu)
        self.tray.setContextMenu(self.menu)
        self.tray.activated.connect(
            lambda r: self.show_window() if r in (QSystemTrayIcon.Trigger, QSystemTrayIcon.DoubleClick) else None)
        self.tray.show()

    def _fill_tray_menu(self):
        self.menu.clear()
        self.menu.addAction(ui.glyph_icon(""), "Open NexusHub", self.show_window)
        self.menu.addSeparator()
        for p in self.plugins:
            if not p.enabled:
                continue
            try:
                actions = p.tray_actions()
            except Exception:
                actions = []
            for text, cb in actions:
                act = QAction(ui.glyph_icon(p.icon), text, self.menu)
                act.triggered.connect(cb)
                self.menu.addAction(act)
        self.menu.addSeparator()
        self.menu.addAction(ui.glyph_icon("\uE72C"), "Restart NexusHub", self.restart)

    def quit(self):
        # Safety net: if anything below hangs (a stuck driver, an app not answering), still exit.
        import threading
        t = threading.Timer(4.0, lambda: os._exit(0))
        t.daemon = True
        t.start()
        self._mark_clean_exit()   # tells the guardian this was on purpose (don't auto-restart)
        for p in self.plugins:
            if p.enabled:
                self._stop(p)
        self.hotkeys.shutdown()
        self.config.save()
        self.tray.hide()
        self.app.quit()

    # ------------------------------------------------------------ startup
    @staticmethod
    def startup_command():
        exe = sys.executable
        pyw = os.path.join(os.path.dirname(exe), "pythonw.exe")
        if os.path.exists(pyw):
            exe = pyw
        return f'"{exe}" "{os.path.join(ROOT, "NexusHub.pyw")}" --minimized'

    def run_at_startup(self):
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as k:
                winreg.QueryValueEx(k, "NexusHub")
                return True
        except OSError:
            return False

    def set_run_at_startup(self, on):
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as k:
            if on:
                winreg.SetValueEx(k, "NexusHub", 0, winreg.REG_SZ, self.startup_command())
            else:
                try:
                    winreg.DeleteValue(k, "NexusHub")
                except OSError:
                    pass


# ====================================================================== UI
def scroll(widget):
    area = QScrollArea()
    area.setWidgetResizable(True)
    area.setFrameShape(QFrame.NoFrame)
    area.setWidget(widget)
    return area


SECTIONS = [
    ("music", "Music", "", "Spotify, sound effects and volume", ["spotify", "soundboard", "sound"]),
    ("desktop", "Desktop", "", "Your dock, wallpaper, widgets and screen", ["taskbar", "wallpaper", "widgets", "display"]),
    ("gaming", "Gaming", "", "Game Mode, crosshair and PC stats", ["gamemode", "crosshair", "sysmonitor"]),
    ("browser", "Browser", "", "", ["browser"]),
    ("tools", "Tools", "", "Handy extras", None),     # None = everything else (incl. your own modules)
]


def section_plan(hub):
    placed = {pid for *_, pids in SECTIONS if pids for pid in pids}
    out = []
    for key, title, glyph, sub, pids in SECTIONS:
        if pids is None:
            pids = [p.id for p in hub.plugins if p.id not in placed]
        pids = [pid for pid in pids if pid in hub.by_id]
        if pids:
            out.append((key, title, glyph, sub, pids))
    return out


class SectionPage(QWidget):
    """One sidebar section: a pill tab strip of its modules, and the chosen module's page below."""

    def __init__(self, hub, key, title, sub, pids):
        super().__init__(objectName="page")
        self.hub, self.key, self.pids = hub, key, pids
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        self.single = len(pids) == 1
        self.tabs = {}
        if not self.single:
            bar = QWidget()
            bl = QHBoxLayout(bar)
            bl.setContentsMargins(34, 22, 34, 4)
            bl.setSpacing(8)
            head = QVBoxLayout()
            head.setSpacing(0)
            head.addWidget(ui.label(title, "h1"))
            head.addWidget(ui.label(sub, "muted"))
            bl.addLayout(head)
            bl.addSpacing(24)
            group = QButtonGroup(self)
            for pid in pids:
                p = hub.by_id[pid]
                b = QPushButton(f"  {p.name}", checkable=True)
                b.setIcon(ui.glyph_icon(p.icon, "white"))
                b.setCursor(Qt.PointingHandCursor)
                b.clicked.connect(lambda _=False, pid=pid: self.select(pid))
                group.addButton(b)
                bl.addWidget(b)
                self.tabs[pid] = b
            bl.addStretch()
            lay.addWidget(bar)
        self.stack = QStackedWidget()
        self.hosts = {}
        for pid in pids:
            host = PluginHost(hub, hub.by_id[pid])
            self.hosts[pid] = host
            self.stack.addWidget(host)
        lay.addWidget(self.stack, 1)
        self.current = pids[0]
        self.refresh_tabs()
        self.select(pids[0])

    def has_full_page(self):
        return getattr(self.hub.by_id[self.current], "full_page", False)

    def select(self, pid):
        self.current = pid
        self.stack.setCurrentWidget(self.hosts[pid])
        if pid in self.tabs:
            self.tabs[pid].setChecked(True)
        self.refresh_tabs()

    def refresh_tabs(self):
        for pid, b in self.tabs.items():
            on = self.hub.by_id[pid].enabled
            sel = pid == self.current
            b.setStyleSheet(
                "QPushButton { border: none; border-radius: 16px; padding: 8px 16px; font-weight: 600;"
                + (f" background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 {ui.ACCENT}, stop:1 {ui.ACCENT2}); color: white; }}"
                   if sel else f" background: {ui.SURFACE}; color: {ui.TEXT if on else ui.MUTED}; }}"
                               f" QPushButton:hover {{ background: {ui.SURFACE2}; }}"))
            b.setToolTip("" if on else "This one is switched off. Open it to turn it on")


class MainWindow(QMainWindow):
    def __init__(self, hub):
        super().__init__()
        self.hub = hub
        self.setWindowTitle(hub.look().get("app_name") or "NexusHub")
        self.setWindowIcon(ui.app_icon())
        self.resize(1180, 760)
        self.setMinimumSize(980, 620)

        root = QWidget(objectName="root")
        lay = QHBoxLayout(root)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        self.setCentralWidget(root)

        # sidebar
        side = QFrame(objectName="sidebar")
        side.setFixedWidth(232)
        sl = QVBoxLayout(side)
        sl.setContentsMargins(14, 18, 14, 14)
        sl.setSpacing(3)
        logo = QLabel()
        logo.setPixmap(ui.app_icon(30).pixmap(30, 30))
        self.brand = ui.label(hub.look().get("app_name") or "NexusHub", "brand")
        sl.addLayout(ui.hrow(logo, self.brand, None))
        sl.addSpacing(18)

        self.stack = QStackedWidget()
        self.group = QButtonGroup(self)
        self.nav = {}
        self.sections = {}
        self.plugin_section = {}
        self._add_nav(sl, "home", "", "Home", HomePage(hub, self))
        sl.addSpacing(8)
        # a handful of sections instead of 20+ tabs; each section has its modules as tabs inside
        for key, title, glyph, sub, pids in section_plan(hub):
            page = SectionPage(hub, key, title, sub, pids)
            self.sections[key] = page
            for pid in pids:
                self.plugin_section[pid] = key
            self._add_nav(sl, key, glyph, title, page)
        sl.addStretch()
        self.off_hint = ui.label("", "muted")      # kept for compatibility; sections show off modules themselves
        self.off_hint.hide()
        from .account_page import AccountPage
        self._add_nav(sl, "account", "", "Account", AccountPage(hub))
        self.refresh_account_chip()
        self._add_nav(sl, "settings", "", "Settings", SettingsPage(hub))

        lay.addWidget(side)
        lay.addWidget(self.stack, 1)
        self.arrange_tabs()
        hub.changed.connect(self.arrange_tabs)
        start = hub.look().get("start_page", "home")
        self.open_page(start)

    def refresh_account_chip(self):
        """The sidebar's account button: your photo/initial, your name and the profile in use."""
        from .account_page import avatar_pixmap, current_identity, profile_name
        from . import accounts as acc
        sub, name, _ = current_identity()
        b, _ = self.nav["account"]
        prof = profile_name(acc.session()["owner"], acc.session()["profile"])
        b.setText(f"   {name.split(' ')[0][:16]}\n   {prof[:18]} profile")       # two short lines, never cut off
        b.setIcon(avatar_pixmap(sub, name, 64))
        b.setIconSize(QSize(22, 22))
        b.setToolTip(f"{name}, profile “{prof}”. Click to switch profile or sign in")

    def tab_order(self):
        """Module ids in the user's chosen sidebar order (new modules go at the end)."""
        order = [i for i in self.hub.look().get("tab_order", []) if i in self.hub.by_id]
        default = [p.id for p in self.hub.plugins]
        for pid in default:
            if pid in order:
                continue
            # a newly added module: put it after the module that comes before it by default
            prev = default[:default.index(pid)]
            anchor = next((p for p in reversed(prev) if p in order), None)
            order.insert(order.index(anchor) + 1 if anchor else 0, pid)
        return order

    def arrange_tabs(self):
        """Refresh the tab strips inside each section (on/off dots)."""
        for s in self.sections.values():
            s.refresh_tabs()

    def apply_title_colors(self):
        """Windows 11 lets apps colour their own title bar and window border."""
        look = self.hub.look()
        hwnd = int(self.winId())

        def colorref(hex_color):
            c = QColor(hex_color)
            return c.red() | (c.green() << 8) | (c.blue() << 16)
        mode = look.get("titlebar", "theme")
        caption = {"theme": ui.SIDEBAR, "accent": ui.ACCENT, "custom": look.get("titlebar_color", ui.SIDEBAR)}.get(mode, ui.SIDEBAR)
        text = "#000000" if QColor(caption).lightness() > 170 else "#ffffff"
        border = ui.ACCENT if look.get("glow_border", True) else ui.BORDER
        for attr, value in ((35, caption), (36, text), (34, border)):   # DWMWA caption / text / border colour
            v = ctypes.c_int(colorref(value))
            win.dwmapi.DwmSetWindowAttribute(hwnd, attr, ctypes.byref(v), ctypes.sizeof(v))

    def _add_nav(self, layout, key, glyph, text, page):
        b = QPushButton("   " + text, objectName="navButton", checkable=True)
        b.setIcon(ui.glyph_icon(glyph, ui.TEXT))
        b.setIconSize(QSize(16, 16))
        b.setCursor(Qt.PointingHandCursor)
        idx = self.stack.addWidget(page)
        b.clicked.connect(lambda: self._show_index(idx))
        self.group.addButton(b)
        layout.addWidget(b)
        self.nav[key] = (b, idx)

    def open_page(self, key):
        """Open a sidebar section ('home', 'music', 'settings'…) or a module by its id ('spotify')."""
        if key not in self.nav and key in self.plugin_section:
            section = self.plugin_section[key]
            self.sections[section].select(key)
            key = section
        if key not in self.nav:
            key = "home"
        b, idx = self.nav[key]
        b.setChecked(True)
        self._show_index(idx)

    def _show_index(self, idx):
        """Switch page with a quick fade-in (skipped for the browser, which draws with the GPU)."""
        if idx == self.stack.currentIndex():
            return
        self.stack.setCurrentIndex(idx)
        page = self.stack.widget(idx)
        if isinstance(page, SectionPage) and page.has_full_page():
            return        # the browser draws with the GPU and doesn't like fade effects
        eff = QGraphicsOpacityEffect(page)
        page.setGraphicsEffect(eff)
        anim = QPropertyAnimation(eff, b"opacity", page)
        anim.setDuration(170)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.finished.connect(lambda: page.setGraphicsEffect(None))
        anim.start()

    def showEvent(self, e):
        super().showEvent(e)
        win.dark_title_bar(self.winId())
        self.apply_title_colors()

    def closeEvent(self, e):
        # The ✕ never quits NexusHub; use Settings → "Quit NexusHub completely".
        e.ignore()
        self.hide()
        if not self.hub.config.get("tray_hint_shown"):
            self.hub.config.set("tray_hint_shown", True)
            self.hub.osd.show_message("NexusHub is still running", "",
                                      sub="Everything keeps working. Open it again from the Start button or tray.")


class Hero(QWidget):
    """Animated dashboard header: aurora background, clock, live chips and a search pill."""

    def __init__(self, hub):
        super().__init__()
        self.hub = hub
        self.setFixedHeight(210)
        self.t = 0.0
        self.chips = []
        self._anim = QTimer(self, interval=33, timeout=self._step)
        self._data = QTimer(self, interval=1500, timeout=self._collect)
        self.search = QPushButton(self)
        self.search.setCursor(Qt.PointingHandCursor)
        self.search.setFixedSize(300, 42)
        self.search.setStyleSheet(
            "QPushButton { background: rgba(255,255,255,0.09); border: 1px solid rgba(255,255,255,0.16);"
            " border-radius: 21px; color: rgba(255,255,255,0.85); text-align: left; padding-left: 16px; font-size: 13px; }"
            "QPushButton:hover { background: rgba(255,255,255,0.16); }")
        self.search.setIcon(ui.glyph_icon("", "white"))
        self.search.clicked.connect(self._open_bar)
        self._collect()

    def _open_bar(self):
        bar = self.hub.by_id.get("nexusbar")
        if bar and bar.enabled:
            bar.on_hotkey("open")
        else:
            self.hub.osd.show_message("Turn on the Nexus Bar module first", "")

    def showEvent(self, e):
        self._anim.start()
        self._data.start()

    def hideEvent(self, e):
        self._anim.stop()
        self._data.stop()

    def resizeEvent(self, e):
        self.search.move(self.width() - self.search.width() - 26, 26)

    def _step(self):
        self.t += 0.033
        self.update()

    def _collect(self):
        import psutil
        chips = [("", f"CPU {psutil.cpu_percent(None):.0f}%"), ("", f"RAM {psutil.virtual_memory().percent:.0f}%")]
        sp = self.hub.by_id.get("spotify")
        if sp and sp.enabled and sp.track:
            artist, _, song = sp.track.partition(" - ")
            chips.append(("", (song or sp.track)[:34]))
        w = self.hub.by_id.get("widgets")
        if w and w.enabled and getattr(w, "weather", None):
            g = type(w).on_enable.__globals__
            emoji = g["WEATHER"].get(w.weather["code"], ("", g["THERMO"]))[1]
            chips.append((emoji, f"{round(w.weather['temp'])}° {w.weather['city']}"))
        gm = self.hub.by_id.get("gamemode")
        if gm and gm.enabled and gm.active:
            chips.append(("", "Game Mode ON"))
        self.chips = chips
        bar = self.hub.by_id.get("nexusbar")
        combo = self.hub.combo_for(bar, "open") if bar else ""
        self.search.setText(f"   Search anything…        {ui.hotkeys.pretty(combo)}" if combo else "   Search anything…")

    def paintEvent(self, _):
        import math
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect())
        path = QPainterPath()
        path.addRoundedRect(r, 22, 22)
        p.setClipPath(path)
        p.fillRect(r, QColor("#12101f"))
        # drifting colour blobs
        for i, col in enumerate((ui.ACCENT, ui.ACCENT2, "#f472b6", "#34d399")):
            x = r.width() * (0.5 + 0.42 * math.sin(self.t * (0.13 + i * 0.05) + i * 1.9))
            y = r.height() * (0.5 + 0.45 * math.cos(self.t * (0.11 + i * 0.04) + i))
            rad = r.width() * (0.32 + 0.05 * math.sin(self.t * 0.3 + i))
            g = QRadialGradient(QPointF(x, y), rad)
            c = QColor(col)
            c.setAlpha(110 if i < 2 else 60)
            g.setColorAt(0, c)
            c.setAlpha(0)
            g.setColorAt(1, c)
            p.fillRect(r, g)
        p.fillRect(r, QColor(10, 10, 20, 70))
        now = datetime.datetime.now()
        hour = now.hour
        greet = "Good morning" if 5 <= hour < 12 else "Good afternoon" if 12 <= hour < 18 else "Good evening"
        f = QFont(ui.TEXT_FONT)
        f.setPixelSize(15)
        f.setWeight(QFont.DemiBold)
        p.setFont(f)
        p.setPen(QColor(255, 255, 255, 200))
        p.drawText(QRectF(30, 24, 400, 24), Qt.AlignLeft | Qt.AlignVCenter, greet)
        f.setPixelSize(62)
        f.setWeight(QFont.Bold)
        p.setFont(f)
        p.setPen(QColor("white"))
        p.drawText(QRectF(26, 44, 500, 76), Qt.AlignLeft | Qt.AlignVCenter, now.strftime("%H:%M"))
        f.setPixelSize(14)
        f.setWeight(QFont.Normal)
        p.setFont(f)
        p.setPen(QColor(255, 255, 255, 190))
        p.drawText(QRectF(30, 118, 400, 22), Qt.AlignLeft | Qt.AlignVCenter, now.strftime("%A, %d %B %Y"))
        # chips
        x = 30.0
        f.setPixelSize(12)
        f.setWeight(QFont.DemiBold)
        for glyph, text in self.chips:
            p.setFont(f)
            w = p.fontMetrics().horizontalAdvance(text) + 44
            chip = QRectF(x, r.height() - 52, w, 30)
            if chip.right() > r.width() - 20:
                break
            p.setPen(QPen(QColor(255, 255, 255, 40), 1))
            p.setBrush(QColor(0, 0, 0, 70))
            p.drawRoundedRect(chip, 15, 15)
            p.setPen(QColor("white"))
            p.drawText(chip.adjusted(30, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, text)
            if ord(glyph[0]) >= 0xE000:        # icon-font glyph
                p.setFont(ui.icon_font(13))
                p.setPen(QColor(ui.ACCENT2))
            else:                               # emoji (weather)
                ef = QFont("Segoe UI Emoji")
                ef.setPixelSize(13)
                p.setFont(ef)
            p.drawText(QRectF(chip.left() + 8, chip.top(), 20, 30), Qt.AlignCenter, glyph)
            x += w + 8


class QuickTile(QPushButton):
    """A big on/off tile for the things you flip most often."""

    def __init__(self, glyph, text):
        super().__init__()
        self.glyph, self.text_ = glyph, text
        self.on = False
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(86)

    def set_on(self, on):
        if on != self.on:
            self.on = on
            self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        if self.on:
            from PySide6.QtGui import QLinearGradient
            g = QLinearGradient(r.topLeft(), r.bottomRight())
            g.setColorAt(0, QColor(ui.ACCENT))
            g.setColorAt(1, QColor(ui.ACCENT2))
            p.setBrush(g)
            p.setPen(Qt.NoPen)
        else:
            p.setBrush(QColor(ui.SURFACE2 if self.underMouse() else ui.SURFACE))
            p.setPen(QPen(QColor(ui.BORDER), 1))
        p.drawRoundedRect(r, 16, 16)
        p.setFont(ui.icon_font(20))
        p.setPen(QColor("white" if self.on else ui.TEXT))
        p.drawText(QRectF(r.left() + 16, r.top() + 12, 28, 28), Qt.AlignCenter, self.glyph)
        f = QFont(ui.TEXT_FONT)
        f.setPixelSize(13)
        f.setWeight(QFont.DemiBold)
        p.setFont(f)
        p.drawText(QRectF(r.left() + 16, r.bottom() - 36, r.width() - 24, 18), Qt.AlignLeft, self.text_)
        f.setPixelSize(11)
        f.setWeight(QFont.Normal)
        p.setFont(f)
        p.setPen(QColor(255, 255, 255, 200) if self.on else QColor(ui.MUTED))
        p.drawText(QRectF(r.left() + 16, r.bottom() - 19, r.width() - 24, 16), Qt.AlignLeft, "On" if self.on else "Off")


class HomePage(QWidget):
    """Simple home: clock header, quick switches, and every module on one compact list."""

    QUICK = [
        # (glyph, label, module id, is_on(plugin), toggle(plugin))
        ("", "Nexus Dock", "taskbar", None, None),
        ("", "Live wallpaper", "wallpaper", lambda p: bool(p.surfaces), lambda p: p.on_hotkey("toggle")),
        ("", "Widgets", "widgets", lambda p: bool(p.shown), lambda p: p.on_hotkey("toggle")),
        ("", "Game mode", "gamemode", lambda p: p.active, lambda p: p.on_hotkey("toggle")),
        ("", "Night filter", "display", lambda p: bool(p.setting("night", False)), lambda p: p.on_hotkey("night")),
        ("", "Keep awake", "keepawake", lambda p: p.active, lambda p: p.on_hotkey("toggle")),
    ]

    def __init__(self, hub, window):
        super().__init__(objectName="page")
        self.hub, self.window = hub, window
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        body = QWidget()
        lay = QVBoxLayout(body)
        lay.setContentsMargins(34, 26, 34, 30)
        lay.setSpacing(10)
        self.hero = Hero(hub)
        lay.addWidget(self.hero)
        lay.addSpacing(8)

        lay.addWidget(ui.label("Quick switches", "h2"))
        qgrid = QGridLayout()
        qgrid.setSpacing(10)
        self.quick = []
        n = 0
        for glyph, text, pid, is_on, toggle in self.QUICK:
            if pid not in hub.by_id:
                continue
            t = QuickTile(glyph, text)
            t.clicked.connect(lambda _=False, pid=pid, toggle=toggle: self._flip(pid, toggle))
            qgrid.addWidget(t, 0, n)
            self.quick.append((t, pid, is_on))
            n += 1
        lay.addLayout(qgrid)
        lay.addSpacing(10)

        lay.addWidget(ui.label("Everything", "h2"))
        lay.addWidget(ui.label("Switch things on or off, or click a name to open it.", "muted"))
        self.rows = []
        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(6)
        col_count = 3
        row = 0
        for key, title, glyph, sub, pids in section_plan(hub):
            head = ui.hrow(ui.glyph_label(glyph, 14, ui.ACCENT2), ui.label(title.upper(), "muted"), None)
            grid.addLayout(head, row, 0, 1, col_count)
            row += 1
            for i, pid in enumerate(pids):
                grid.addWidget(self._module_row(hub.by_id[pid]), row + i // col_count, i % col_count)
            row += (len(pids) + col_count - 1) // col_count
        for c in range(col_count):
            grid.setColumnStretch(c, 1)
        lay.addLayout(grid)

        if hub.load_errors:
            err = ui.Card("Some modules failed to load", "")
            for fname, tb in hub.load_errors:
                err.add(ui.label(f"{fname}: {tb.strip().splitlines()[-1]}", "muted", wrap=True))
            lay.addWidget(err)
        lay.addStretch()
        outer.addWidget(scroll(body))
        hub.changed.connect(self.refresh)
        hub.tick.connect(self.refresh)
        self.refresh()

    def _module_row(self, p):
        w = QFrame(objectName="modrow")
        w.setStyleSheet(f"#modrow {{ background: {ui.SURFACE}; border: 1px solid {ui.BORDER}; border-radius: 12px; }}"
                        f"#modrow:hover {{ border-color: {ui.rgba(ui.ACCENT, 0.5)}; }}")
        h = QHBoxLayout(w)
        h.setContentsMargins(12, 8, 10, 8)
        h.setSpacing(10)
        h.addWidget(ui.glyph_label(p.icon, 15, ui.ACCENT2))
        name = QPushButton(p.name)
        name.setCursor(Qt.PointingHandCursor)
        name.setStyleSheet("QPushButton { background: transparent; border: none; text-align: left; font-weight: 600; padding: 0; }"
                           f"QPushButton:hover {{ color: {ui.ACCENT2}; }}")
        name.setToolTip(p.description)
        name.clicked.connect(lambda _=False, p=p: self.window.open_page(p.id))
        h.addWidget(name, 1)
        sw = ui.ToggleSwitch(p.enabled)
        sw.toggled.connect(lambda on, p=p: self.hub.set_enabled(p, on))
        h.addWidget(sw)
        self.rows.append((p, sw))
        return w

    def _flip(self, pid, toggle):
        p = self.hub.by_id[pid]
        if toggle is None:                     # a whole module (e.g. the dock)
            self.hub.set_enabled(p, not p.enabled)
        else:
            if not p.enabled:
                self.hub.set_enabled(p, True)
            toggle(p)
        QTimer.singleShot(250, self.refresh)

    def refresh(self):
        if not self.isVisible() and self.rows and self.rows[0][1].isChecked() == self.rows[0][0].enabled:
            return
        for t, pid, is_on in self.quick:
            p = self.hub.by_id[pid]
            try:
                on = p.enabled if is_on is None else (p.enabled and bool(is_on(p)))
            except Exception:
                on = False
            t.set_on(on)
        for p, sw in self.rows:
            if sw.isChecked() != p.enabled:
                sw.blockSignals(True)
                sw.setChecked(p.enabled)
                sw.blockSignals(False)


class PluginHost(QWidget):
    """Header + the plugin's own page, or an 'off' placeholder."""

    def __init__(self, hub, plugin):
        super().__init__(objectName="page")
        self.hub, self.p = hub, plugin
        lay = QVBoxLayout(self)
        lay.setContentsMargins(34, 14, 34, 0)
        lay.setSpacing(16)

        head = QHBoxLayout()
        head.setSpacing(14)
        bubble = ui.glyph_label(plugin.icon, 20, "white")
        bubble.setFixedSize(46, 46)
        bubble.setStyleSheet(f"background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 {ui.ACCENT}, stop:1 {ui.ACCENT2});"
                             "border-radius: 14px; color: white;" + f'font-family:"{ui.icon_font().family()}"; font-size:20px;')
        head.addWidget(bubble)
        col = QVBoxLayout()
        col.setSpacing(2)
        col.addWidget(ui.label(plugin.name, "h1"))
        col.addWidget(ui.label(plugin.description, "muted", wrap=True))
        head.addLayout(col, 1)
        self.toggle = ui.ToggleSwitch(plugin.enabled)
        self.toggle.toggled.connect(lambda on: hub.set_enabled(plugin, on))
        head.addWidget(self.toggle)
        if getattr(plugin, "full_page", False):
            # full-page modules (the browser) have their own toolbar: skip the big header
            lay.setContentsMargins(0, 0, 0, 0)
            lay.setSpacing(0)
            for w in (bubble, self.toggle):
                w.hide()
            col.itemAt(0).widget().hide()
            col.itemAt(1).widget().hide()
        else:
            lay.addLayout(head)

        self.stack = QStackedWidget()
        off = QWidget()
        ol = QVBoxLayout(off)
        ol.addStretch()
        ol.addWidget(ui.glyph_label("", 36, ui.MUTED))
        msg = ui.label("This module is turned off", "h2")
        msg.setAlignment(Qt.AlignCenter)
        ol.addWidget(msg)
        btn = ui.button("Turn on", "primary", on_click=lambda: hub.set_enabled(plugin, True))
        ol.addLayout(ui.hrow(None, btn, None))
        ol.addStretch()
        self.stack.addWidget(off)
        self._page_added = False
        lay.addWidget(self.stack, 1)
        hub.changed.connect(self.refresh)
        self.refresh()

    def showEvent(self, e):
        super().showEvent(e)
        self.refresh()

    def refresh(self):
        self.toggle.blockSignals(True)
        self.toggle.setChecked(self.p.enabled)
        self.toggle.blockSignals(False)
        if self.p.enabled and not self._page_added and self.isVisible():   # build pages lazily
            # mark first: adding a page (e.g. the browser's web view) can fire showEvent -> refresh again,
            # which used to add the page a second time and leave the stack pointing at a broken slot
            self._page_added = True
            page = None
            try:
                page = self.p.page()
            except Exception:
                log.exception("Page failed: %s", self.p.id)
            if page is None:
                page = ui.label("This module has no settings page.", "muted")
            if getattr(self.p, "full_page", False):
                # e.g. the browser: fills the whole area, no scrolling wrapper
                self._content = page
            else:
                body = QWidget()
                bl = QVBoxLayout(body)
                bl.setContentsMargins(0, 0, 6, 28)
                bl.addWidget(page)
                bl.addStretch()
                self._content = scroll(body)
            if self.stack.indexOf(self._content) == -1:
                self.stack.addWidget(self._content)
        content = getattr(self, "_content", None)
        if self.p.enabled and content is not None:
            self.stack.setCurrentWidget(content)
        else:
            self.stack.setCurrentIndex(0)


class SettingsPage(QWidget):
    def __init__(self, hub):
        super().__init__(objectName="page")
        self.hub = hub
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        body = QWidget()
        lay = QVBoxLayout(body)
        lay.setContentsMargins(34, 30, 34, 30)
        lay.setSpacing(16)
        lay.addWidget(ui.label("Settings", "h1"))

        general = ui.Card("General", "")
        startup = ui.ToggleSwitch(hub.run_at_startup())
        startup.toggled.connect(hub.set_run_at_startup)
        general.add(self._row("Start with Windows", "Launch quietly into the tray when you sign in.", startup))
        alive = ui.ToggleSwitch(hub.config.get("keep_alive", True))
        alive.toggled.connect(lambda on: hub.config.set("keep_alive", on))
        general.add(self._row("Keep NexusHub running",
                              "The ✕ button only hides the window. If NexusHub is closed from Task Manager or crashes, "
                              "it starts again by itself, and your Windows taskbar always comes back.", alive))
        quit_btn = ui.button("Quit NexusHub completely…", "danger", "", hub.ask_quit)
        general.add(ui.hrow(None, quit_btn))
        lay.addWidget(general)
        lay.addWidget(self._appearance_card())

        keys = ui.Card("Hotkeys", "")
        keys.add(ui.label("Click a box and press a new combo. Backspace clears it. These work everywhere, even in games "
                          "(unless the game blocks them).", "muted", wrap=True))
        self.warns = []
        self.edits = []
        for p in hub.plugins:
            static = type(p).hotkeys   # per-item hotkeys (favourites, pads…) live on the module's own page
            if not static:
                continue
            keys.lay.addSpacing(6)
            keys.add(ui.hrow(ui.glyph_label(p.icon, 14, ui.ACCENT2), ui.label(p.name, "h2"), None))
            for action, (text, default) in static.items():
                edit = ui.HotkeyEdit(hub.combo_for(p, action))
                edit.reviewer = lambda c, p=p, a=action: hub.review_combo(p, a, c, self.window())
                edit.changed.connect(lambda c, p=p, a=action: hub.set_combo(p, a, c))
                self.edits.append((p, action, edit))
                warn = ui.label("", None)
                warn.setStyleSheet(f"color:{ui.WARN}; font-size:12px;")
                reset = ui.button("", "ghost", "")
                reset.setToolTip(f"Reset to {default or 'none'}")
                reset.clicked.connect(lambda _=False, p=p, a=action, d=default, e=edit: (e.set_combo(d), hub.set_combo(p, a, d)))
                keys.add(ui.hrow(ui.label(text), None, warn, edit, reset))
                self.warns.append((f"{p.id}.{action}", warn, p))
        lay.addWidget(keys)

        about = ui.Card("Files", "")
        about.add(ui.label(f"Settings live in {APP_DIR}", "muted", wrap=True))
        about.add(ui.hrow(
            ui.button("Open plugins folder", None, "", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(PLUGIN_DIR))),
            ui.button("Open settings folder", None, "", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(APP_DIR))),
            ui.button("View log", None, "", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(LOG_PATH))),
            None))
        lay.addWidget(about)
        lay.addStretch()
        outer.addWidget(scroll(body))
        hub.changed.connect(self.refresh)
        self.refresh()

    # ------------------------------------------------------------ appearance
    def _appearance_card(self):
        hub = self.hub
        look = hub.look()
        card = ui.Card("Appearance", "")

        # theme swatches
        card.add(ui.label("Colour theme", "h2"))
        grid = QGridLayout()
        grid.setSpacing(8)
        current = look.get("theme", "Nexus Violet") if not look.get("custom_colors") else ""
        for i, (name, (a, b)) in enumerate(ui.THEMES.items()):
            btn = QPushButton(name)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setMinimumHeight(46)
            sel = name == current
            btn.setStyleSheet(
                f"QPushButton {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 {a}, stop:1 {b}); color: white;"
                f" font-weight: 700; border-radius: 12px; border: {'3px solid white' if sel else '1px solid rgba(255,255,255,0.15)'}; }}"
                "QPushButton:hover { border: 2px solid rgba(255,255,255,0.7); }")
            btn.clicked.connect(lambda _=False, n=name: self._set_theme(n, None))
            grid.addWidget(btn, i // 4, i % 4)
        card.add(grid)
        card.add(ui.hrow(ui.button("Custom colours…", None, "", self._custom_theme), None,
                         ui.label("Themes apply after a quick restart (about 2 seconds).", "muted")))

        # window title bar (Windows 11)
        card.lay.addSpacing(6)
        card.add(ui.label("Window title bar", "h2"))
        tb = QComboBox()
        for text, v in (("Match the sidebar", "theme"), ("Accent colour", "accent"), ("Custom colour", "custom")):
            tb.addItem(text, v)
        tb.setCurrentIndex(max(0, tb.findData(look.get("titlebar", "theme"))))

        def tb_changed(_):
            if tb.currentData() == "custom":
                c = QColorDialog.getColor(QColor(look.get("titlebar_color", ui.SIDEBAR)), None, "Title bar colour")
                if c.isValid():
                    hub.set_look("titlebar_color", c.name())
            hub.set_look("titlebar", tb.currentData())
            hub.window.apply_title_colors()
        tb.currentIndexChanged.connect(tb_changed)
        card.add(ui.hrow(ui.label("Colour"), None, tb))
        glow = ui.ToggleSwitch(look.get("glow_border", True))
        glow.toggled.connect(lambda on: (hub.set_look("glow_border", on), hub.window.apply_title_colors()))
        card.add(ui.hrow(ui.label("Glowing accent-coloured window border"), None, glow))

        name = QLineEdit(text=look.get("app_name", ""), placeholderText="NexusHub")
        name.setMaxLength(24)
        name.setFixedWidth(220)

        def rename():
            text = name.text().strip()
            hub.set_look("app_name", text)
            hub.window.setWindowTitle(text or "NexusHub")
            hub.window.brand.setText(text or "NexusHub")
            hub.tray.setToolTip(text or "NexusHub")
        name.editingFinished.connect(rename)
        card.add(ui.hrow(ui.label("App name (window title, sidebar and tray)"), None, name))

        start = QComboBox()
        start.addItem("Home", "home")
        for p in hub.plugins:
            start.addItem(p.name, p.id)
        start.setCurrentIndex(max(0, start.findData(look.get("start_page", "home"))))
        start.currentIndexChanged.connect(lambda _: hub.set_look("start_page", start.currentData()))
        card.add(ui.hrow(ui.label("Open on this page"), None, start))
        return card

    def _set_theme(self, name, custom):
        self.hub.set_look("theme", name)
        self.hub.set_look("custom_colors", list(custom) if custom else None)
        self.hub.osd.show_message(f"Theme: {name}", "", sub="Restarting to apply…")
        QTimer.singleShot(700, self.hub.restart)

    def _custom_theme(self):
        a = QColorDialog.getColor(QColor(ui.ACCENT), None, "Main accent colour")
        if not a.isValid():
            return
        b = QColorDialog.getColor(QColor(ui.ACCENT2), None, "Second accent colour (for gradients)")
        if not b.isValid():
            return
        self._set_theme("Custom", (a.name(), b.name()))

    def _tabs_card(self):
        card = ui.Card("Sidebar tabs", "")
        card.add(ui.label("Reorder your tabs and choose which ones show. Modules you switch off are always hidden; "
                          "turn them back on from Home.", "muted", wrap=True))
        self.tab_box = QVBoxLayout()
        self.tab_box.setSpacing(4)
        card.add(self.tab_box)
        card.add(ui.hrow(None, ui.button("Reset order", "ghost", "",
                                         lambda: (self.hub.set_look("tab_order", []), self.hub.set_look("hidden_tabs", []),
                                                  self._fill_tabs(), self.hub.window.arrange_tabs()))))
        self._fill_tabs()
        self.hub.changed.connect(self._fill_tabs)
        return card

    def _fill_tabs(self):
        while self.tab_box.count():
            w = self.tab_box.takeAt(0).widget()
            if w:
                w.deleteLater()
        order = self.hub.window.tab_order() if hasattr(self.hub, "window") else [p.id for p in self.hub.plugins]
        hidden = set(self.hub.look().get("hidden_tabs", []))
        for i, pid in enumerate(order):
            p = self.hub.by_id[pid]
            row = QFrame()
            row.setStyleSheet(f"QFrame {{ background:{ui.SURFACE2}; border-radius:9px; }}")
            rl = QHBoxLayout(row)
            rl.setContentsMargins(10, 4, 8, 4)
            rl.addWidget(ui.glyph_label(p.icon, 14, ui.ACCENT2 if p.enabled else ui.MUTED))
            rl.addWidget(ui.label(p.name + ("" if p.enabled else "   (off)")), 1)
            up = ui.button("", "ghost", "", lambda _=False, i=i: self._move_tab(i, -1))
            down = ui.button("", "ghost", "", lambda _=False, i=i: self._move_tab(i, 1))
            up.setEnabled(i > 0)
            down.setEnabled(i < len(order) - 1)
            show = ui.ToggleSwitch(pid not in hidden)
            show.setToolTip("Show in sidebar")
            show.toggled.connect(lambda on, pid=pid: self._set_hidden(pid, not on))
            for w in (up, down, show):
                rl.addWidget(w)
            self.tab_box.addWidget(row)

    def _move_tab(self, i, delta):
        order = self.hub.window.tab_order()
        j = i + delta
        if 0 <= j < len(order):
            order[i], order[j] = order[j], order[i]
            self.hub.set_look("tab_order", order)
            self.hub.window.arrange_tabs()
            self._fill_tabs()

    def _set_hidden(self, pid, hide):
        hidden = set(self.hub.look().get("hidden_tabs", []))
        (hidden.add if hide else hidden.discard)(pid)
        self.hub.set_look("hidden_tabs", sorted(hidden))
        self.hub.window.arrange_tabs()

    @staticmethod
    def _row(title, sub, control):
        col = QVBoxLayout()
        col.setSpacing(1)
        col.addWidget(ui.label(title))
        col.addWidget(ui.label(sub, "muted", wrap=True))
        row = QHBoxLayout()
        row.addLayout(col, 1)
        row.addWidget(control)
        w = QWidget()
        w.setLayout(row)
        row.setContentsMargins(0, 4, 0, 4)
        return w

    def refresh(self):
        for key, warn, p in self.warns:
            ok = self.hub.hotkey_ok.get(key)
            warn.setText("Taken by another app" if p.enabled and ok is False else "")
        # a combo may have been moved away from another action: keep every box showing the truth
        for p, action, edit in getattr(self, "edits", []):
            combo = self.hub.combo_for(p, action)
            if edit.combo != combo and not edit.hasFocus():
                edit.set_combo(combo)
