"""Wi-Fi: list networks, connect (with a password for new ones), disconnect. Uses Windows' own netsh + WLAN API."""
import ctypes
import os
import re
import subprocess
import tempfile
from ctypes import wintypes
from xml.sax.saxutils import escape

NO_WINDOW = 0x08000000


def _netsh(*args):
    r = subprocess.run(["netsh", "wlan", *args], capture_output=True, text=True, creationflags=NO_WINDOW,
                       errors="replace")
    return r.returncode, r.stdout + r.stderr


def _fields(block):
    out = {}
    for line in block.splitlines():
        if ":" in line:
            k, _, v = line.partition(":")
            out.setdefault(k.strip().lower(), v.strip())
    return out


def status():
    """Current connection: {'state', 'ssid', 'signal', 'rate', 'band', 'interface', 'guid'} (empty if no Wi-Fi)."""
    code, out = _netsh("show", "interfaces")
    if "name" not in out.lower():
        return {}
    f = _fields(out)
    sig = re.search(r"(\d+)", f.get("signal", ""))
    return {"state": f.get("state", ""), "ssid": f.get("ssid", ""), "signal": int(sig.group(1)) if sig else 0,
            "rate": f.get("receive rate (mbps)", ""), "band": f.get("band", ""), "interface": f.get("name", "Wi-Fi"),
            "guid": f.get("guid", "")}


def saved_profiles():
    code, out = _netsh("show", "profiles")
    return [m.group(1).strip() for m in re.finditer(r"All User Profile\s*:\s*(.+)", out)] + \
           [m.group(1).strip() for m in re.finditer(r"Current User Profile\s*:\s*(.+)", out)]


def networks():
    """[{'ssid', 'signal', 'auth', 'secure', 'saved', 'connected', 'band'}] strongest first."""
    code, out = _netsh("show", "networks", "mode=bssid")
    cur = status().get("ssid", "")
    saved = set(saved_profiles())
    nets = {}
    for block in re.split(r"\n(?=SSID \d+ :)", out):
        m = re.match(r"SSID \d+ :\s*(.*)", block.strip())
        if not m:
            continue
        ssid = m.group(1).strip()
        if not ssid:
            continue      # hidden networks
        f = _fields(block)
        signals = [int(s) for s in re.findall(r"Signal\s*:\s*(\d+)%", block)]
        bands = re.findall(r"Band\s*:\s*([\d.]+ GHz)", block)
        auth = f.get("authentication", "")
        n = {"ssid": ssid, "signal": max(signals) if signals else 0, "auth": auth,
             "secure": auth.lower() not in ("open", ""), "saved": ssid in saved, "connected": ssid == cur,
             "band": " / ".join(sorted(set(bands)))}
        if ssid not in nets or n["signal"] > nets[ssid]["signal"]:
            nets[ssid] = n
    return sorted(nets.values(), key=lambda n: (not n["connected"], -n["signal"]))


def scan():
    """Ask the Wi-Fi adapter for a fresh scan (results appear a few seconds later)."""
    try:
        from comtypes import GUID
        wlan = ctypes.WinDLL("wlanapi")
        handle = wintypes.HANDLE()
        ver = wintypes.DWORD()
        if wlan.WlanOpenHandle(2, None, ctypes.byref(ver), ctypes.byref(handle)) != 0:
            return False
        try:
            guid = status().get("guid")
            if not guid:
                return False
            g = GUID("{" + guid.strip("{}") + "}")
            return wlan.WlanScan(handle, ctypes.byref(g), None, None, None) == 0
        finally:
            wlan.WlanCloseHandle(handle, None)
    except Exception:
        return False


def connect(ssid, password=None, auth="WPA2-Personal"):
    """Connect; for a new secured network a profile is created with `password`. Returns (ok, message)."""
    iface = status().get("interface", "Wi-Fi")
    if ssid not in saved_profiles():
        if password is None and auth.lower() != "open":
            return False, "password needed"
        xml = _profile_xml(ssid, password, auth)
        fd, path = tempfile.mkstemp(suffix=".xml")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(xml)
            code, out = _netsh("add", "profile", f"filename={path}", f"interface={iface}", "user=current")
        finally:
            try:
                os.remove(path)     # it contained the password: never leave it on disk
            except OSError:
                pass
        if code != 0:
            return False, "Windows couldn't save that network"
    code, out = _netsh("connect", f"name={ssid}", f"ssid={ssid}", f"interface={iface}")
    return code == 0, ("Connecting…" if code == 0 else out.strip().splitlines()[-1] if out.strip() else "Couldn't connect")


def forget(ssid):
    code, _ = _netsh("delete", "profile", f"name={ssid}")
    return code == 0


def disconnect():
    code, _ = _netsh("disconnect")
    return code == 0


def _profile_xml(ssid, password, auth):
    a = auth.lower()
    if a == "open":
        auth_x, enc, key = "open", "none", ""
    else:
        auth_x = "WPA3SAE" if "wpa3" in a else ("WPA2PSK" if "wpa2" in a else "WPAPSK")
        enc = "AES"
        key = (f"<sharedKey><keyType>passPhrase</keyType><protected>false</protected>"
               f"<keyMaterial>{escape(password or '')}</keyMaterial></sharedKey>")
    hex_ssid = ssid.encode("utf-8").hex().upper()
    return f"""<?xml version="1.0"?>
<WLANProfile xmlns="http://www.microsoft.com/networking/WLAN/profile/v1">
  <name>{escape(ssid)}</name>
  <SSIDConfig><SSID><hex>{hex_ssid}</hex><name>{escape(ssid)}</name></SSID></SSIDConfig>
  <connectionType>ESS</connectionType>
  <connectionMode>auto</connectionMode>
  <MSM><security>
    <authEncryption><authentication>{auth_x}</authentication><encryption>{enc}</encryption><useOneX>false</useOneX></authEncryption>
    {key}
  </security></MSM>
</WLANProfile>"""
