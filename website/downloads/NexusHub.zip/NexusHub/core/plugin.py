"""Base class for NexusHub modules.

Drop a .py file in the `plugins` folder containing a Plugin subclass and it
shows up in the hub automatically.  See plugins/_TEMPLATE.py.
"""
from PySide6.QtCore import QObject


class Plugin(QObject):
    # --- metadata (override these) ---
    id = ""                 # unique, lowercase, e.g. "spotify"
    name = "Unnamed"
    icon = ""         # a Segoe Fluent Icons glyph
    description = ""
    category = "Tools"
    default_enabled = True
    order = 100             # position in the sidebar
    # action -> (label, default combo); users can rebind these in Settings
    hotkeys = {}

    def __init__(self, hub):
        super().__init__()
        self.hub = hub
        self.enabled = False
        self._page = None
        # per-instance copy, so a module can add hotkeys at runtime (see add_hotkey)
        self.hotkeys = dict(type(self).hotkeys)

    # --- lifecycle hooks (override what you need) ---
    def on_enable(self):
        """Start background work (timers, threads)."""

    def on_disable(self):
        """Stop everything started in on_enable."""

    def on_hotkey(self, action):
        """Called when one of `hotkeys` fires, in the GUI thread."""

    def create_page(self):
        """Return the QWidget shown when this module is opened."""
        return None

    def tray_actions(self):
        """[(label, callback), ...] added to the tray menu while enabled."""
        return []

    def status(self):
        """Short text shown on the Home card, e.g. 'Playing: …'."""
        return ""

    # --- helpers ---
    @property
    def settings(self):
        return self.hub.config.section("plugin." + self.id)

    def setting(self, key, default=None):
        return self.settings.get(key, default)

    def set_setting(self, key, value):
        self.settings[key] = value
        self.hub.config.save()

    def notify(self, text, glyph=None):
        """Show the on-screen popup."""
        self.hub.osd.show_message(text, glyph or self.icon)

    def add_hotkey(self, action, label, default=""):
        """Add (or relabel) a hotkey while running, e.g. one per favourite."""
        self.hotkeys[action] = (label, default)
        if self.enabled:
            self.hub.bind_action(self, action)

    def hotkey_editor(self, action):
        """A ready-wired hotkey box for one action (warns if another app owns the combo)."""
        from . import ui
        edit = ui.HotkeyEdit(self.hub.combo_for(self, action))
        edit.reviewer = lambda combo: self.hub.review_combo(self, action, combo, edit.window())

        def changed(combo):
            self.hub.set_combo(self, action, combo)
            if combo and self.hub.hotkey_ok.get(f"{self.id}.{action}") is False:
                self.notify("That hotkey is taken by another app", "")

        edit.changed.connect(changed)
        return edit

    def remove_hotkey(self, action):
        self.hub.unbind_action(self, action)
        self.hotkeys.pop(action, None)
        self.hub.config.section("hotkeys").pop(f"{self.id}.{action}", None)
        self.hub.config.save()

    def page(self):
        if self._page is None:
            self._page = self.create_page()
        return self._page
