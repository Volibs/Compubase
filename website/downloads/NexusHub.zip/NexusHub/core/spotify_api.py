"""Minimal Spotify Web API client (PKCE login, no client secret needed).

Everything here blocks, so call it from a background thread.
"""
import base64
import hashlib
import http.server
import json
import re
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser

REDIRECT = "http://127.0.0.1:8888/callback"
SCOPES = ("user-modify-playback-state user-read-playback-state user-read-currently-playing "
          "user-library-modify user-library-read")
API = "https://api.spotify.com/v1"
LINK_RE = re.compile(r"(track|album|playlist|artist|episode|show)[/:]([A-Za-z0-9]{22})")


def parse_link(text):
    """'https://open.spotify.com/intl-de/album/ID?si=…' or 'spotify:album:ID' -> 'spotify:album:ID'."""
    m = LINK_RE.search(text or "")
    return f"spotify:{m.group(1)}:{m.group(2)}" if m else None


def oembed(uri):
    """Public name + cover art URL for a Spotify item (no login needed)."""
    _, kind, sid = uri.split(":")
    url = "https://open.spotify.com/oembed?url=" + urllib.parse.quote(f"https://open.spotify.com/{kind}/{sid}")
    req = urllib.request.Request(url, headers={"User-Agent": "NexusHub"})
    with urllib.request.urlopen(req, timeout=10) as r:
        data = json.loads(r.read())
    return data.get("title", ""), data.get("thumbnail_url", "")


class SpotifyError(Exception):
    pass


class SpotifyAPI:
    def __init__(self, store, save):
        self.store = store          # dict persisted in config
        self.save = save
        self._lock = threading.Lock()

    @property
    def connected(self):
        return bool(self.store.get("client_id") and self.store.get("refresh_token"))

    def disconnect(self):
        for k in ("refresh_token", "access_token", "expires", "user"):
            self.store.pop(k, None)
        self.save()

    # ------------------------------------------------------------ login
    def login(self, client_id, timeout=180):
        """Opens the browser, waits for Spotify to redirect back. Returns the display name."""
        verifier = secrets.token_urlsafe(64)[:100]
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
        state = secrets.token_urlsafe(16)
        result = {}

        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                ok = q.get("state", [""])[0] == state and "code" in q
                if ok:
                    result["code"] = q["code"][0]
                else:
                    result["error"] = q.get("error", ["cancelled"])[0]
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                msg = "Connected! You can close this tab and go back to NexusHub." if ok else "Login failed. You can close this tab."
                self.wfile.write(f"<html><body style='font-family:Segoe UI;background:#0d0f14;color:#e8ebf2;"
                                 f"display:grid;place-items:center;height:95vh'><h2>{msg}</h2></body></html>".encode())

            def log_message(self, *a):
                pass

        server = http.server.HTTPServer(("127.0.0.1", 8888), Handler)
        server.timeout = 1
        webbrowser.open("https://accounts.spotify.com/authorize?" + urllib.parse.urlencode({
            "client_id": client_id, "response_type": "code", "redirect_uri": REDIRECT, "scope": SCOPES,
            "code_challenge_method": "S256", "code_challenge": challenge, "state": state}))
        end = time.time() + timeout
        try:
            while not result and time.time() < end:
                server.handle_request()
        finally:
            server.server_close()
        if "code" not in result:
            raise SpotifyError(f"Login didn't finish ({result.get('error', 'timed out')})")
        tok = self._token_request({"grant_type": "authorization_code", "code": result["code"],
                                   "redirect_uri": REDIRECT, "client_id": client_id, "code_verifier": verifier})
        self.store["client_id"] = client_id
        self._save_token(tok)
        me = self.call("GET", "/me")[1] or {}
        self.store["user"] = me.get("display_name") or me.get("id", "")
        self.save()
        return self.store["user"]

    def _token_request(self, fields):
        req = urllib.request.Request("https://accounts.spotify.com/api/token",
                                     data=urllib.parse.urlencode(fields).encode(),
                                     headers={"Content-Type": "application/x-www-form-urlencoded"})
        try:
            with urllib.request.urlopen(req, timeout=15) as r:
                return json.loads(r.read())
        except urllib.error.HTTPError as e:
            raise SpotifyError(f"Spotify refused the login ({e.code}). Check the Client ID and redirect URI.")

    def _save_token(self, tok):
        self.store["access_token"] = tok["access_token"]
        self.store["expires"] = time.time() + tok.get("expires_in", 3600) - 60
        if tok.get("refresh_token"):
            self.store["refresh_token"] = tok["refresh_token"]
        self.save()

    def _access_token(self):
        with self._lock:
            if not self.connected:
                raise SpotifyError("Spotify isn't connected")
            if time.time() >= self.store.get("expires", 0):
                self._save_token(self._token_request({
                    "grant_type": "refresh_token", "refresh_token": self.store["refresh_token"],
                    "client_id": self.store["client_id"]}))
            return self.store["access_token"]

    # ------------------------------------------------------------ calls
    def call(self, method, path, body=None, query=None):
        url = API + path + ("?" + urllib.parse.urlencode(query) if query else "")
        data = json.dumps(body).encode() if body is not None else (b"" if method in ("PUT", "POST") else None)
        req = urllib.request.Request(url, data=data, method=method, headers={
            "Authorization": "Bearer " + self._access_token(), "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=15) as r:
                raw = r.read()
                return r.status, (json.loads(raw) if raw else None)
        except urllib.error.HTTPError as e:
            raw = e.read()
            try:
                return e.code, json.loads(raw)
            except ValueError:
                return e.code, None

    def _device_query(self):
        """Pick a device when Spotify says nothing is active (prefers this PC)."""
        _, data = self.call("GET", "/me/player/devices")
        devices = (data or {}).get("devices", [])
        if not devices:
            raise SpotifyError("Open Spotify first")
        dev = next((d for d in devices if d.get("type") == "Computer"), devices[0])
        return {"device_id": dev["id"]}

    def _player(self, method, path, body=None, query=None):
        status, data = self.call(method, path, body, query)
        if status == 404:
            status, data = self.call(method, path, body, {**(query or {}), **self._device_query()})
        if status == 403:
            raise SpotifyError("Spotify says no (Premium is needed for remote control)")
        if status >= 400:
            msg = ((data or {}).get("error") or {}).get("message", f"error {status}")
            raise SpotifyError(f"Spotify: {msg}")
        return data

    def play_uri(self, uri, shuffle=False):
        _, kind, sid = uri.split(":")
        if kind in ("track", "episode"):
            self._player("PUT", "/me/player/play", {"uris": [uri]})
            return
        body = {"context_uri": uri}
        if shuffle and kind in ("album", "playlist"):
            # start from a random song, and leave shuffle on for the rest
            total = 0
            if kind == "album":
                status, data = self.call("GET", f"/albums/{sid}", query={"fields": "total_tracks"})
                total = (data or {}).get("total_tracks", 0) if status == 200 else 0
            else:
                status, data = self.call("GET", f"/playlists/{sid}", query={"fields": "tracks.total"})
                total = ((data or {}).get("tracks") or {}).get("total", 0) if status == 200 else 0
            if total > 1:
                body["offset"] = {"position": secrets.randbelow(total)}
        self._player("PUT", "/me/player/play", body)
        if kind != "track":
            try:
                self._player("PUT", "/me/player/shuffle", query={"state": "true" if shuffle else "false"})
            except SpotifyError:
                pass

    def current(self):
        status, data = self.call("GET", "/me/player")
        return data if status == 200 else None

    def toggle_like(self):
        state = self.current()
        item = (state or {}).get("item")
        if not item:
            raise SpotifyError("Nothing is playing")
        _, saved = self.call("GET", "/me/tracks/contains", query={"ids": item["id"]})
        liked = bool(saved and saved[0])
        self._player("DELETE" if liked else "PUT", "/me/tracks", query={"ids": item["id"]})
        return not liked, item["name"]

    def toggle_shuffle(self):
        state = self.current() or {}
        on = not state.get("shuffle_state", False)
        self._player("PUT", "/me/player/shuffle", query={"state": "true" if on else "false"})
        return on

    def seek_by(self, seconds):
        state = self.current()
        if not state or not state.get("item"):
            raise SpotifyError("Nothing is playing")
        pos = max(0, state.get("progress_ms", 0) + int(seconds * 1000))
        self._player("PUT", "/me/player/seek", query={"position_ms": pos})
