"""NexusHub: your personal Windows control hub.  Run: python main.py"""
import ctypes
import logging
import os
import sys
import time

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

try:
    # Verify HTTPS with Windows' own certificate store. Antivirus "web shields" re-sign
    # traffic with a certificate only Windows knows about; without this, online modules fail.
    import truststore
    truststore.inject_into_ssl()
except ImportError:
    pass

from PySide6.QtCore import Qt
from PySide6.QtNetwork import QLocalServer, QLocalSocket
from PySide6.QtWidgets import QApplication

from core import ui
from core.config import APP_DIR

SERVER_NAME = "NexusHub-" + os.environ.get("USERNAME", "user")


def already_running(message=b"show"):
    """If another NexusHub is open, send it `message` (b"show", b"quit" or None) and return True."""
    sock = QLocalSocket()
    sock.connectToServer(SERVER_NAME)
    if sock.waitForConnected(300):
        if message:
            sock.write(message)
            sock.waitForBytesWritten(300)
        sock.disconnectFromServer()
        return True
    return False


def main():
    os.makedirs(APP_DIR, exist_ok=True)
    logging.basicConfig(filename=os.path.join(APP_DIR, "nexushub.log"), level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    sys.excepthook = lambda *exc: logging.getLogger("nexushub").error("Unhandled error", exc_info=exc)
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("NexusHub.App")

    app = QApplication(sys.argv)
    app.setApplicationName("NexusHub")
    app.setQuitOnLastWindowClosed(False)

    from core.config import Config
    look = Config().get("appearance", {})
    custom = look.get("custom_colors")
    ui.apply_theme(look.get("theme", "Nexus Violet"), tuple(custom) if custom else None)
    app.setWindowIcon(ui.app_icon())
    app.setStyleSheet(ui.STYLESHEET)

    if "--restart" in sys.argv:
        # Replace the running copy: ask it to quit, and wait until it has let go of the lock.
        for i in range(40):
            if not already_running(b"quit" if i % 10 == 0 else None):
                break
            time.sleep(0.2)
    elif already_running():
        return 0
    QLocalServer.removeServer(SERVER_NAME)
    server = QLocalServer()
    server.listen(SERVER_NAME)

    from core.hub import Hub
    hub = Hub(app, start_hidden="--minimized" in sys.argv and "--restart" not in sys.argv)

    def on_connection():
        conn = server.nextPendingConnection()

        def got():
            msg = bytes(conn.readAll())
            if msg.startswith(b"quit"):
                hub.quit()
            else:
                hub.show_window()
        conn.readyRead.connect(got)

    server.newConnection.connect(on_connection)
    return app.exec()


if __name__ == "__main__":
    code = main()
    # Settings are already saved. Skip interpreter teardown, which would try to release
    # audio COM objects after Windows has shut COM down and print scary (harmless) errors.
    logging.shutdown()
    os._exit(code or 0)
